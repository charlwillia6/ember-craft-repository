'use strict';

define('ember-craft-repository/tests/app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'app.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/breakpoints.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - breakpoints.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'breakpoints.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/ember-sinon-qunit/test', ['exports', 'ember', 'sinon', 'qunit', 'ember-qunit'], function (exports, _ember, _sinon, _qunit, _emberQunit) {
  exports['default'] = test;

  _sinon['default'].expectation.fail = _sinon['default'].assert.fail = function (msg) {
    _qunit['default'].ok(false, msg);
  };

  _sinon['default'].assert.pass = function (assertion) {
    _qunit['default'].ok(true, assertion);
  };

  _sinon['default'].config = {
    injectIntoThis: false,
    injectInto: null,
    properties: ['spy', 'stub', 'mock', 'sandbox'],
    useFakeTimers: false,
    useFakeServer: false
  };

  function test(testName, callback) {
    function sinonWrapper() {
      var context = this;
      if (_ember['default'].isBlank(context)) {
        context = {};
      }
      _sinon['default'].config.injectInto = context;

      return _sinon['default'].test(callback).apply(context, arguments);
    }

    return (0, _emberQunit.test)(testName, sinonWrapper);
  }
});
define('ember-craft-repository/tests/helpers/bibliographic-helper.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/bibliographic-helper.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/bibliographic-helper.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/capitalize.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/capitalize.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/capitalize.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/check-data-type.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/check-data-type.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/check-data-type.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/destroy-app', ['exports', 'ember'], function (exports, _ember) {
  exports['default'] = destroyApp;

  function destroyApp(application) {
    _ember['default'].run(application, 'destroy');
  }
});
define('ember-craft-repository/tests/helpers/destroy-app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/destroy-app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/destroy-app.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/draft-text-input.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/draft-text-input.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/draft-text-input.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/ember-i18n/test-helpers', ['exports', 'ember'], function (exports, _ember) {

  // example usage: find(`.header:contains(${t('welcome_message')})`)
  _ember['default'].Test.registerHelper('t', function (app, key, interpolations) {
    var i18n = app.__container__.lookup('service:i18n');
    return i18n.t(key, interpolations);
  });

  // example usage: expectTranslation('.header', 'welcome_message');
  _ember['default'].Test.registerHelper('expectTranslation', function (app, element, key, interpolations) {
    var text = app.testHelpers.t(key, interpolations);

    assertTranslation(element, key, text);
  });

  var assertTranslation = (function () {
    if (typeof QUnit !== 'undefined' && typeof ok === 'function') {
      return function (element, key, text) {
        ok(find(element + ':contains(' + text + ')').length, 'Found translation key ' + key + ' in ' + element);
      };
    } else if (typeof expect === 'function') {
      return function (element, key, text) {
        var found = !!find(element + ':contains(' + text + ')').length;
        expect(found).to.equal(true);
      };
    } else {
      return function () {
        throw new Error("ember-i18n could not find a compatible test framework");
      };
    }
  })();
});
define('ember-craft-repository/tests/helpers/ember-simple-auth', ['exports', 'ember-simple-auth/authenticators/test'], function (exports, _emberSimpleAuthAuthenticatorsTest) {
  exports.authenticateSession = authenticateSession;
  exports.currentSession = currentSession;
  exports.invalidateSession = invalidateSession;

  var TEST_CONTAINER_KEY = 'authenticator:test';

  function ensureAuthenticator(app, container) {
    var authenticator = container.lookup(TEST_CONTAINER_KEY);
    if (!authenticator) {
      app.register(TEST_CONTAINER_KEY, _emberSimpleAuthAuthenticatorsTest['default']);
    }
  }

  function authenticateSession(app, sessionData) {
    var container = app.__container__;

    var session = container.lookup('service:session');
    ensureAuthenticator(app, container);
    session.authenticate(TEST_CONTAINER_KEY, sessionData);
    return wait();
  }

  ;

  function currentSession(app) {
    return app.__container__.lookup('service:session');
  }

  ;

  function invalidateSession(app) {
    var session = app.__container__.lookup('service:session');
    if (session.get('isAuthenticated')) {
      session.invalidate();
    }
    return wait();
  }

  ;
});
define('ember-craft-repository/tests/helpers/module-for-acceptance', ['exports', 'qunit', 'ember-craft-repository/tests/helpers/start-app', 'ember-craft-repository/tests/helpers/destroy-app'], function (exports, _qunit, _emberCraftRepositoryTestsHelpersStartApp, _emberCraftRepositoryTestsHelpersDestroyApp) {
  exports['default'] = function (name) {
    var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

    (0, _qunit.module)(name, {
      beforeEach: function beforeEach() {
        this.application = (0, _emberCraftRepositoryTestsHelpersStartApp['default'])();

        if (options.beforeEach) {
          options.beforeEach.apply(this, arguments);
        }
      },

      afterEach: function afterEach() {
        if (options.afterEach) {
          options.afterEach.apply(this, arguments);
        }

        (0, _emberCraftRepositoryTestsHelpersDestroyApp['default'])(this.application);
      }
    });
  };
});
define('ember-craft-repository/tests/helpers/module-for-acceptance.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/module-for-acceptance.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/module-for-acceptance.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/permission-helper.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/permission-helper.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/permission-helper.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/resolver', ['exports', 'ember-craft-repository/resolver', 'ember-craft-repository/config/environment'], function (exports, _emberCraftRepositoryResolver, _emberCraftRepositoryConfigEnvironment) {

  var resolver = _emberCraftRepositoryResolver['default'].create();

  resolver.namespace = {
    modulePrefix: _emberCraftRepositoryConfigEnvironment['default'].modulePrefix,
    podModulePrefix: _emberCraftRepositoryConfigEnvironment['default'].podModulePrefix
  };

  exports['default'] = resolver;
});
define('ember-craft-repository/tests/helpers/resolver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/resolver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/resolver.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/selected-helper.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/selected-helper.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/selected-helper.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/helpers/start-app', ['exports', 'ember', 'ember-craft-repository/app', 'ember-craft-repository/config/environment'], function (exports, _ember, _emberCraftRepositoryApp, _emberCraftRepositoryConfigEnvironment) {
  exports['default'] = startApp;

  function startApp(attrs) {
    var application = undefined;

    var attributes = _ember['default'].merge({}, _emberCraftRepositoryConfigEnvironment['default'].APP);
    attributes = _ember['default'].merge(attributes, attrs); // use defaults, but you can override;

    _ember['default'].run(function () {
      application = _emberCraftRepositoryApp['default'].create(attributes);
      application.setupForTesting();
      application.injectTestHelpers();
    });

    return application;
  }
});
define('ember-craft-repository/tests/helpers/start-app.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - helpers/start-app.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/start-app.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/locales/en-us/config.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - locales/en-us/config.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'locales/en-us/config.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/locales/en-us/translations.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - locales/en-us/translations.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'locales/en-us/translations.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/mirage/config.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - mirage/config.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mirage/config.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/mirage/factories/base.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - mirage/factories/base.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mirage/factories/base.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/mirage/scenarios/default.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - mirage/scenarios/default.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mirage/scenarios/default.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/mixins/paginated-component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - mixins/paginated-component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/paginated-component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/allnodes/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/allnodes/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/allnodes/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/application/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/application/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/application/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/application/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/application/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/application/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/collections/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/collections/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/collections/detail/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/collections/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/collections/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/collections/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/collections/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/collections/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/collections/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/comment-detail/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/comment-detail/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/comment-detail/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/comment-form/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/comment-form/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/comment-form/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/comment-pane/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/comment-pane/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/comment-pane/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/contrib-add/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/contrib-add/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/contrib-add/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/contrib-manager/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/contrib-manager/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/contrib-manager/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/dropzone-widget/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/dropzone-widget/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/dropzone-widget/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/execution-dashboard/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/execution-dashboard/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/execution-dashboard/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-actions/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-actions/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-actions/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-browser-icon/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-browser-icon/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-browser-icon/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-browser-item/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-browser-item/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-browser-item/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-browser/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-browser/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-browser/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-chooser/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-chooser/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-chooser/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-tree/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-tree/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-tree/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/file-widget/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/file-widget/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/file-widget/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/footer-main/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/footer-main/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/footer-main/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/loading-widget/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/loading-widget/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/loading-widget/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/log-detail/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/log-detail/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/log-detail/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/login-register-selector/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/login-register-selector/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/login-register-selector/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/navbar-main/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/navbar-main/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/navbar-main/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/navbar-sidebar/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/navbar-sidebar/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/navbar-sidebar/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/oauth-popup/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/oauth-popup/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/oauth-popup/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/pagination-control-ui/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/pagination-control-ui/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/pagination-control-ui/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/project-child-create/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/project-child-create/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/project-child-create/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/project-create/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/project-create/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/project-create/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/project-delete/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/project-delete/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'pods/components/project-delete/component.js should pass jshint.\npods/components/project-delete/component.js: line 13, col 23, \'name\' is defined but never used.\n\n1 error');
  });
});
define('ember-craft-repository/tests/pods/components/project-edit/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/project-edit/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/project-edit/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/project-summary/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/project-summary/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/project-summary/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/projects-cards/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/projects-cards/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/projects-cards/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/projects-list/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/projects-list/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/projects-list/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/projects-public-cards/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/projects-public-cards/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/projects-public-cards/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/projects-search/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/projects-search/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/projects-search/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/components/tags-widget/component.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/components/tags-widget/component.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/components/tags-widget/component.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/cookielogin/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/cookielogin/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/cookielogin/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/cookielogin/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/cookielogin/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/cookielogin/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/index/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/institutions/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/institutions/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/institutions/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/login/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/login/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/login/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/login/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/login/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/login/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/prereg/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/prereg/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/prereg/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/profile/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/profile/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/profile/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/children/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/children/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/children/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/draft-registrations/detail/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/draft-registrations/detail/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/draft-registrations/detail/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/draft-registrations/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/draft-registrations/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/draft-registrations/detail/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/draft-registrations/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/draft-registrations/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/draft-registrations/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/draft-registrations/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/draft-registrations/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/draft-registrations/index/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/index/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/provider/file/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/provider/file/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/provider/file/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/provider/file/revisions/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/provider/file/revisions/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/provider/file/revisions/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/provider/file/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/provider/file/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/provider/file/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/provider/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/provider/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/provider/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/provider/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/provider/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/provider/index/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/provider/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/provider/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/provider/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/files/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/files/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/files/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/index/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/registrations/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/registrations/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/registrations/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/detail/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/index/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/index/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/index/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/projects/index/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/projects/index/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/projects/index/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/registrations/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/registrations/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/registrations/detail/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/registrations/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/registrations/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/registrations/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/signup/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/signup/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/signup/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/usernodes/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/usernodes/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/usernodes/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/users/detail/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/users/detail/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/users/detail/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/users/list/controller.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/users/list/controller.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/users/list/controller.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/pods/users/list/route.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - pods/users/list/route.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'pods/users/list/route.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/resolver.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - resolver.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'resolver.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/router.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - router.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'router.js should pass jshint.');
  });
});
define('ember-craft-repository/tests/test-helper', ['exports', 'ember-craft-repository/tests/helpers/resolver', 'ember-qunit'], function (exports, _emberCraftRepositoryTestsHelpersResolver, _emberQunit) {

  (0, _emberQunit.setResolver)(_emberCraftRepositoryTestsHelpersResolver['default']);
});
define('ember-craft-repository/tests/test-helper.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - test-helper.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'test-helper.js should pass jshint.');
  });
});
/* jshint ignore:start */

require('ember-craft-repository/tests/test-helper');
EmberENV.TESTS_FILE_LOADED = true;

/* jshint ignore:end */
//# sourceMappingURL=tests.map