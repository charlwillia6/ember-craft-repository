"use strict";

/* jshint ignore:start */



/* jshint ignore:end */

define('ember-craft-repository/adapters/collection', ['exports', 'ember-osf/adapters/collection'], function (exports, _emberOsfAdaptersCollection) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersCollection['default'];
    }
  });
});
define('ember-craft-repository/adapters/comment-report', ['exports', 'ember-osf/adapters/comment-report'], function (exports, _emberOsfAdaptersCommentReport) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersCommentReport['default'];
    }
  });
});
define('ember-craft-repository/adapters/comment', ['exports', 'ember-osf/adapters/comment'], function (exports, _emberOsfAdaptersComment) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersComment['default'];
    }
  });
});
define('ember-craft-repository/adapters/contributor', ['exports', 'ember-osf/adapters/contributor'], function (exports, _emberOsfAdaptersContributor) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersContributor['default'];
    }
  });
});
define('ember-craft-repository/adapters/draft-registration', ['exports', 'ember-osf/adapters/draft-registration'], function (exports, _emberOsfAdaptersDraftRegistration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersDraftRegistration['default'];
    }
  });
});
define('ember-craft-repository/adapters/file-contents', ['exports', 'ember-osf/adapters/file-contents'], function (exports, _emberOsfAdaptersFileContents) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersFileContents['default'];
    }
  });
});
define('ember-craft-repository/adapters/file-provider', ['exports', 'ember-osf/adapters/file-provider'], function (exports, _emberOsfAdaptersFileProvider) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersFileProvider['default'];
    }
  });
});
define('ember-craft-repository/adapters/file-version', ['exports', 'ember-osf/adapters/file-version'], function (exports, _emberOsfAdaptersFileVersion) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersFileVersion['default'];
    }
  });
});
define('ember-craft-repository/adapters/file', ['exports', 'ember-osf/adapters/file'], function (exports, _emberOsfAdaptersFile) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersFile['default'];
    }
  });
});
define('ember-craft-repository/adapters/institution', ['exports', 'ember-osf/adapters/institution'], function (exports, _emberOsfAdaptersInstitution) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersInstitution['default'];
    }
  });
});
define('ember-craft-repository/adapters/log', ['exports', 'ember-osf/adapters/log'], function (exports, _emberOsfAdaptersLog) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersLog['default'];
    }
  });
});
define('ember-craft-repository/adapters/metaschema', ['exports', 'ember-osf/adapters/metaschema'], function (exports, _emberOsfAdaptersMetaschema) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersMetaschema['default'];
    }
  });
});
define('ember-craft-repository/adapters/node-link', ['exports', 'ember-osf/adapters/node-link'], function (exports, _emberOsfAdaptersNodeLink) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersNodeLink['default'];
    }
  });
});
define('ember-craft-repository/adapters/node', ['exports', 'ember-osf/adapters/node'], function (exports, _emberOsfAdaptersNode) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersNode['default'];
    }
  });
});
define('ember-craft-repository/adapters/osf-adapter', ['exports', 'ember-osf/adapters/osf-adapter'], function (exports, _emberOsfAdaptersOsfAdapter) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersOsfAdapter['default'];
    }
  });
});
define('ember-craft-repository/adapters/registration', ['exports', 'ember-osf/adapters/registration'], function (exports, _emberOsfAdaptersRegistration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersRegistration['default'];
    }
  });
});
define('ember-craft-repository/adapters/user', ['exports', 'ember-osf/adapters/user'], function (exports, _emberOsfAdaptersUser) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAdaptersUser['default'];
    }
  });
});
define('ember-craft-repository/app', ['exports', 'ember', 'ember-craft-repository/resolver', 'ember-load-initializers', 'ember-craft-repository/config/environment'], function (exports, _ember, _emberCraftRepositoryResolver, _emberLoadInitializers, _emberCraftRepositoryConfigEnvironment) {

    var App = undefined;

    _ember['default'].MODEL_FACTORY_INJECTIONS = true;

    App = _ember['default'].Application.extend({
        modulePrefix: _emberCraftRepositoryConfigEnvironment['default'].modulePrefix,
        podModulePrefix: _emberCraftRepositoryConfigEnvironment['default'].podModulePrefix,
        LOG_TRANSITIONS: true,
        Resolver: _emberCraftRepositoryResolver['default']
    });

    (0, _emberLoadInitializers['default'])(App, _emberCraftRepositoryConfigEnvironment['default'].modulePrefix);

    exports['default'] = App;
});
// app/app.js
define('ember-craft-repository/authenticators/osf-cookie', ['exports', 'ember-osf/authenticators/osf-cookie'], function (exports, _emberOsfAuthenticatorsOsfCookie) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAuthenticatorsOsfCookie['default'];
    }
  });
});
define('ember-craft-repository/authenticators/osf-token', ['exports', 'ember-osf/authenticators/osf-token'], function (exports, _emberOsfAuthenticatorsOsfToken) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAuthenticatorsOsfToken['default'];
    }
  });
});
define('ember-craft-repository/authorizers/osf-cookie', ['exports', 'ember-osf/authorizers/osf-cookie'], function (exports, _emberOsfAuthorizersOsfCookie) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAuthorizersOsfCookie['default'];
    }
  });
});
define('ember-craft-repository/authorizers/osf-token', ['exports', 'ember-osf/authorizers/osf-token'], function (exports, _emberOsfAuthorizersOsfToken) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfAuthorizersOsfToken['default'];
    }
  });
});
define('ember-craft-repository/breakpoints', ['exports'], function (exports) {
    // app/breakpoints.js

    exports['default'] = {
        mobile: '(max-width: 768px)',
        tablet: '(min-width: 769px) and (max-width: 992px)',
        desktop: '(min-width: 993px)'
    };
});
define('ember-craft-repository/components/app-version', ['exports', 'ember-cli-app-version/components/app-version', 'ember-craft-repository/config/environment'], function (exports, _emberCliAppVersionComponentsAppVersion, _emberCraftRepositoryConfigEnvironment) {

  var name = _emberCraftRepositoryConfigEnvironment['default'].APP.name;
  var version = _emberCraftRepositoryConfigEnvironment['default'].APP.version;

  exports['default'] = _emberCliAppVersionComponentsAppVersion['default'].extend({
    version: version,
    name: name
  });
});
define('ember-craft-repository/components/comment-detail/component', ['exports', 'ember-osf/components/comment-detail/component'], function (exports, _emberOsfComponentsCommentDetailComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsCommentDetailComponent['default'];
    }
  });
});
define('ember-craft-repository/components/comment-form/component', ['exports', 'ember-osf/components/comment-form/component'], function (exports, _emberOsfComponentsCommentFormComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsCommentFormComponent['default'];
    }
  });
});
define('ember-craft-repository/components/comment-pane/component', ['exports', 'ember-osf/components/comment-pane/component'], function (exports, _emberOsfComponentsCommentPaneComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsCommentPaneComponent['default'];
    }
  });
});
define('ember-craft-repository/components/dropzone-widget/component', ['exports', 'ember-osf/components/dropzone-widget/component'], function (exports, _emberOsfComponentsDropzoneWidgetComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsDropzoneWidgetComponent['default'];
    }
  });
});
define('ember-craft-repository/components/ember-collection', ['exports', 'ember-collection/components/ember-collection'], function (exports, _emberCollectionComponentsEmberCollection) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberCollectionComponentsEmberCollection['default'];
    }
  });
});
define('ember-craft-repository/components/ember-native-scrollable', ['exports', 'ember-collection/components/ember-native-scrollable'], function (exports, _emberCollectionComponentsEmberNativeScrollable) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberCollectionComponentsEmberNativeScrollable['default'];
    }
  });
});
define('ember-craft-repository/components/eosf-project-nav/component', ['exports', 'ember-osf/components/eosf-project-nav/component'], function (exports, _emberOsfComponentsEosfProjectNavComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsEosfProjectNavComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-browser-icon/component', ['exports', 'ember-osf/components/file-browser-icon/component'], function (exports, _emberOsfComponentsFileBrowserIconComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileBrowserIconComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-browser-item/component', ['exports', 'ember-osf/components/file-browser-item/component'], function (exports, _emberOsfComponentsFileBrowserItemComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileBrowserItemComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-browser-tree/component', ['exports', 'ember-osf/components/file-browser-tree/component'], function (exports, _emberOsfComponentsFileBrowserTreeComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileBrowserTreeComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-browser/component', ['exports', 'ember-osf/components/file-browser/component'], function (exports, _emberOsfComponentsFileBrowserComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileBrowserComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-chooser/component', ['exports', 'ember-osf/components/file-chooser/component'], function (exports, _emberOsfComponentsFileChooserComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileChooserComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-renderer/component', ['exports', 'ember-osf/components/file-renderer/component'], function (exports, _emberOsfComponentsFileRendererComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileRendererComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-version/component', ['exports', 'ember-osf/components/file-version/component'], function (exports, _emberOsfComponentsFileVersionComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileVersionComponent['default'];
    }
  });
});
define('ember-craft-repository/components/file-widget/component', ['exports', 'ember-osf/components/file-widget/component'], function (exports, _emberOsfComponentsFileWidgetComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsFileWidgetComponent['default'];
    }
  });
});
define('ember-craft-repository/components/head-content', ['exports', 'ember', 'ember-craft-repository/templates/head'], function (exports, _ember, _emberCraftRepositoryTemplatesHead) {
  exports['default'] = _ember['default'].Component.extend({
    tagName: '',
    model: _ember['default'].inject.service('head-data'),
    layout: _emberCraftRepositoryTemplatesHead['default']
  });
});
define('ember-craft-repository/components/head-layout', ['exports', 'ember', 'ember-cli-head/templates/components/head-layout'], function (exports, _ember, _emberCliHeadTemplatesComponentsHeadLayout) {
  exports['default'] = _ember['default'].Component.extend({
    tagName: '',
    layout: _emberCliHeadTemplatesComponentsHeadLayout['default']
  });
});
define('ember-craft-repository/components/oauth-popup/component', ['exports', 'ember-osf/components/oauth-popup/component'], function (exports, _emberOsfComponentsOauthPopupComponent) {
    Object.defineProperty(exports, 'default', {
        enumerable: true,
        get: function get() {
            return _emberOsfComponentsOauthPopupComponent['default'];
        }
    });
});
define('ember-craft-repository/components/osf-copyright/component', ['exports', 'ember-osf/components/osf-copyright/component'], function (exports, _emberOsfComponentsOsfCopyrightComponent) {
    Object.defineProperty(exports, 'default', {
        enumerable: true,
        get: function get() {
            return _emberOsfComponentsOsfCopyrightComponent['default'];
        }
    });
});
define('ember-craft-repository/components/osf-footer/component', ['exports', 'ember-osf/components/osf-footer/component'], function (exports, _emberOsfComponentsOsfFooterComponent) {
    Object.defineProperty(exports, 'default', {
        enumerable: true,
        get: function get() {
            return _emberOsfComponentsOsfFooterComponent['default'];
        }
    });
});
define('ember-craft-repository/components/osf-mode-footer/component', ['exports', 'ember-osf/components/osf-mode-footer/component'], function (exports, _emberOsfComponentsOsfModeFooterComponent) {
    Object.defineProperty(exports, 'default', {
        enumerable: true,
        get: function get() {
            return _emberOsfComponentsOsfModeFooterComponent['default'];
        }
    });
});
define('ember-craft-repository/components/osf-navbar/component', ['exports', 'ember-osf/components/osf-navbar/component'], function (exports, _emberOsfComponentsOsfNavbarComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsOsfNavbarComponent['default'];
    }
  });
});
define('ember-craft-repository/components/osf-paginator/component', ['exports', 'ember-osf/components/osf-paginator/component'], function (exports, _emberOsfComponentsOsfPaginatorComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsOsfPaginatorComponent['default'];
    }
  });
});
define('ember-craft-repository/components/pagination-control/component', ['exports', 'ember-osf/components/pagination-control/component'], function (exports, _emberOsfComponentsPaginationControlComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsPaginationControlComponent['default'];
    }
  });
});
define('ember-craft-repository/components/radio-button', ['exports', 'ember-radio-buttons/components/radio-button'], function (exports, _emberRadioButtonsComponentsRadioButton) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberRadioButtonsComponentsRadioButton['default'];
    }
  });
});
define('ember-craft-repository/components/search-dropdown/component', ['exports', 'ember-osf/components/search-dropdown/component'], function (exports, _emberOsfComponentsSearchDropdownComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsSearchDropdownComponent['default'];
    }
  });
});
define('ember-craft-repository/components/sign-up/component', ['exports', 'ember-osf/components/sign-up/component'], function (exports, _emberOsfComponentsSignUpComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsSignUpComponent['default'];
    }
  });
});
define('ember-craft-repository/components/tags-widget/component', ['exports', 'ember-osf/components/tags-widget/component'], function (exports, _emberOsfComponentsTagsWidgetComponent) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfComponentsTagsWidgetComponent['default'];
    }
  });
});
define('ember-craft-repository/components/ui-accordion', ['exports', 'semantic-ui-ember/components/ui-accordion'], function (exports, _semanticUiEmberComponentsUiAccordion) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiAccordion['default'];
    }
  });
});
define('ember-craft-repository/components/ui-checkbox', ['exports', 'semantic-ui-ember/components/ui-checkbox'], function (exports, _semanticUiEmberComponentsUiCheckbox) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiCheckbox['default'];
    }
  });
});
define('ember-craft-repository/components/ui-dimmer', ['exports', 'semantic-ui-ember/components/ui-dimmer'], function (exports, _semanticUiEmberComponentsUiDimmer) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiDimmer['default'];
    }
  });
});
define('ember-craft-repository/components/ui-dropdown', ['exports', 'semantic-ui-ember/components/ui-dropdown'], function (exports, _semanticUiEmberComponentsUiDropdown) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiDropdown['default'];
    }
  });
});
define('ember-craft-repository/components/ui-embed', ['exports', 'semantic-ui-ember/components/ui-embed'], function (exports, _semanticUiEmberComponentsUiEmbed) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiEmbed['default'];
    }
  });
});
define('ember-craft-repository/components/ui-modal', ['exports', 'semantic-ui-ember/components/ui-modal'], function (exports, _semanticUiEmberComponentsUiModal) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiModal['default'];
    }
  });
});
define('ember-craft-repository/components/ui-nag', ['exports', 'semantic-ui-ember/components/ui-nag'], function (exports, _semanticUiEmberComponentsUiNag) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiNag['default'];
    }
  });
});
define('ember-craft-repository/components/ui-popup', ['exports', 'semantic-ui-ember/components/ui-popup'], function (exports, _semanticUiEmberComponentsUiPopup) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiPopup['default'];
    }
  });
});
define('ember-craft-repository/components/ui-progress', ['exports', 'semantic-ui-ember/components/ui-progress'], function (exports, _semanticUiEmberComponentsUiProgress) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiProgress['default'];
    }
  });
});
define('ember-craft-repository/components/ui-radio', ['exports', 'semantic-ui-ember/components/ui-radio'], function (exports, _semanticUiEmberComponentsUiRadio) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiRadio['default'];
    }
  });
});
define('ember-craft-repository/components/ui-rating', ['exports', 'semantic-ui-ember/components/ui-rating'], function (exports, _semanticUiEmberComponentsUiRating) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiRating['default'];
    }
  });
});
define('ember-craft-repository/components/ui-search', ['exports', 'semantic-ui-ember/components/ui-search'], function (exports, _semanticUiEmberComponentsUiSearch) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiSearch['default'];
    }
  });
});
define('ember-craft-repository/components/ui-shape', ['exports', 'semantic-ui-ember/components/ui-shape'], function (exports, _semanticUiEmberComponentsUiShape) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiShape['default'];
    }
  });
});
define('ember-craft-repository/components/ui-sidebar', ['exports', 'semantic-ui-ember/components/ui-sidebar'], function (exports, _semanticUiEmberComponentsUiSidebar) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiSidebar['default'];
    }
  });
});
define('ember-craft-repository/components/ui-sticky', ['exports', 'semantic-ui-ember/components/ui-sticky'], function (exports, _semanticUiEmberComponentsUiSticky) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberComponentsUiSticky['default'];
    }
  });
});
define('ember-craft-repository/helpers/and', ['exports', 'ember', 'ember-truth-helpers/helpers/and'], function (exports, _ember, _emberTruthHelpersHelpersAnd) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersAnd.andHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersAnd.andHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/bibliographic-helper', ['exports', 'ember'], function (exports, _ember) {
    exports.bibliographicHelper = bibliographicHelper;

    function bibliographicHelper(params) {
        // checks if bibliographic is true or false
        if (params[0]) {
            return 'checked';
        }
        return null;
    }

    exports['default'] = _ember['default'].Helper.helper(bibliographicHelper);
});
// app/helpers/bibliographic-helper.js
define('ember-craft-repository/helpers/capitalize', ['exports', 'ember'], function (exports, _ember) {
    var _slicedToArray = (function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i['return']) _i['return'](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError('Invalid attempt to destructure non-iterable instance'); } }; })();

    var capitalize = _ember['default'].String.capitalize;

    exports['default'] = _ember['default'].Helper.helper(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 1);

        var string = _ref2[0];

        return capitalize(string);
    });
});
// app/helpers/capitalize.js
define('ember-craft-repository/helpers/check-data-type', ['exports', 'ember'], function (exports, _ember) {
    exports.checkDataType = checkDataType;

    function checkDataType(resource) {
        return _ember['default'].typeOf(resource[0]);
    }

    exports['default'] = _ember['default'].Helper.helper(checkDataType);
});
define('ember-craft-repository/helpers/draft-text-input', ['exports', 'ember'], function (exports, _ember) {
    var _slicedToArray = (function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i['return']) _i['return'](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError('Invalid attempt to destructure non-iterable instance'); } }; })();

    exports.draftTextInput = draftTextInput;

    function draftTextInput(_ref) {
        var _ref2 = _slicedToArray(_ref, 4);

        var metadata = _ref2[0];
        var question = _ref2[1];
        var subquestion = _ref2[2];
        var subsubquestion = _ref2[3];

        var response = '';
        if (subquestion) {
            if (metadata && metadata[question.qid] && metadata[question.qid].value[subquestion.id]) {
                if (subsubquestion) {
                    if (metadata[question.qid].value[subquestion.id].value[subsubquestion.id]) {
                        response = metadata[question.qid].value[subquestion.id].value[subsubquestion.id].value;
                    }
                } else {
                    response = metadata[question.qid].value[subquestion.id].value;
                }
            }
        } else {
            if (metadata && metadata[question.qid]) {
                if (_ember['default'].typeOf(metadata[question.qid].value) === 'array') {
                    response = metadata[question.qid].value[0];
                } else {
                    response = metadata[question.qid].value;
                }
            }
        }
        return response;
    }

    exports['default'] = _ember['default'].Helper.helper(draftTextInput);
});
define('ember-craft-repository/helpers/elem-id', ['exports', 'ember-osf/helpers/elem-id'], function (exports, _emberOsfHelpersElemId) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfHelpersElemId['default'];
    }
  });
  Object.defineProperty(exports, 'elemId', {
    enumerable: true,
    get: function get() {
      return _emberOsfHelpersElemId.elemId;
    }
  });
});
define('ember-craft-repository/helpers/eq', ['exports', 'ember', 'ember-truth-helpers/helpers/equal'], function (exports, _ember, _emberTruthHelpersHelpersEqual) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersEqual.equalHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersEqual.equalHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/fixed-grid-layout', ['exports', 'ember', 'ember-collection/layouts/grid'], function (exports, _ember, _emberCollectionLayoutsGrid) {
  exports['default'] = _ember['default'].Helper.helper(function (params, hash) {
    return new _emberCollectionLayoutsGrid['default'](params[0], params[1]);
  });
});
define('ember-craft-repository/helpers/gt', ['exports', 'ember', 'ember-truth-helpers/helpers/gt'], function (exports, _ember, _emberTruthHelpersHelpersGt) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersGt.gtHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersGt.gtHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/gte', ['exports', 'ember', 'ember-truth-helpers/helpers/gte'], function (exports, _ember, _emberTruthHelpersHelpersGte) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersGte.gteHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersGte.gteHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/is-array', ['exports', 'ember', 'ember-truth-helpers/helpers/is-array'], function (exports, _ember, _emberTruthHelpersHelpersIsArray) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersIsArray.isArrayHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersIsArray.isArrayHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/lt', ['exports', 'ember', 'ember-truth-helpers/helpers/lt'], function (exports, _ember, _emberTruthHelpersHelpersLt) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersLt.ltHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersLt.ltHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/lte', ['exports', 'ember', 'ember-truth-helpers/helpers/lte'], function (exports, _ember, _emberTruthHelpersHelpersLte) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersLte.lteHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersLte.lteHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/map-value', ['exports', 'semantic-ui-ember/helpers/map-value'], function (exports, _semanticUiEmberHelpersMapValue) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberHelpersMapValue['default'];
    }
  });
  Object.defineProperty(exports, 'mapValue', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberHelpersMapValue.mapValue;
    }
  });
});
define('ember-craft-repository/helpers/mixed-grid-layout', ['exports', 'ember', 'ember-collection/layouts/mixed-grid'], function (exports, _ember, _emberCollectionLayoutsMixedGrid) {
  exports['default'] = _ember['default'].Helper.helper(function (params, hash) {
    return new _emberCollectionLayoutsMixedGrid['default'](params[0]);
  });
});
define('ember-craft-repository/helpers/moment-calendar', ['exports', 'ember', 'ember-craft-repository/config/environment', 'ember-moment/helpers/moment-calendar'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment, _emberMomentHelpersMomentCalendar) {
  exports['default'] = _emberMomentHelpersMomentCalendar['default'].extend({
    globalAllowEmpty: !!_ember['default'].get(_emberCraftRepositoryConfigEnvironment['default'], 'moment.allowEmpty')
  });
});
define('ember-craft-repository/helpers/moment-duration', ['exports', 'ember-moment/helpers/moment-duration'], function (exports, _emberMomentHelpersMomentDuration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberMomentHelpersMomentDuration['default'];
    }
  });
});
define('ember-craft-repository/helpers/moment-format', ['exports', 'ember', 'ember-craft-repository/config/environment', 'ember-moment/helpers/moment-format'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment, _emberMomentHelpersMomentFormat) {
  exports['default'] = _emberMomentHelpersMomentFormat['default'].extend({
    globalAllowEmpty: !!_ember['default'].get(_emberCraftRepositoryConfigEnvironment['default'], 'moment.allowEmpty')
  });
});
define('ember-craft-repository/helpers/moment-from-now', ['exports', 'ember', 'ember-craft-repository/config/environment', 'ember-moment/helpers/moment-from-now'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment, _emberMomentHelpersMomentFromNow) {
  exports['default'] = _emberMomentHelpersMomentFromNow['default'].extend({
    globalAllowEmpty: !!_ember['default'].get(_emberCraftRepositoryConfigEnvironment['default'], 'moment.allowEmpty')
  });
});
define('ember-craft-repository/helpers/moment-to-now', ['exports', 'ember', 'ember-craft-repository/config/environment', 'ember-moment/helpers/moment-to-now'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment, _emberMomentHelpersMomentToNow) {
  exports['default'] = _emberMomentHelpersMomentToNow['default'].extend({
    globalAllowEmpty: !!_ember['default'].get(_emberCraftRepositoryConfigEnvironment['default'], 'moment.allowEmpty')
  });
});
define('ember-craft-repository/helpers/not-eq', ['exports', 'ember', 'ember-truth-helpers/helpers/not-equal'], function (exports, _ember, _emberTruthHelpersHelpersNotEqual) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersNotEqual.notEqualHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersNotEqual.notEqualHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/not', ['exports', 'ember', 'ember-truth-helpers/helpers/not'], function (exports, _ember, _emberTruthHelpersHelpersNot) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersNot.notHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersNot.notHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/now', ['exports', 'ember-moment/helpers/now'], function (exports, _emberMomentHelpersNow) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberMomentHelpersNow['default'];
    }
  });
});
define('ember-craft-repository/helpers/or', ['exports', 'ember', 'ember-truth-helpers/helpers/or'], function (exports, _ember, _emberTruthHelpersHelpersOr) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersOr.orHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersOr.orHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/helpers/page-title', ['exports', 'ember-page-title/helpers/page-title'], function (exports, _emberPageTitleHelpersPageTitle) {
  exports['default'] = _emberPageTitleHelpersPageTitle['default'];
});
define('ember-craft-repository/helpers/permission-helper', ['exports', 'ember'], function (exports, _ember) {
    exports.permissionHelper = permissionHelper;

    function permissionHelper(params) {
        if (params[0] === params[1]) {
            return 'selected';
        }
        return null;
    }

    exports['default'] = _ember['default'].Helper.helper(permissionHelper);
});
// app/helpers/permission-helper.js
define('ember-craft-repository/helpers/pluralize', ['exports', 'ember-inflector/lib/helpers/pluralize'], function (exports, _emberInflectorLibHelpersPluralize) {
  exports['default'] = _emberInflectorLibHelpersPluralize['default'];
});
define('ember-craft-repository/helpers/selected-helper', ['exports', 'ember'], function (exports, _ember) {
    exports.selectedHelper = selectedHelper;

    function selectedHelper(params) {
        if (params[0] === params[1]) {
            return 'selected';
        }
        return null;
    }

    exports['default'] = _ember['default'].Helper.helper(selectedHelper);
});
// app/helpers/permission-helper.js
define('ember-craft-repository/helpers/singularize', ['exports', 'ember-inflector/lib/helpers/singularize'], function (exports, _emberInflectorLibHelpersSingularize) {
  exports['default'] = _emberInflectorLibHelpersSingularize['default'];
});
define('ember-craft-repository/helpers/t', ['exports', 'ember-i18n/helper'], function (exports, _emberI18nHelper) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberI18nHelper['default'];
    }
  });
});
define('ember-craft-repository/helpers/xor', ['exports', 'ember', 'ember-truth-helpers/helpers/xor'], function (exports, _ember, _emberTruthHelpersHelpersXor) {

  var forExport = null;

  if (_ember['default'].Helper) {
    forExport = _ember['default'].Helper.helper(_emberTruthHelpersHelpersXor.xorHelper);
  } else if (_ember['default'].HTMLBars.makeBoundHelper) {
    forExport = _ember['default'].HTMLBars.makeBoundHelper(_emberTruthHelpersHelpersXor.xorHelper);
  }

  exports['default'] = forExport;
});
define('ember-craft-repository/initializers/allow-link-action', ['exports', 'ember-link-action/initializers/allow-link-action'], function (exports, _emberLinkActionInitializersAllowLinkAction) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberLinkActionInitializersAllowLinkAction['default'];
    }
  });
  Object.defineProperty(exports, 'initialize', {
    enumerable: true,
    get: function get() {
      return _emberLinkActionInitializersAllowLinkAction.initialize;
    }
  });
});
define('ember-craft-repository/initializers/app-version', ['exports', 'ember-cli-app-version/initializer-factory', 'ember-craft-repository/config/environment'], function (exports, _emberCliAppVersionInitializerFactory, _emberCraftRepositoryConfigEnvironment) {
  exports['default'] = {
    name: 'App Version',
    initialize: (0, _emberCliAppVersionInitializerFactory['default'])(_emberCraftRepositoryConfigEnvironment['default'].APP.name, _emberCraftRepositoryConfigEnvironment['default'].APP.version)
  };
});
define('ember-craft-repository/initializers/container-debug-adapter', ['exports', 'ember-resolver/container-debug-adapter'], function (exports, _emberResolverContainerDebugAdapter) {
  exports['default'] = {
    name: 'container-debug-adapter',

    initialize: function initialize() {
      var app = arguments[1] || arguments[0];

      app.register('container-debug-adapter:main', _emberResolverContainerDebugAdapter['default']);
      app.inject('container-debug-adapter:main', 'namespace', 'application:main');
    }
  };
});
define('ember-craft-repository/initializers/data-adapter', ['exports', 'ember'], function (exports, _ember) {

  /*
    This initializer is here to keep backwards compatibility with code depending
    on the `data-adapter` initializer (before Ember Data was an addon).
  
    Should be removed for Ember Data 3.x
  */

  exports['default'] = {
    name: 'data-adapter',
    before: 'store',
    initialize: _ember['default'].K
  };
});
define('ember-craft-repository/initializers/ember-data', ['exports', 'ember-data/setup-container', 'ember-data/-private/core'], function (exports, _emberDataSetupContainer, _emberDataPrivateCore) {

  /*
  
    This code initializes Ember-Data onto an Ember application.
  
    If an Ember.js developer defines a subclass of DS.Store on their application,
    as `App.StoreService` (or via a module system that resolves to `service:store`)
    this code will automatically instantiate it and make it available on the
    router.
  
    Additionally, after an application's controllers have been injected, they will
    each have the store made available to them.
  
    For example, imagine an Ember.js application with the following classes:
  
    App.StoreService = DS.Store.extend({
      adapter: 'custom'
    });
  
    App.PostsController = Ember.ArrayController.extend({
      // ...
    });
  
    When the application is initialized, `App.ApplicationStore` will automatically be
    instantiated, and the instance of `App.PostsController` will have its `store`
    property set to that instance.
  
    Note that this code will only be run if the `ember-application` package is
    loaded. If Ember Data is being used in an environment other than a
    typical application (e.g., node.js where only `ember-runtime` is available),
    this code will be ignored.
  */

  exports['default'] = {
    name: 'ember-data',
    initialize: _emberDataSetupContainer['default']
  };
});
define("ember-craft-repository/initializers/ember-i18n", ["exports", "ember-craft-repository/instance-initializers/ember-i18n"], function (exports, _emberCraftRepositoryInstanceInitializersEmberI18n) {
  exports["default"] = {
    name: _emberCraftRepositoryInstanceInitializersEmberI18n["default"].name,

    initialize: function initialize() {
      var application = arguments[1] || arguments[0]; // depending on Ember version
      if (application.instanceInitializer) {
        return;
      }

      _emberCraftRepositoryInstanceInitializersEmberI18n["default"].initialize(application);
    }
  };
});
define('ember-craft-repository/initializers/ember-simple-auth', ['exports', 'ember', 'ember-craft-repository/config/environment', 'ember-simple-auth/configuration', 'ember-simple-auth/initializers/setup-session', 'ember-simple-auth/initializers/setup-session-service'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment, _emberSimpleAuthConfiguration, _emberSimpleAuthInitializersSetupSession, _emberSimpleAuthInitializersSetupSessionService) {
  exports['default'] = {
    name: 'ember-simple-auth',
    initialize: function initialize(registry) {
      var config = _emberCraftRepositoryConfigEnvironment['default']['ember-simple-auth'] || {};
      config.baseURL = _emberCraftRepositoryConfigEnvironment['default'].baseURL;
      _emberSimpleAuthConfiguration['default'].load(config);

      (0, _emberSimpleAuthInitializersSetupSession['default'])(registry);
      (0, _emberSimpleAuthInitializersSetupSessionService['default'])(registry);
    }
  };
});
define('ember-craft-repository/initializers/export-application-global', ['exports', 'ember', 'ember-craft-repository/config/environment'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment) {
  exports.initialize = initialize;

  function initialize() {
    var application = arguments[1] || arguments[0];
    if (_emberCraftRepositoryConfigEnvironment['default'].exportApplicationGlobal !== false) {
      var value = _emberCraftRepositoryConfigEnvironment['default'].exportApplicationGlobal;
      var globalName;

      if (typeof value === 'string') {
        globalName = value;
      } else {
        globalName = _ember['default'].String.classify(_emberCraftRepositoryConfigEnvironment['default'].modulePrefix);
      }

      if (!window[globalName]) {
        window[globalName] = application;

        application.reopen({
          willDestroy: function willDestroy() {
            this._super.apply(this, arguments);
            delete window[globalName];
          }
        });
      }
    }
  }

  exports['default'] = {
    name: 'export-application-global',

    initialize: initialize
  };
});
define('ember-craft-repository/initializers/injectStore', ['exports', 'ember'], function (exports, _ember) {

  /*
    This initializer is here to keep backwards compatibility with code depending
    on the `injectStore` initializer (before Ember Data was an addon).
  
    Should be removed for Ember Data 3.x
  */

  exports['default'] = {
    name: 'injectStore',
    before: 'store',
    initialize: _ember['default'].K
  };
});
define('ember-craft-repository/initializers/responsive', ['exports', 'ember-responsive/initializers/responsive'], function (exports, _emberResponsiveInitializersResponsive) {
  exports['default'] = _emberResponsiveInitializersResponsive['default'];
});
define('ember-craft-repository/initializers/store', ['exports', 'ember'], function (exports, _ember) {

  /*
    This initializer is here to keep backwards compatibility with code depending
    on the `store` initializer (before Ember Data was an addon).
  
    Should be removed for Ember Data 3.x
  */

  exports['default'] = {
    name: 'store',
    after: 'ember-data',
    initialize: _ember['default'].K
  };
});
define('ember-craft-repository/initializers/toastr', ['exports', 'ember-toastr/initializers/toastr', 'ember-craft-repository/config/environment'], function (exports, _emberToastrInitializersToastr, _emberCraftRepositoryConfigEnvironment) {

  var toastrOptions = {
    closeButton: true,
    debug: false,
    newestOnTop: true,
    progressBar: true,
    positionClass: 'toast-top-right',
    preventDuplicates: true,
    onclick: null,
    showDuration: '300',
    hideDuration: '1000',
    timeOut: '4000',
    extendedTimeOut: '1000',
    showEasing: 'swing',
    hideEasing: 'linear',
    showMethod: 'fadeIn',
    hideMethod: 'fadeOut'
  };
  var config = _emberCraftRepositoryConfigEnvironment['default']['ember-toastr'] || {
    injectAs: 'toast',
    toastrOptions: toastrOptions
  };

  exports['default'] = {
    name: 'ember-toastr',
    initialize: function initialize() {
      // support 1.x and 2.x
      var application = arguments[1] || arguments[0];

      if (!config.toastrOptions) {
        config.toastrOptions = toastrOptions;
      }

      if (!config.injectAs) {
        config.injectAs = 'toast';
      }

      (0, _emberToastrInitializersToastr.initialize)(application, config);
    }
  };
});
define('ember-craft-repository/initializers/transforms', ['exports', 'ember'], function (exports, _ember) {

  /*
    This initializer is here to keep backwards compatibility with code depending
    on the `transforms` initializer (before Ember Data was an addon).
  
    Should be removed for Ember Data 3.x
  */

  exports['default'] = {
    name: 'transforms',
    before: 'store',
    initialize: _ember['default'].K
  };
});
define('ember-craft-repository/initializers/truth-helpers', ['exports', 'ember', 'ember-truth-helpers/utils/register-helper', 'ember-truth-helpers/helpers/and', 'ember-truth-helpers/helpers/or', 'ember-truth-helpers/helpers/equal', 'ember-truth-helpers/helpers/not', 'ember-truth-helpers/helpers/is-array', 'ember-truth-helpers/helpers/not-equal', 'ember-truth-helpers/helpers/gt', 'ember-truth-helpers/helpers/gte', 'ember-truth-helpers/helpers/lt', 'ember-truth-helpers/helpers/lte'], function (exports, _ember, _emberTruthHelpersUtilsRegisterHelper, _emberTruthHelpersHelpersAnd, _emberTruthHelpersHelpersOr, _emberTruthHelpersHelpersEqual, _emberTruthHelpersHelpersNot, _emberTruthHelpersHelpersIsArray, _emberTruthHelpersHelpersNotEqual, _emberTruthHelpersHelpersGt, _emberTruthHelpersHelpersGte, _emberTruthHelpersHelpersLt, _emberTruthHelpersHelpersLte) {
  exports.initialize = initialize;

  function initialize() /* container, application */{

    // Do not register helpers from Ember 1.13 onwards, starting from 1.13 they
    // will be auto-discovered.
    if (_ember['default'].Helper) {
      return;
    }

    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('and', _emberTruthHelpersHelpersAnd.andHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('or', _emberTruthHelpersHelpersOr.orHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('eq', _emberTruthHelpersHelpersEqual.equalHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('not', _emberTruthHelpersHelpersNot.notHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('is-array', _emberTruthHelpersHelpersIsArray.isArrayHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('not-eq', _emberTruthHelpersHelpersNotEqual.notEqualHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('gt', _emberTruthHelpersHelpersGt.gtHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('gte', _emberTruthHelpersHelpersGte.gteHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('lt', _emberTruthHelpersHelpersLt.ltHelper);
    (0, _emberTruthHelpersUtilsRegisterHelper.registerHelper)('lte', _emberTruthHelpersHelpersLte.lteHelper);
  }

  exports['default'] = {
    name: 'truth-helpers',
    initialize: initialize
  };
});
define('ember-craft-repository/instance-initializers/browser/head', ['exports', 'ember', 'ember-craft-repository/config/environment'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment) {
  exports.initialize = initialize;

  function initialize(instance) {
    if (_emberCraftRepositoryConfigEnvironment['default']['ember-cli-head'] && _emberCraftRepositoryConfigEnvironment['default']['ember-cli-head']['suppressBrowserRender']) {
      return true;
    }

    // clear fast booted head (if any)
    _ember['default'].$('meta[name="ember-cli-head-start"]').nextUntil('meta[name="ember-cli-head-end"] ~').addBack().remove();
    var container = instance.lookup ? instance : instance.container;
    // const renderer = container.lookup('renderer:-dom');
    var component = container.lookup('component:head-layout');
    component.appendTo(document.head);
  }

  exports['default'] = {
    name: 'head-browser',
    initialize: initialize
  };
});
define("ember-craft-repository/instance-initializers/ember-data", ["exports", "ember-data/-private/instance-initializers/initialize-store-service"], function (exports, _emberDataPrivateInstanceInitializersInitializeStoreService) {
  exports["default"] = {
    name: "ember-data",
    initialize: _emberDataPrivateInstanceInitializersInitializeStoreService["default"]
  };
});
define("ember-craft-repository/instance-initializers/ember-i18n", ["exports", "ember", "ember-i18n/stream", "ember-i18n/legacy-helper", "ember-craft-repository/config/environment"], function (exports, _ember, _emberI18nStream, _emberI18nLegacyHelper, _emberCraftRepositoryConfigEnvironment) {
  exports["default"] = {
    name: 'ember-i18n',

    initialize: function initialize(appOrAppInstance) {
      if (_emberI18nLegacyHelper["default"] != null) {
        (function () {
          // Used for Ember < 1.13
          var i18n = appOrAppInstance.container.lookup('service:i18n');

          i18n.localeStream = new _emberI18nStream["default"](function () {
            return i18n.get('locale');
          });

          _ember["default"].addObserver(i18n, 'locale', i18n, function () {
            this.localeStream.value(); // force the stream to be dirty
            this.localeStream.notify();
          });

          _ember["default"].HTMLBars._registerHelper('t', _emberI18nLegacyHelper["default"]);
        })();
      }
    }
  };
});
define('ember-craft-repository/instance-initializers/ember-osf', ['exports', 'ember-osf/instance-initializers/ember-osf'], function (exports, _emberOsfInstanceInitializersEmberOsf) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfInstanceInitializersEmberOsf['default'];
    }
  });
  Object.defineProperty(exports, 'initialize', {
    enumerable: true,
    get: function get() {
      return _emberOsfInstanceInitializersEmberOsf.initialize;
    }
  });
});
define('ember-craft-repository/instance-initializers/ember-simple-auth', ['exports', 'ember-simple-auth/instance-initializers/setup-session-restoration'], function (exports, _emberSimpleAuthInstanceInitializersSetupSessionRestoration) {
  exports['default'] = {
    name: 'ember-simple-auth',
    initialize: function initialize(instance) {
      (0, _emberSimpleAuthInstanceInitializersSetupSessionRestoration['default'])(instance);
    }
  };
});
define("ember-craft-repository/locales/en-us/config", ["exports"], function (exports) {
    // app/locales/en-us/config.js
    // Ember-I18n includes configuration for common locales. Most users
    // can safely delete this file. Use it if you need to override behavior
    // for a locale or define behavior for a locale that Ember-I18n
    // doesn't know about.
    exports["default"] = {
        // rtl: [true|FALSE],
        //
        // pluralForm: function(count) {
        //   if (count === 0) { return 'zero'; }
        //   if (count === 1) { return 'one'; }
        //   if (count === 2) { return 'two'; }
        //   if (count < 5) { return 'few'; }
        //   if (count >= 5) { return 'many'; }
        //   return 'other';
        // }
    };
});
define('ember-craft-repository/locales/en-us/translations', ['exports'], function (exports) {
    // app/locales/en-us/translations.js
    exports['default'] = {
        login: {
            pageTitle: 'Please Login'
        }
    };
});
define("ember-craft-repository/mirage/config", ["exports"], function (exports) {
  // app/mirage/config.js

  exports["default"] = function () {}

  // These comments are here to help you get started. Feel free to delete them.

  /*
    Config (with defaults).
     Note: these only affect routes defined *after* them!
  */
  // this.urlPrefix = '';    // make this `http://localhost:8080`, for example, if your API is on a different server
  // this.namespace = '';    // make this `api`, for example, if your API is namespaced
  // this.timing = 400;      // delay for each request, automatically set to 0 during testing

  /*
    Route shorthand cheatsheet
  */
  /*
    GET shorthands
     // Collections
    this.get('/contacts');
    this.get('/contacts', 'users');
    this.get('/contacts', ['contacts', 'addresses']);
     // Single objects
    this.get('/contacts/:id');
    this.get('/contacts/:id', 'user');
    this.get('/contacts/:id', ['contact', 'addresses']);
  */

  /*
    POST shorthands
     this.post('/contacts');
    this.post('/contacts', 'user'); // specify the type of resource to be created
  */

  /*
    PUT shorthands
     this.put('/contacts/:id');
    this.put('/contacts/:id', 'user'); // specify the type of resource to be updated
  */

  /*
    DELETE shorthands
     this.del('/contacts/:id');
    this.del('/contacts/:id', 'user'); // specify the type of resource to be deleted
     // Single object + related resources. Make sure parent resource is first.
    this.del('/contacts/:id', ['contact', 'addresses']);
  */

  /*
    Function fallback. Manipulate data in the db via
       - db.{collection}
      - db.{collection}.find(id)
      - db.{collection}.where(query)
      - db.{collection}.update(target, attrs)
      - db.{collection}.remove(target)
     // Example: return a single object with related models
    this.get('/contacts/:id', function(db, request) {
      var contactId = +request.params.id;
       return {
        contact: db.contacts.find(contactId),
        addresses: db.addresses.where({contact_id: contactId})
      };
    });
   */

  /*
  You can optionally export a config that is only loaded during tests
  export function testConfig() {
  
  }
  */
  ;
});
define('ember-craft-repository/mirage/factories/base', ['exports', 'ember-cli-mirage'], function (exports, _emberCliMirage) {
  exports['default'] = _emberCliMirage['default'].Factory.extend({});
});
// app/mirage/factories/base.js
/*, {faker}*/
define("ember-craft-repository/mirage/scenarios/default", ["exports"], function (exports) {
  // app/mirage/scenarios/default.js

  exports["default"] = function () /* server */{

    // Seed your development database using your factories. This
    // data will not be loaded in your tests.

    // server.createList('contact', 10);
  };
});
define('ember-craft-repository/mixins/base', ['exports', 'semantic-ui-ember/mixins/base'], function (exports, _semanticUiEmberMixinsBase) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _semanticUiEmberMixinsBase['default'];
    }
  });
});
define('ember-craft-repository/mixins/commentable', ['exports', 'ember-osf/mixins/commentable'], function (exports, _emberOsfMixinsCommentable) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfMixinsCommentable['default'];
    }
  });
});
define('ember-craft-repository/mixins/link-action', ['exports', 'ember-link-action/mixins/link-action'], function (exports, _emberLinkActionMixinsLinkAction) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberLinkActionMixinsLinkAction['default'];
    }
  });
});
define('ember-craft-repository/mixins/osf-token-login-controller', ['exports', 'ember-osf/mixins/osf-token-login-controller'], function (exports, _emberOsfMixinsOsfTokenLoginController) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfMixinsOsfTokenLoginController['default'];
    }
  });
});
define('ember-craft-repository/mixins/osf-token-login-route', ['exports', 'ember-osf/mixins/osf-token-login-route'], function (exports, _emberOsfMixinsOsfTokenLoginRoute) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfMixinsOsfTokenLoginRoute['default'];
    }
  });
});
define('ember-craft-repository/mixins/paginated-component', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Mixin.create({
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        // TODO: Remove below after testing thoroughly
        // When page numbers are updated, fetch the new results from the server
        // queryParams: {
        //     page: {
        //         refresh: true
        //     },
        //     page_size: {
        //         refresh: true
        //     }
        // },
        // queryParams: ['page', 'page_size'],
        // page: 1,
        // page_size: null,

        // Configure how pagination query params in the frontend map to the query params expected by the API backend
        //  (helps support different APIs). Most users will not need to change this.
        apiArgs: {
            page: 'page',
            page_size: 'page[size]'
        },

        /**
         * @method queryForPage  Fetch a route-specifed page of results from an external API
         * @param modelName The name of the model to query in the store
         * @param routeParams Parameters gictionary available to the model hook; must be passed in manually
         * @param userParams Additional user-specified query parameters
         * @returns {Promise}
         */
        queryForComponent: function queryForComponent(modelName, routeParams, userParams) {
            var _this = this;

            var params = Object.assign({}, userParams || {}, routeParams);

            // Rename parameters to match what the API expects, and remove the old param name if necessary
            var apiArgs = this.get('apiArgs');

            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = Object.keys(apiArgs)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var frontEndParamName = _step.value;

                    var backEndParamName = apiArgs[frontEndParamName];
                    if (params[frontEndParamName]) {
                        params[backEndParamName] = params[frontEndParamName];
                    }
                    if (frontEndParamName !== backEndParamName) {
                        delete params[frontEndParamName];
                    }
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator['return']) {
                        _iterator['return']();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }

            return this.get('store').query(modelName, params).then(function (list) {
                _this.set('list', list);
                _this.set('pagination', list.get('meta.pagination'));

                var totalResults = _ember['default'].computed('list', function () {
                    return list.get('meta.pagination.total');
                });
                _this.set('totalResults', totalResults);

                var totalPages = _ember['default'].computed('list', 'totalResults', function () {
                    var results = this.get('totalResults');
                    var pageSize = list.get('meta.pagination.per_page');
                    return Math.ceil(results / pageSize);
                });
                _this.set('totalPages', totalPages);

                if (_this.page) {
                    _this.set('page', _this.get('page'));
                } else {
                    _this.set('page', 1);
                }
            });
        }
    });
});
// app/mixins/paginated-component.js
define('ember-craft-repository/models/collection', ['exports', 'ember-osf/models/collection'], function (exports, _emberOsfModelsCollection) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsCollection['default'];
    }
  });
});
define('ember-craft-repository/models/comment-report', ['exports', 'ember-osf/models/comment-report'], function (exports, _emberOsfModelsCommentReport) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsCommentReport['default'];
    }
  });
});
define('ember-craft-repository/models/comment', ['exports', 'ember-osf/models/comment'], function (exports, _emberOsfModelsComment) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsComment['default'];
    }
  });
});
define('ember-craft-repository/models/contributor', ['exports', 'ember-osf/models/contributor'], function (exports, _emberOsfModelsContributor) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsContributor['default'];
    }
  });
});
define('ember-craft-repository/models/draft-registration', ['exports', 'ember-osf/models/draft-registration'], function (exports, _emberOsfModelsDraftRegistration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsDraftRegistration['default'];
    }
  });
});
define('ember-craft-repository/models/file-provider', ['exports', 'ember-osf/models/file-provider'], function (exports, _emberOsfModelsFileProvider) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsFileProvider['default'];
    }
  });
});
define('ember-craft-repository/models/file-version', ['exports', 'ember-osf/models/file-version'], function (exports, _emberOsfModelsFileVersion) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsFileVersion['default'];
    }
  });
});
define('ember-craft-repository/models/file', ['exports', 'ember-osf/models/file'], function (exports, _emberOsfModelsFile) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsFile['default'];
    }
  });
});
define('ember-craft-repository/models/institution', ['exports', 'ember-osf/models/institution'], function (exports, _emberOsfModelsInstitution) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsInstitution['default'];
    }
  });
});
define('ember-craft-repository/models/log', ['exports', 'ember-osf/models/log'], function (exports, _emberOsfModelsLog) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsLog['default'];
    }
  });
});
define('ember-craft-repository/models/metaschema', ['exports', 'ember-osf/models/metaschema'], function (exports, _emberOsfModelsMetaschema) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsMetaschema['default'];
    }
  });
});
define('ember-craft-repository/models/node-link', ['exports', 'ember-osf/models/node-link'], function (exports, _emberOsfModelsNodeLink) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsNodeLink['default'];
    }
  });
});
define('ember-craft-repository/models/node', ['exports', 'ember-osf/models/node'], function (exports, _emberOsfModelsNode) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsNode['default'];
    }
  });
});
define('ember-craft-repository/models/osf-model', ['exports', 'ember-osf/models/osf-model'], function (exports, _emberOsfModelsOsfModel) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsOsfModel['default'];
    }
  });
});
define('ember-craft-repository/models/registration', ['exports', 'ember-osf/models/registration'], function (exports, _emberOsfModelsRegistration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsRegistration['default'];
    }
  });
});
define('ember-craft-repository/models/user', ['exports', 'ember-osf/models/user'], function (exports, _emberOsfModelsUser) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfModelsUser['default'];
    }
  });
});
define('ember-craft-repository/pods/allnodes/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin', 'ember-osf/mixins/fetch-all-route'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin, _emberOsfMixinsFetchAllRoute) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], _emberOsfMixinsFetchAllRoute['default'], {
        model: function model() {
            return this.infinityModel('node', {
                perPage: 20
            });
        }
    });
});
// app/pods/allnodes/route.js
define("ember-craft-repository/pods/allnodes/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 3,
              "column": 4
            },
            "end": {
              "line": 5,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/allnodes/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("li");
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 0, 0);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [4, 12], [4, 29]]]]],
        locals: ["project"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 8,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/allnodes/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createTextNode("These are the projects:\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("ol");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        var el2 = dom.createTextNode("Load more");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [3]);
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
        morphs[1] = dom.createElementMorph(element0);
        return morphs;
      },
      statements: [["block", "each", [["get", "model", ["loc", [null, [3, 12], [3, 17]]]]], [], 0, null, ["loc", [null, [3, 4], [5, 13]]]], ["element", "action", ["getMore"], [], ["loc", [null, [7, 8], [7, 28]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/application/controller', ['exports', 'ember', 'ember-osf/mixins/osf-token-login-controller', 'ember-osf/utils/auth'], function (exports, _ember, _emberOsfMixinsOsfTokenLoginController, _emberOsfUtilsAuth) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsOsfTokenLoginController['default'], {
        session: _ember['default'].inject.service(),
        toast: _ember['default'].inject.service(),
        authUrl: (0, _emberOsfUtilsAuth.getAuthUrl)(),
        actions: {
            // TODO: Not being used - Find a way to use it.
            loginFail: function loginFail() /* err */{
                this.get('toast').error('Login failed');
            }
        }
    });
});
// app/pods/application/controller.js
// toggleSidebar: function(subSidebarName) {
//     $('#'+subSidebarName)
//         .sidebar('setting', 'transition', 'push')
//         .sidebar('toggle');
// },
// closeMenu: function() {
//     $('.sidebar').sidebar("toggle");
// }
define('ember-craft-repository/pods/application/route', ['exports', 'ember', 'ember-osf/mixins/osf-token-login-route'], function (exports, _ember, _emberOsfMixinsOsfTokenLoginRoute) {
    exports['default'] = _ember['default'].Route.extend(_emberOsfMixinsOsfTokenLoginRoute['default'], {
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        model: function model() {
            // TODO: Check if session.session is really necessary
            if (this.get('session.isAuthenticated')) {
                return this.get('store').findRecord('user', 'me');
            }
            return null;
        }
    });
});
// app/pods/application/route.js
define("ember-craft-repository/pods/application/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 14,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/application/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/application/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui pushable segment component context");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "pusher");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "main page");
        dom.setAttribute(el3, "role", "main");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [4]);
        var element1 = dom.childAt(element0, [3]);
        var morphs = new Array(5);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(element0, 1, 1);
        morphs[2] = dom.createMorphAt(element1, 1, 1);
        morphs[3] = dom.createMorphAt(dom.childAt(element1, [3]), 1, 1);
        morphs[4] = dom.createMorphAt(element1, 5, 5);
        return morphs;
      },
      statements: [["inline", "page-title", ["Craft Repository"], [], ["loc", [null, [2, 0], [2, 28]]]], ["content", "navbar-sidebar", ["loc", [null, [5, 4], [5, 22]]]], ["content", "navbar-main", ["loc", [null, [7, 8], [7, 23]]]], ["content", "outlet", ["loc", [null, [9, 12], [9, 22]]]], ["content", "footer-main", ["loc", [null, [11, 8], [11, 23]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/collections/detail/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        model: function model(params) {
            return this.store.findRecord('collection', params.collection_id);
        },
        actions: {
            /**
            * Add node to a collection
            *
            * @method addNodeToCollection
            * @param {String} projectId, ID of node (linkedNode) to be added to the collection
            * @return {Promise} Returns a promise that resolves to the updated collection
            * with the new linkedNodes relationship
            */
            addProjectToCollection: function addProjectToCollection(projectId) {
                var _this = this;

                this.store.findRecord('node', projectId).then(function (project) {
                    var collection = _this.modelFor(_this.routeName);
                    collection.get('linkedNodes').pushObject(project);
                    collection.save();
                });
            },
            /**
            * Remove node from a collection
            *
            * @method removeNodeFromCollection
            * @param {Object} project Node(linkedNode) relationship to be removed from collection
            * @return {Promise} Returns a promise that resolves to the updated collection
            * with the linkedNode relationship removed.  The node itself is not removed.
            */
            removeProjectFromCollection: function removeProjectFromCollection(project) {
                var collection = this.modelFor(this.routeName);
                collection.get('linkedNodes').removeObject(project);
                collection.save();
            }
        }
    });
});
// app/pods/collections/detail/route.js
define("ember-craft-repository/pods/collections/detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 18,
              "column": 8
            },
            "end": {
              "line": 24,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/collections/detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode(" ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode(" ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-danger");
          var el4 = dom.createTextNode("Remove project");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode(" ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [5, 0]);
          var morphs = new Array(3);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 0, 0);
          morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 0, 0);
          morphs[2] = dom.createElementMorph(element1);
          return morphs;
        },
        statements: [["inline", "link-to", [["get", "linkedProject.title", ["loc", [null, [20, 30], [20, 49]]]], "projects.detail", ["get", "linkedProject.id", ["loc", [null, [20, 68], [20, 84]]]]], [], ["loc", [null, [20, 20], [20, 87]]]], ["inline", "moment-format", [["get", "linkedProject.dateModified", ["loc", [null, [21, 36], [21, 62]]]]], [], ["loc", [null, [21, 20], [21, 64]]]], ["element", "action", ["removeProjectFromCollection", ["get", "linkedProject", ["loc", [null, [22, 67], [22, 80]]]]], [], ["loc", [null, [22, 28], [22, 82]]]]],
        locals: ["linkedProject"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 33,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/collections/detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/collections/detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "panel");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h3");
        var el3 = dom.createTextNode(" Collection Details ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Title:");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode(" ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Date created:");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode(" ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Date modified:");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode(" ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Bookmark:");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode(" ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h3");
        var el3 = dom.createTextNode(" Collection Contents ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("table");
        dom.setAttribute(el2, "class", "table");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("tr");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode(" Name ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode(" Date Modified ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode(" ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h3");
        var el3 = dom.createTextNode("Add project to collection");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("label");
        var el3 = dom.createTextNode(" Project id ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode(" ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("button");
        dom.setAttribute(el2, "class", "btn btn-primary");
        var el3 = dom.createTextNode("Add");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element2 = dom.childAt(fragment, [6]);
        var element3 = dom.childAt(element2, [21]);
        var morphs = new Array(9);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(dom.childAt(element2, [3]), 2, 2);
        morphs[3] = dom.createMorphAt(dom.childAt(element2, [5]), 2, 2);
        morphs[4] = dom.createMorphAt(dom.childAt(element2, [7]), 2, 2);
        morphs[5] = dom.createMorphAt(dom.childAt(element2, [9]), 2, 2);
        morphs[6] = dom.createMorphAt(dom.childAt(element2, [13]), 3, 3);
        morphs[7] = dom.createMorphAt(element2, 19, 19);
        morphs[8] = dom.createElementMorph(element3);
        return morphs;
      },
      statements: [["inline", "page-title", [["get", "model.title", ["loc", [null, [2, 8], [2, 19]]]]], [], ["loc", [null, [2, 0], [2, 21]]]], ["inline", "link-to", ["Back to list", "collections"], ["class", "btn btn-default"], ["loc", [null, [3, 0], [3, 64]]]], ["content", "model.title", ["loc", [null, [6, 29], [6, 44]]]], ["inline", "moment-format", [["get", "model.dateCreated", ["loc", [null, [7, 52], [7, 69]]]]], [], ["loc", [null, [7, 36], [7, 71]]]], ["inline", "moment-format", [["get", "model.dateModified", ["loc", [null, [8, 53], [8, 71]]]]], [], ["loc", [null, [8, 37], [8, 73]]]], ["content", "model.bookmarks", ["loc", [null, [9, 32], [9, 51]]]], ["block", "each", [["get", "model.linkedNodes", ["loc", [null, [18, 16], [18, 33]]]]], [], 0, null, ["loc", [null, [18, 8], [24, 17]]]], ["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "projectId", ["loc", [null, [28, 46], [28, 55]]]]], [], []]], ["loc", [null, [28, 32], [28, 57]]]], ["element", "action", ["addProjectToCollection", ["get", "projectId", ["loc", [null, [29, 46], [29, 55]]]]], [], ["loc", [null, [29, 12], [29, 57]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/collections/index/controller', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Controller.extend({
        actions: {
            /**
            * Create a collection
            *
            * @method createCollection
            * @param {String} title Title for collection
            * @return {Promise} Returns a promise that resolves to the new collection.
            */
            createCollection: function createCollection(title) {
                var collection = this.store.createRecord('collection', {
                    title: title
                });
                collection.save();
            }
        }
    });
});
// app/pods/collections/index/controller.js
define("ember-craft-repository/pods/collections/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 13,
              "column": 4
            },
            "end": {
              "line": 19,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/collections/index/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("Title: ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("Date created: ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("Date modified: ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("hr");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(fragment, [5]), 1, 1);
          morphs[3] = dom.createMorphAt(fragment, 7, 7, contextualElement);
          return morphs;
        },
        statements: [["content", "collection.title", ["loc", [null, [14, 18], [14, 38]]]], ["inline", "moment-format", [["get", "collection.dateCreated", ["loc", [null, [15, 41], [15, 63]]]]], [], ["loc", [null, [15, 25], [15, 65]]]], ["inline", "moment-format", [["get", "collection.dateModified", ["loc", [null, [16, 42], [16, 65]]]]], [], ["loc", [null, [16, 26], [16, 67]]]], ["inline", "link-to", ["Detail", "collections.detail", ["get", "collection.id", ["loc", [null, [17, 48], [17, 61]]]]], ["class", "btn btn-primary"], ["loc", [null, [17, 8], [17, 87]]]]],
        locals: ["collection"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 21,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/collections/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/collections/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h4");
        var el2 = dom.createTextNode("Collections");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h5");
        var el3 = dom.createTextNode("Create Collection");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("button");
        var el3 = dom.createTextNode("Create");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("hr");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h5");
        var el3 = dom.createTextNode("Collections list");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [6]);
        var element1 = dom.childAt(element0, [5]);
        var morphs = new Array(4);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(element0, 3, 3);
        morphs[2] = dom.createElementMorph(element1);
        morphs[3] = dom.createMorphAt(dom.childAt(fragment, [10]), 3, 3);
        return morphs;
      },
      statements: [["inline", "page-title", ["Collections"], [], ["loc", [null, [2, 0], [2, 23]]]], ["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "title", ["loc", [null, [7, 18], [7, 23]]]]], [], []], "placeholder", "Collection's title", "required", true], ["loc", [null, [7, 4], [7, 72]]]], ["element", "action", ["createCollection", ["get", "title", ["loc", [null, [8, 40], [8, 45]]]]], [], ["loc", [null, [8, 12], [8, 47]]]], ["block", "each", [["get", "model", ["loc", [null, [13, 12], [13, 17]]]]], [], 0, null, ["loc", [null, [13, 4], [19, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define("ember-craft-repository/pods/collections/loading/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/collections/loading/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/loading/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active centered large text inline loader");
        var el2 = dom.createTextNode("Loading");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/collections/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        model: function model() {
            return this.get('store').findAll('collection');
        }
    });
});
// app/pod/collections/route.js
define("ember-craft-repository/pods/collections/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/collections/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pod/collections/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/comment-detail/component', ['exports', 'ember-osf/components/comment-detail/component', 'ember-craft-repository/pods/components/comment-detail/template', 'ember'], function (exports, _emberOsfComponentsCommentDetailComponent, _emberCraftRepositoryPodsComponentsCommentDetailTemplate, _ember) {
    exports['default'] = _emberOsfComponentsCommentDetailComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsCommentDetailTemplate['default'],
        tagName: '',
        classNames: ['comment', 'detail'],
        toast: _ember['default'].inject.service(),
        store: _ember['default'].inject.service(),
        isEditable: false,
        // TODO: Very slot finding username and gravatarUrl.  Needs reworked.
        commentUserFullName: _ember['default'].computed('comment', function () {
            var _this = this;

            // console.log(this.get('comment'));
            this.get('comment.user').then(function (user) {
                // console.log(user.get('fullName'));
                if (_this.isDestroyed) {
                    return;
                }
                _this.set('commentUserFullName', user.get('fullName'));
            });
        }),
        gravatarUrl: _ember['default'].computed('comment', function () {
            var _this2 = this;

            var imgLink = '';
            this.get('comment.user').then(function (user) {
                imgLink = user.get('links.profile_image');
                // console.log(imgLink);
                if (imgLink) {
                    imgLink += '&s=25';
                }
                if (_this2.isDestroyed) {
                    return;
                }
                _this2.set('gravatarUrl', imgLink);
            });
        }),
        actions: {
            reportComment: function reportComment(comment) {
                this.sendAction('reportComment', comment);
            },
            toggleEdit: function toggleEdit() {
                this.set('isEditable', true);
            },
            deleteComment: function deleteComment(comment) {
                this.sendActiom('delete', comment);
            },
            editComment: function editComment(comment) {
                this.sendAction('editComment', comment);
                this.set('isEditable', false);
                this.get('toast').success("You comment has been edited");
            }
        }
    });
});
// app/pods/components/comment-detail/component.js
define("ember-craft-repository/pods/components/comment-detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 7,
                "column": 16
              },
              "end": {
                "line": 9,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("button");
            dom.setAttribute(el1, "class", "ui yellow button");
            var el2 = dom.createTextNode("Restore");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element6 = dom.childAt(fragment, [1]);
            var morphs = new Array(1);
            morphs[0] = dom.createElementMorph(element6);
            return morphs;
          },
          statements: [["element", "action", [["get", "restoreComment", ["loc", [null, [8, 37], [8, 51]]]], ["get", "comment", ["loc", [null, [8, 52], [8, 59]]]]], [], ["loc", [null, [8, 28], [8, 61]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 4,
              "column": 8
            },
            "end": {
              "line": 11,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          var el2 = dom.createTextNode("\n                Comment deleted\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
          return morphs;
        },
        statements: [["block", "if", [["get", "comment.canEdit", ["loc", [null, [7, 23], [7, 38]]]]], [], 0, null, ["loc", [null, [7, 16], [9, 23]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 26,
                  "column": 20
                },
                "end": {
                  "line": 33,
                  "column": 20
                }
              },
              "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                        ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("div");
              dom.setAttribute(el1, "class", "text");
              var el2 = dom.createTextNode("\n                            ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                        ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n                        ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("div");
              dom.setAttribute(el1, "class", "actions");
              var el2 = dom.createTextNode("\n                            ");
              dom.appendChild(el1, el2);
              var el2 = dom.createElement("a");
              dom.setAttribute(el2, "class", "ui tiny button");
              var el3 = dom.createTextNode("Save");
              dom.appendChild(el2, el3);
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                        ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element3 = dom.childAt(fragment, [3, 1]);
              var morphs = new Array(2);
              morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
              morphs[1] = dom.createElementMorph(element3);
              return morphs;
            },
            statements: [["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "comment.content", ["loc", [null, [28, 42], [28, 57]]]]], [], []]], ["loc", [null, [28, 28], [28, 59]]]], ["element", "action", ["editComment", ["get", "comment", ["loc", [null, [31, 77], [31, 84]]]]], [], ["loc", [null, [31, 54], [31, 86]]]]],
            locals: [],
            templates: []
          };
        })();
        var child1 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 33,
                  "column": 20
                },
                "end": {
                  "line": 43,
                  "column": 20
                }
              },
              "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                        ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("div");
              dom.setAttribute(el1, "class", "text");
              var el2 = dom.createTextNode("\n                            ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                        ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n                        ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("div");
              dom.setAttribute(el1, "class", "actions");
              var el2 = dom.createTextNode("\n                            ");
              dom.appendChild(el1, el2);
              var el2 = dom.createElement("a");
              dom.setAttribute(el2, "class", "ui tiny button");
              var el3 = dom.createTextNode("Edit");
              dom.appendChild(el2, el3);
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                            ");
              dom.appendChild(el1, el2);
              var el2 = dom.createElement("a");
              dom.setAttribute(el2, "class", "ui tiny button");
              var el3 = dom.createTextNode("Delete");
              dom.appendChild(el2, el3);
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                            ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment(" TODO: Add ability to reply ");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("                        ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element0 = dom.childAt(fragment, [3]);
              var element1 = dom.childAt(element0, [1]);
              var element2 = dom.childAt(element0, [3]);
              var morphs = new Array(3);
              morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
              morphs[1] = dom.createElementMorph(element1);
              morphs[2] = dom.createElementMorph(element2);
              return morphs;
            },
            statements: [["content", "comment.content", ["loc", [null, [35, 28], [35, 47]]]], ["element", "action", ["toggleEdit"], [], ["loc", [null, [38, 54], [38, 77]]]], ["element", "action", ["deleteComment", ["get", "comment", ["loc", [null, [39, 79], [39, 86]]]]], [], ["loc", [null, [39, 54], [39, 88]]]]],
            locals: [],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 25,
                "column": 16
              },
              "end": {
                "line": 44,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
            dom.insertBoundary(fragment, 0);
            dom.insertBoundary(fragment, null);
            return morphs;
          },
          statements: [["block", "if", [["get", "isEditable", ["loc", [null, [26, 26], [26, 36]]]]], [], 0, 1, ["loc", [null, [26, 20], [43, 27]]]]],
          locals: [],
          templates: [child0, child1]
        };
      })();
      var child1 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 44,
                "column": 16
              },
              "end": {
                "line": 55,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "text");
            var el2 = dom.createTextNode("\n                        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "actions");
            var el2 = dom.createTextNode("\n                        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment(" TODO: reportComment not yet possible ");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("                        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment(" TODO: Add ability to reply ");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            return morphs;
          },
          statements: [["content", "comment.content", ["loc", [null, [46, 24], [46, 43]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 11,
              "column": 8
            },
            "end": {
              "line": 116,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("a");
          dom.setAttribute(el1, "class", "avatar");
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment(" TODO: Add customer avatar helper ");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("img");
          dom.setAttribute(el2, "class", "ui avatar image");
          dom.setAttribute(el2, "alt", "User gravatar");
          dom.setAttribute(el2, "width", "25px");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "content");
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment(" TODO: Add Author Helper ");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("a");
          dom.setAttribute(el2, "class", "author");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment(" TODO: Add More Metadata? ");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "metadata");
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment(" TODO: Add Logic to have nested comments when user replies (See Semantic \"Threaded Comments\") ");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("                                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment(" TODO: reportComment not yet possible ");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("                                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment(" TODO: Add ability to reply ");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element4 = dom.childAt(fragment, [1, 4]);
          var element5 = dom.childAt(fragment, [3]);
          var morphs = new Array(4);
          morphs[0] = dom.createAttrMorph(element4, 'src');
          morphs[1] = dom.createMorphAt(dom.childAt(element5, [3]), 0, 0);
          morphs[2] = dom.createMorphAt(dom.childAt(element5, [7]), 1, 1);
          morphs[3] = dom.createMorphAt(element5, 9, 9);
          return morphs;
        },
        statements: [["attribute", "src", ["concat", [["get", "gravatarUrl", ["loc", [null, [15, 52], [15, 63]]]]]]], ["content", "commentUserFullName", ["loc", [null, [19, 34], [19, 57]]]], ["inline", "moment-from-now", [["get", "comment.dateCreated", ["loc", [null, [22, 38], [22, 57]]]]], [], ["loc", [null, [22, 20], [22, 59]]]], ["block", "if", [["get", "comment.canEdit", ["loc", [null, [25, 22], [25, 37]]]]], [], 0, 1, ["loc", [null, [25, 16], [55, 23]]]]],
        locals: [],
        templates: [child0, child1]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 119,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/comment-detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/comment-detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui comments");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "comment");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [2, 1]), 1, 1);
        return morphs;
      },
      statements: [["block", "if", [["get", "comment.deleted", ["loc", [null, [4, 14], [4, 29]]]]], [], 0, 1, ["loc", [null, [4, 8], [116, 15]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/comment-form/component', ['exports', 'ember-osf/components/comment-form/component', 'ember-craft-repository/pods/components/comment-form/template'], function (exports, _emberOsfComponentsCommentFormComponent, _emberCraftRepositoryPodsComponentsCommentFormTemplate) {
    exports['default'] = _emberOsfComponentsCommentFormComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsCommentFormTemplate['default'],
        tagName: '',
        classNames: ['comment', 'form']
    });
});
// app/pods/components/comment-form/component.js
define("ember-craft-repository/pods/components/comment-form/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 12,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/comment-form/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/comment-form/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui form");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui field");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui field");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("button");
        dom.setAttribute(el3, "class", "ui green button");
        var el4 = dom.createTextNode("\n           ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("i");
        dom.setAttribute(el4, "class", "chat icon");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode(" Add comment\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var element1 = dom.childAt(element0, [3, 1]);
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
        morphs[1] = dom.createAttrMorph(element1, 'disabled');
        morphs[2] = dom.createElementMorph(element1);
        return morphs;
      },
      statements: [["inline", "textarea", [], ["maxlength", "500", "rows", "2", "placeholder", "Add a comment", "value", ["subexpr", "@mut", [["get", "_commentText", ["loc", [null, [4, 78], [4, 90]]]]], [], []]], ["loc", [null, [4, 8], [4, 92]]]], ["attribute", "disabled", ["subexpr", "if", [["subexpr", "not", [["get", "_commentText", ["loc", [null, [7, 96], [7, 108]]]]], [], ["loc", [null, [7, 91], [7, 109]]]], true], [], ["loc", [null, [7, 86], [7, 116]]]]], ["element", "action", ["addComment", ["get", "_commentText", ["loc", [null, [7, 38], [7, 50]]]]], [], ["loc", [null, [7, 16], [7, 52]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/comment-pane/component', ['exports', 'ember-osf/components/comment-pane/component', 'ember-craft-repository/pods/components/comment-pane/template'], function (exports, _emberOsfComponentsCommentPaneComponent, _emberCraftRepositoryPodsComponentsCommentPaneTemplate) {
    exports['default'] = _emberOsfComponentsCommentPaneComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsCommentPaneTemplate['default'],
        tagName: '',
        classNames: ['comment', 'pane', 'ui', 'segments']
    });
});
// app/pods/components/comment-pane/component.js
define("ember-craft-repository/pods/components/comment-pane/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 8,
              "column": 12
            },
            "end": {
              "line": 15,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/components/comment-pane/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["inline", "comment-detail", [], ["comment", ["subexpr", "@mut", [["get", "comment", ["loc", [null, [10, 24], [10, 31]]]]], [], []], "editComment", ["subexpr", "@mut", [["get", "attrs.editComment", ["loc", [null, [11, 28], [11, 45]]]]], [], []], "deleteComment", ["subexpr", "@mut", [["get", "attrs.deleteComment", ["loc", [null, [12, 30], [12, 49]]]]], [], []], "restoreComment", ["subexpr", "@mut", [["get", "attrs.restoreComment", ["loc", [null, [13, 31], [13, 51]]]]], [], []], "reportComment", ["subexpr", "@mut", [["get", "attrs.reportComment", ["loc", [null, [14, 30], [14, 49]]]]], [], []]], ["loc", [null, [9, 16], [14, 51]]]]],
        locals: ["comment"],
        templates: []
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 15,
              "column": 12
            },
            "end": {
              "line": 17,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/components/comment-pane/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                (none)\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 25,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/comment-pane/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/comment-pane/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segments");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("h4");
        dom.setAttribute(el3, "class", "ui header");
        var el4 = dom.createTextNode("Comments");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        dom.setAttribute(el2, "style", "height: 300px; overflow-y: scroll;");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui threaded comments");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(dom.childAt(element0, [3, 1]), 1, 1);
        morphs[1] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
        return morphs;
      },
      statements: [["block", "each", [["get", "comments", ["loc", [null, [8, 20], [8, 28]]]]], [], 0, 1, ["loc", [null, [8, 12], [17, 21]]]], ["inline", "comment-form", [], ["addComment", ["subexpr", "@mut", [["get", "attrs.addComment", ["loc", [null, [22, 34], [22, 50]]]]], [], []]], ["loc", [null, [22, 8], [22, 52]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/contrib-add/component', ['exports', 'ember', 'ember-craft-repository/pods/components/contrib-add/template', 'ember-osf/const/permissions'], function (exports, _ember, _emberCraftRepositoryPodsComponentsContribAddTemplate, _emberOsfConstPermissions) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsContribAddTemplate['default'],
        tagName: '',
        classNames: ['contrib', 'add'],
        toast: _ember['default'].inject.service(),
        READ: _emberOsfConstPermissions['default'].READ,
        WRITE: _emberOsfConstPermissions['default'].WRITE,
        ADMIN: _emberOsfConstPermissions['default'].ADMIN,
        newContributorPermissions: {},
        newContributorIsBibliographic: {},
        init: function init() {
            this._super.apply(this, arguments);
        },
        actions: {
            requestContribAdd: function requestContribAdd(name) {
                // jshint ignore:line
                $('.ui.modal.contrib.add').modal('setting', 'closable', false).modal('show'); // jshint ignore:line
            },
            addContributor: function addContributor(userId, permission, isBibliographic, sendMail) {
                // TODO: Reset values after you addContributor and refresh
                // console.log('1', userId, permission, isBibliographic, sendMail);
                this.sendAction('addContributor', userId, permission, isBibliographic, sendMail);
            },
            cancelContribAdd: function cancelContribAdd(name) {
                // jshint ignore:line
                this.set('newContributorId', '');
                this.set('newContributorPermissions', '');
                this.set('newContributorIsBibliographic', '');
                $('.ui.modal.contrib.add').modal().modal('hide'); // jshint ignore:line
            },
            permissionsChange: function permissionsChange(component) {
                this.set('newContributorPermissions', component);
            },
            isBibliographicChange: function isBibliographicChange(value) {
                this.set('newContributorIsBibliographic', value);
            }
        }
    });
});
// app/pods/components/contrib-add/component.js
define("ember-craft-repository/pods/components/contrib-add/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 8,
              "column": 0
            },
            "end": {
              "line": 73,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/contrib-add/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "close icon");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "header");
          var el2 = dom.createTextNode("\n        Add Contributor?\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "content");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui stackable grid");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "sixteen wide column");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          dom.setAttribute(el4, "class", "bold");
          var el5 = dom.createTextNode("User ID:");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "ui fluid input");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "two column row");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "column");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "ui fluid input");
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          var el6 = dom.createElement("div");
          dom.setAttribute(el6, "class", "ui inline fields");
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("label");
          dom.setAttribute(el7, "for", "permision");
          var el8 = dom.createTextNode("Permissions");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("div");
          dom.setAttribute(el7, "class", "field");
          var el8 = dom.createTextNode("\n                                ");
          dom.appendChild(el7, el8);
          var el8 = dom.createComment("");
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                            ");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("div");
          dom.setAttribute(el7, "class", "field");
          var el8 = dom.createTextNode("\n                                ");
          dom.appendChild(el7, el8);
          var el8 = dom.createComment("");
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                            ");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("div");
          dom.setAttribute(el7, "class", "field");
          var el8 = dom.createTextNode("\n                                ");
          dom.appendChild(el7, el8);
          var el8 = dom.createComment("");
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                            ");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                        ");
          dom.appendChild(el6, el7);
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                    ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "column");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("label");
          dom.setAttribute(el5, "for", "bibliographic");
          var el6 = dom.createTextNode("Bibliographic");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "ui fluid input");
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          var el6 = dom.createElement("div");
          dom.setAttribute(el6, "class", "ui inline fields");
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("div");
          dom.setAttribute(el7, "class", "field");
          var el8 = dom.createTextNode("\n                                ");
          dom.appendChild(el7, el8);
          var el8 = dom.createComment("");
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                            ");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("div");
          dom.setAttribute(el7, "class", "field");
          var el8 = dom.createTextNode("\n                                ");
          dom.appendChild(el7, el8);
          var el8 = dom.createComment("");
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                            ");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                        ");
          dom.appendChild(el6, el7);
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                    ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "actions");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui black cancel button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "close icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Cancel\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui green approve right labeled icon button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "checkmark icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Add\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [5, 1]);
          var element1 = dom.childAt(element0, [3]);
          var element2 = dom.childAt(element1, [1, 1, 1]);
          var element3 = dom.childAt(element1, [3, 3, 1]);
          var element4 = dom.childAt(fragment, [7]);
          var element5 = dom.childAt(element4, [1]);
          var element6 = dom.childAt(element4, [3]);
          var morphs = new Array(8);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 3]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element2, [3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element2, [5]), 1, 1);
          morphs[3] = dom.createMorphAt(dom.childAt(element2, [7]), 1, 1);
          morphs[4] = dom.createMorphAt(dom.childAt(element3, [1]), 1, 1);
          morphs[5] = dom.createMorphAt(dom.childAt(element3, [3]), 1, 1);
          morphs[6] = dom.createElementMorph(element5);
          morphs[7] = dom.createElementMorph(element6);
          return morphs;
        },
        statements: [["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "newContributorId", ["loc", [null, [18, 46], [18, 62]]]]], [], []], "placeholder", "User ID", "required", true], ["loc", [null, [18, 20], [18, 100]]]], ["inline", "ui-radio", [], ["name", "newContributorPermissions", "value", ["subexpr", "@mut", [["get", "READ", ["loc", [null, [27, 82], [27, 86]]]]], [], []], "label", "Read", "current", ["subexpr", "@mut", [["get", "newContributorPermissions", ["loc", [null, [28, 44], [28, 69]]]]], [], []], "onChange", ["subexpr", "action", ["permissionsChange"], ["value", ["get", "target.value", ["loc", [null, [29, 79], [29, 91]]]]], ["loc", [null, [29, 45], [29, 92]]]]], ["loc", [null, [27, 32], [29, 94]]]], ["inline", "ui-radio", [], ["name", "newContributorPermissions", "value", ["subexpr", "@mut", [["get", "WRITE", ["loc", [null, [32, 82], [32, 87]]]]], [], []], "label", "Read + Write", "current", ["subexpr", "@mut", [["get", "newContributorPermissions", ["loc", [null, [33, 44], [33, 69]]]]], [], []], "onChange", ["subexpr", "action", ["permissionsChange"], ["value", ["get", "target.value", ["loc", [null, [34, 79], [34, 91]]]]], ["loc", [null, [34, 45], [34, 92]]]]], ["loc", [null, [32, 32], [34, 94]]]], ["inline", "ui-radio", [], ["name", "newContributorPermissions", "value", ["subexpr", "@mut", [["get", "ADMIN", ["loc", [null, [37, 82], [37, 87]]]]], [], []], "label", "Administrator", "current", ["subexpr", "@mut", [["get", "newContributorPermissions", ["loc", [null, [38, 44], [38, 69]]]]], [], []], "onChange", ["subexpr", "action", ["permissionsChange"], ["value", ["get", "target.value", ["loc", [null, [39, 79], [39, 91]]]]], ["loc", [null, [39, 45], [39, 92]]]]], ["loc", [null, [37, 32], [39, 94]]]], ["inline", "ui-radio", [], ["name", "newContributorIsBibliographic", "value", true, "label", "Bibliographic", "current", ["subexpr", "@mut", [["get", "newContributorIsBibliographic", ["loc", [null, [50, 44], [50, 73]]]]], [], []], "onChange", ["subexpr", "action", ["isBibliographicChange"], ["value", ["get", "target.value", ["loc", [null, [51, 83], [51, 95]]]]], ["loc", [null, [51, 45], [51, 96]]]]], ["loc", [null, [49, 32], [51, 98]]]], ["inline", "ui-radio", [], ["name", "newContributorIsBibliographic", "value", false, "label", "Non-Bibliographic", "current", ["subexpr", "@mut", [["get", "newContributorIsBibliographic", ["loc", [null, [55, 44], [55, 73]]]]], [], []], "onChange", ["subexpr", "action", ["isBibliographicChange"], ["value", ["get", "target.value", ["loc", [null, [56, 83], [56, 95]]]]], ["loc", [null, [56, 45], [56, 96]]]]], ["loc", [null, [54, 32], [56, 98]]]], ["element", "action", ["cancelContribAdd", "project-create"], [], ["loc", [null, [65, 47], [65, 93]]]], ["element", "action", ["addContributor", ["get", "newContributorId", ["loc", [null, [69, 38], [69, 54]]]], ["get", "newContributorPermissions", ["loc", [null, [69, 55], [69, 80]]]], ["get", "newContributorIsBibliographic", ["loc", [null, [69, 81], [69, 110]]]]], [], ["loc", [null, [69, 12], [69, 112]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 74,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/contrib-add/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/contrib-add/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        dom.setAttribute(el1, "class", "ui blue button");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("i");
        dom.setAttribute(el2, "class", "plus icon");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("Add Contributor\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element7 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createElementMorph(element7);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["element", "action", ["requestContribAdd", "contrib-add"], [], ["loc", [null, [3, 31], [3, 75]]]], ["block", "ui-modal", [], ["name", "contrib-add", "class", "contrib add"], 0, null, ["loc", [null, [8, 0], [73, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/contrib-manager/component', ['exports', 'ember', 'ember-craft-repository/pods/components/contrib-manager/template', 'ember-osf/const/permissions'], function (exports, _ember, _emberCraftRepositoryPodsComponentsContribManagerTemplate, _emberOsfConstPermissions) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsContribManagerTemplate['default'],
        tagName: '',
        classNames: ['contributor', 'manager', 'ui', 'segments'],
        toast: _ember['default'].inject.service(),
        READ: _emberOsfConstPermissions['default'].READ,
        WRITE: _emberOsfConstPermissions['default'].WRITE,
        ADMIN: _emberOsfConstPermissions['default'].ADMIN,
        updatedContributorPermissions: {},
        updatedContributorIsBibliographic: {},
        permissions: null,
        init: function init() {
            this._super.apply(this, arguments);

            var permissions = [{
                "value": this.get('ADMIN'),
                "description": "Administrator"
            }, {
                "value": this.get('READ'),
                "description": "Read"
            }, {
                "value": this.get('WRITE'),
                "description": "Read + Write"
            }];

            this.set('permissions', permissions);
        },
        actions: {
            removeContributor: function removeContributor(contrib) {
                this.sendAction('removeContributor', contrib);
            },
            permissionsUpdate: function permissionsUpdate(contributor, permission) {
                this.set('updatedContributorPermissions.' + contributor.id, permission.toLowerCase());
            },
            isBibliographicUpdate: function isBibliographicUpdate(contributor, isBibliographic) {
                this.set('updatedContributorIsBibliographic.' + contributor.id, isBibliographic);
            },
            updateContributors: function updateContributors() {
                // TODO:10 Should test PUT or PATCH and errors for not being admin
                this.sendAction('editContributors', this.get('contributors'), this.get('updatedContributorPermissions'), this.get('updatedContributorIsBibliographic'));
                // TODO: Called even it it isn't updated successfully.  No error check.
                this.get('toast').success('Contributor updated successfully!');
            },
            addContributor: function addContributor(userId, permission, isBibliographic, sendMail) {
                this.sendAction('addContributor', userId, permission, isBibliographic, sendMail);
                // TODO: Called even it it isn't updated successfully.  No error check.
                this.get('toast').success('Contributor added successfully!');
            }
        }
    });
});
// app/pods/components/contrib-manager/component.js
define("ember-craft-repository/pods/components/contrib-manager/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 43,
                  "column": 32
                },
                "end": {
                  "line": 47,
                  "column": 32
                }
              },
              "moduleName": "ember-craft-repository/pods/components/contrib-manager/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                                    ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("div");
              dom.setAttribute(el1, "class", "item");
              var el2 = dom.createTextNode("\n                                        ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                                    ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element0 = dom.childAt(fragment, [1]);
              var morphs = new Array(2);
              morphs[0] = dom.createAttrMorph(element0, 'data-value');
              morphs[1] = dom.createMorphAt(element0, 1, 1);
              return morphs;
            },
            statements: [["attribute", "data-value", ["concat", [["subexpr", "map-value", [["get", "mapper", ["loc", [null, [44, 78], [44, 84]]]], ["get", "permission.value", ["loc", [null, [44, 85], [44, 101]]]]], [], ["loc", [null, [44, 66], [44, 103]]]]]]], ["content", "permission.description", ["loc", [null, [45, 40], [45, 66]]]]],
            locals: ["permission"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 36,
                "column": 24
              },
              "end": {
                "line": 49,
                "column": 24
              }
            },
            "moduleName": "ember-craft-repository/pods/components/contrib-manager/template.hbs"
          },
          isEmpty: false,
          arity: 2,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "default text");
            var el2 = dom.createTextNode("\n                                ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                            ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "dropdown icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "menu");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("                            ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(2);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            morphs[1] = dom.createMorphAt(dom.childAt(fragment, [5]), 1, 1);
            return morphs;
          },
          statements: [["content", "contributor.permission", ["loc", [null, [39, 32], [39, 58]]]], ["block", "each", [["get", "permissions", ["loc", [null, [43, 40], [43, 51]]]]], [], 0, null, ["loc", [null, [43, 32], [47, 41]]]]],
          locals: ["execute", "mapper"],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 26,
              "column": 12
            },
            "end": {
              "line": 62,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/components/contrib-manager/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "ui red button");
          var el4 = dom.createTextNode("\n                            Remove\n                        ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element1 = dom.childAt(fragment, [1]);
          var element2 = dom.childAt(element1, [9, 1]);
          var morphs = new Array(5);
          morphs[0] = dom.createMorphAt(dom.childAt(element1, [1]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element1, [3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element1, [5]), 1, 1);
          morphs[3] = dom.createMorphAt(dom.childAt(element1, [7]), 1, 1);
          morphs[4] = dom.createElementMorph(element2);
          return morphs;
        },
        statements: [["content", "contributor.id", ["loc", [null, [29, 24], [29, 42]]]], ["inline", "if", [["get", "contributor.unregisteredContributor", ["loc", [null, [32, 29], [32, 64]]]], ["get", "contributors.unregisteredContributor", ["loc", [null, [32, 65], [32, 101]]]], ["get", "contributor.users.fullName", ["loc", [null, [33, 28], [33, 54]]]]], [], ["loc", [null, [32, 24], [33, 56]]]], ["block", "ui-dropdown", [], ["class", "selection", "selected", ["subexpr", "@mut", [["get", "contributor.permission", ["loc", [null, [36, 66], [36, 88]]]]], [], []], "onChange", ["subexpr", "action", ["permissionsUpdate", ["get", "contributor", ["loc", [null, [37, 65], [37, 76]]]]], [], ["loc", [null, [37, 37], [37, 77]]]]], 0, null, ["loc", [null, [36, 24], [49, 40]]]], ["inline", "ui-checkbox", [], ["class", "ui checkbox", "onChange", ["subexpr", "action", ["isBibliographicUpdate", ["get", "contributor", ["loc", [null, [52, 99], [52, 110]]]]], ["value", ["get", "target.checked", ["loc", [null, [53, 34], [53, 48]]]]], ["loc", [null, [52, 67], [53, 49]]]], "name", "bibliographic", "label", "Bibliographic", "checked", ["subexpr", "@mut", [["get", "contributor.bibliographic", ["loc", [null, [54, 58], [54, 83]]]]], [], []]], ["loc", [null, [52, 24], [54, 85]]]], ["element", "action", ["removeContributor", ["get", "contributor", ["loc", [null, [57, 61], [57, 72]]]]], [], ["loc", [null, [57, 32], [57, 74]]]]],
        locals: ["contributor"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 75,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/contrib-manager/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/contrib-manager/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segments");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui two column grid");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "column");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("h4");
        dom.setAttribute(el5, "class", "ui header");
        var el6 = dom.createTextNode("Contributors");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "right aligned column");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createComment(" For Add Contributor Button ");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("table");
        dom.setAttribute(el3, "class", "ui compact tiny celled table");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("thead");
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("tr");
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("ID");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Name");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Permissions");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Bibliographic");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n            ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("tbody");
        var el5 = dom.createTextNode("\n");
        dom.appendChild(el4, el5);
        var el5 = dom.createComment("");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("            ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("tr");
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("td");
        dom.setAttribute(el6, "colspan", "5");
        var el7 = dom.createTextNode("\n                    ");
        dom.appendChild(el6, el7);
        var el7 = dom.createElement("button");
        dom.setAttribute(el7, "class", "ui green button");
        var el8 = dom.createTextNode("\n                        ");
        dom.appendChild(el7, el8);
        var el8 = dom.createElement("i");
        dom.setAttribute(el8, "class", "checkmark icon");
        dom.appendChild(el7, el8);
        var el8 = dom.createTextNode("Save changes\n                    ");
        dom.appendChild(el7, el8);
        dom.appendChild(el6, el7);
        var el7 = dom.createTextNode("\n                    ");
        dom.appendChild(el6, el7);
        var el7 = dom.createComment("");
        dom.appendChild(el6, el7);
        var el7 = dom.createTextNode("\n                ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n            ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element3 = dom.childAt(fragment, [2, 3, 1, 3]);
        var element4 = dom.childAt(element3, [3, 1]);
        var element5 = dom.childAt(element4, [1]);
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(element3, 1, 1);
        morphs[1] = dom.createElementMorph(element5);
        morphs[2] = dom.createMorphAt(element4, 3, 3);
        return morphs;
      },
      statements: [["block", "each", [["get", "contributors", ["loc", [null, [26, 20], [26, 32]]]]], [], 0, null, ["loc", [null, [26, 12], [62, 21]]]], ["element", "action", ["updateContributors"], [], ["loc", [null, [65, 28], [65, 59]]]], ["inline", "contrib-add", [], ["model", ["subexpr", "@mut", [["get", "model", ["loc", [null, [68, 40], [68, 45]]]]], [], []], "addContributor", ["subexpr", "action", ["addContributor"], [], ["loc", [null, [68, 61], [68, 86]]]]], ["loc", [null, [68, 20], [68, 88]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/dropzone-widget/component', ['exports', 'ember-osf/components/dropzone-widget/component', 'ember-craft-repository/pods/components/dropzone-widget/template'], function (exports, _emberOsfComponentsDropzoneWidgetComponent, _emberCraftRepositoryPodsComponentsDropzoneWidgetTemplate) {
    exports['default'] = _emberOsfComponentsDropzoneWidgetComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsDropzoneWidgetTemplate['default'],
        tagName: '',
        classNames: ['dropzone', 'widget']
    });
});
// app/pods/components/dropzone-widget/component.js
define("ember-craft-repository/pods/components/dropzone-widget/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 2,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/dropzone-widget/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/dropzone-widget/template.hbs");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/execution-dashboard/component', ['exports', 'ember', 'ember-craft-repository/pods/components/execution-dashboard/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsExecutionDashboardTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsExecutionDashboardTemplate['default'],
        tagName: '',
        classNames: ['execution', 'dashboard']
    });
});
// app/pods/components/execution-dashboard/component.js
// TODO: 0 issue: 4 Develop Execution Dashboard as component
define("ember-craft-repository/pods/components/execution-dashboard/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 13,
                  "column": 28
                },
                "end": {
                  "line": 17,
                  "column": 28
                }
              },
              "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("option");
              var el2 = dom.createTextNode("\n                                    ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode(" (");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode(")\n                                ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element1 = dom.childAt(fragment, [1]);
              var morphs = new Array(3);
              morphs[0] = dom.createAttrMorph(element1, 'value');
              morphs[1] = dom.createMorphAt(element1, 1, 1);
              morphs[2] = dom.createMorphAt(element1, 3, 3);
              return morphs;
            },
            statements: [["attribute", "value", ["concat", [["get", "file.path", ["loc", [null, [14, 49], [14, 58]]]]]]], ["content", "file.name", ["loc", [null, [15, 36], [15, 49]]]], ["content", "file.provider", ["loc", [null, [15, 51], [15, 68]]]]],
            locals: ["file"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 12,
                "column": 24
              },
              "end": {
                "line": 18,
                "column": 24
              }
            },
            "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
            dom.insertBoundary(fragment, 0);
            dom.insertBoundary(fragment, null);
            return morphs;
          },
          statements: [["block", "each", [["get", "provider.files", ["loc", [null, [13, 36], [13, 50]]]]], [], 0, null, ["loc", [null, [13, 28], [17, 37]]]]],
          locals: ["provider"],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 11,
              "column": 20
            },
            "end": {
              "line": 19,
              "column": 20
            }
          },
          "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "each", [["get", "project.files", ["loc", [null, [12, 32], [12, 45]]]]], [], 0, null, ["loc", [null, [12, 24], [18, 33]]]]],
        locals: ["project"],
        templates: [child0]
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 49,
                  "column": 28
                },
                "end": {
                  "line": 53,
                  "column": 28
                }
              },
              "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("option");
              var el2 = dom.createTextNode("\n                                    ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode(" (");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode(")\n                                ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element0 = dom.childAt(fragment, [1]);
              var morphs = new Array(3);
              morphs[0] = dom.createAttrMorph(element0, 'value');
              morphs[1] = dom.createMorphAt(element0, 1, 1);
              morphs[2] = dom.createMorphAt(element0, 3, 3);
              return morphs;
            },
            statements: [["attribute", "value", ["concat", [["get", "file.path", ["loc", [null, [50, 49], [50, 58]]]]]]], ["content", "file.name", ["loc", [null, [51, 36], [51, 49]]]], ["content", "file.provider", ["loc", [null, [51, 51], [51, 68]]]]],
            locals: ["file"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 48,
                "column": 24
              },
              "end": {
                "line": 54,
                "column": 24
              }
            },
            "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
            dom.insertBoundary(fragment, 0);
            dom.insertBoundary(fragment, null);
            return morphs;
          },
          statements: [["block", "each", [["get", "provider.files", ["loc", [null, [49, 36], [49, 50]]]]], [], 0, null, ["loc", [null, [49, 28], [53, 37]]]]],
          locals: ["provider"],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 47,
              "column": 20
            },
            "end": {
              "line": 55,
              "column": 20
            }
          },
          "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "each", [["get", "project.files", ["loc", [null, [48, 32], [48, 45]]]]], [], 0, null, ["loc", [null, [48, 24], [54, 33]]]]],
        locals: ["project"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 67,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/execution-dashboard/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/execution-dashboard/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segment");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h4");
        dom.setAttribute(el2, "class", "ui header");
        var el3 = dom.createTextNode("Execution Dashboard");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment(" Three Column Grid ");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui two column very relaxed grid form");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment(" Column One ");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui column");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "field");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("label");
        dom.setAttribute(el5, "class", "bold");
        var el6 = dom.createTextNode("Data ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("select");
        dom.setAttribute(el5, "class", "ui fluid dropdown");
        var el6 = dom.createTextNode("\n");
        dom.appendChild(el5, el6);
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "field");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("label");
        dom.setAttribute(el5, "class", "bold");
        var el6 = dom.createTextNode("Mode ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("select");
        dom.setAttribute(el5, "class", "ui fluid dropdown");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("option");
        dom.setAttribute(el6, "value", "Execute Script");
        var el7 = dom.createTextNode(" Execute Script ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("option");
        dom.setAttribute(el6, "value", "Run Notebook");
        var el7 = dom.createTextNode(" Run Notebook ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment(" Run and Reset ");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "ui buttons");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("button");
        dom.setAttribute(el5, "type", "button");
        dom.setAttribute(el5, "class", "ui green button");
        var el6 = dom.createTextNode("\n                    Run ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("i");
        dom.setAttribute(el6, "class", "ui play icon");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("button");
        dom.setAttribute(el5, "type", "button");
        dom.setAttribute(el5, "class", "ui red button");
        var el6 = dom.createTextNode("\n                    Reset ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("i");
        dom.setAttribute(el6, "class", "ui eject icon");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment(" Column Two ");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui column");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "field");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("label");
        dom.setAttribute(el5, "class", "bold");
        var el6 = dom.createTextNode("Script ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("select");
        dom.setAttribute(el5, "class", "ui fluid dropdown");
        var el6 = dom.createTextNode("\n");
        dom.appendChild(el5, el6);
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "field");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("label");
        dom.setAttribute(el5, "class", "bold");
        var el6 = dom.createTextNode("Status ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "input-status ready");
        var el6 = dom.createTextNode("\n                    Ready\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element2 = dom.childAt(fragment, [2, 5]);
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(dom.childAt(element2, [3, 1, 3]), 1, 1);
        morphs[1] = dom.createMorphAt(dom.childAt(element2, [7, 1, 3]), 1, 1);
        return morphs;
      },
      statements: [["block", "each", [["get", "model", ["loc", [null, [11, 28], [11, 33]]]]], [], 0, null, ["loc", [null, [11, 20], [19, 29]]]], ["block", "each", [["get", "model", ["loc", [null, [47, 28], [47, 33]]]]], [], 1, null, ["loc", [null, [47, 20], [55, 29]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/file-actions/component', ['exports', 'ember', 'ember-craft-repository/pods/components/file-actions/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsFileActionsTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsFileActionsTemplate['default'],
        fileManager: _ember['default'].inject.service(),
        store: _ember['default'].inject.service(),
        classNames: ['file', 'actions'],
        actions: {
            download: function download() {
                var file = this.get('file');
                var url = file.get('links').download;
                window.open(url);
            },
            updateContents: function updateContents(contents) {
                var file = this.get('file');
                var fm = this.get('fileManager');

                fm.updateContents(file, contents);
            },
            addSubfolder: function addSubfolder(name) {
                var folder = this.get('file');
                if (name) {
                    this.get('fileManager').addSubfolder(folder, name);
                }
            },
            uploadFiles: function uploadFiles(files) {
                var fm = this.get('fileManager');
                var folder = this.get('file');

                while (files && files.length) {
                    var file = files.pop();
                    console.log(file.name);
                    fm.uploadFile(folder, file.name, file);
                }
            },
            rename: function rename(newName) {
                var file = this.get('file');
                if (newName) {
                    this.get('fileManager').rename(file, newName);
                }
            },
            deleteFile: function deleteFile() {
                var _this = this;

                var file = this.get('file');
                var p = this.get('fileManager').deleteFile(file);
                p.then(function () {
                    _this.get('onChange')();
                });
            },
            moveFile: function moveFile(folderId) {
                var _this2 = this;

                var file = this.get('file');
                var store = this.get('store');
                store.findRecord('file', folderId).then(function (folder) {
                    // TODO:40 moving to file-provider root
                    var options = {
                        node: _this2.get('moveNode'),
                        provider: folder.get('provider'),
                        replace: _this2.get('moveReplace'),
                        copy: _this2.get('moveCopy'),
                        newName: _this2.get('moveName')
                    };

                    _this2.get('fileManager').move(file, folder, options);
                });
            }
        }
    });
});
// app/pods/components/file-actions/component.js
define("ember-craft-repository/pods/components/file-actions/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 3,
              "column": 4
            },
            "end": {
              "line": 52,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-actions/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                Rename:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-primary");
          var el4 = dom.createTextNode("\n                    Rename\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          dom.setAttribute(el2, "colspan", "2");
          var el3 = dom.createTextNode("\n                Delete:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-primary");
          var el4 = dom.createTextNode("\n                    Delete\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                Move to:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          var el4 = dom.createTextNode("Folder ID: ");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          var el4 = dom.createTextNode("Project ID (optional): ");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          var el4 = dom.createTextNode("New name (optional): ");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          var el4 = dom.createTextNode("\n                    ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          var el5 = dom.createTextNode("\n                        Replace ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          var el4 = dom.createTextNode("\n                    ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          var el5 = dom.createTextNode("\n                        Copy ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-primary");
          var el4 = dom.createTextNode("\n                    Move\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element5 = dom.childAt(fragment, [1]);
          var element6 = dom.childAt(element5, [5, 1]);
          var element7 = dom.childAt(fragment, [3, 3, 1]);
          var element8 = dom.childAt(fragment, [5]);
          var element9 = dom.childAt(element8, [3]);
          var element10 = dom.childAt(element8, [5, 1]);
          var morphs = new Array(9);
          morphs[0] = dom.createMorphAt(dom.childAt(element5, [3]), 1, 1);
          morphs[1] = dom.createElementMorph(element6);
          morphs[2] = dom.createElementMorph(element7);
          morphs[3] = dom.createMorphAt(dom.childAt(element9, [1]), 1, 1);
          morphs[4] = dom.createMorphAt(dom.childAt(element9, [3]), 1, 1);
          morphs[5] = dom.createMorphAt(dom.childAt(element9, [5]), 1, 1);
          morphs[6] = dom.createMorphAt(dom.childAt(element9, [7, 1]), 1, 1);
          morphs[7] = dom.createMorphAt(dom.childAt(element9, [9, 1]), 1, 1);
          morphs[8] = dom.createElementMorph(element10);
          return morphs;
        },
        statements: [["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "newName", ["loc", [null, [9, 30], [9, 37]]]]], [], []]], ["loc", [null, [9, 16], [9, 39]]]], ["element", "action", ["rename", ["get", "newName", ["loc", [null, [12, 42], [12, 49]]]]], [], ["loc", [null, [12, 24], [12, 51]]]], ["element", "action", ["deleteFile"], [], ["loc", [null, [22, 24], [22, 47]]]], ["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "moveTarget", ["loc", [null, [32, 46], [32, 56]]]]], [], []]], ["loc", [null, [32, 32], [32, 58]]]], ["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "moveProject", ["loc", [null, [33, 58], [33, 69]]]]], [], []]], ["loc", [null, [33, 44], [33, 71]]]], ["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "moveName", ["loc", [null, [34, 56], [34, 64]]]]], [], []]], ["loc", [null, [34, 42], [34, 66]]]], ["inline", "input", [], ["type", "checkbox", "checked", ["subexpr", "@mut", [["get", "moveReplace", ["loc", [null, [37, 64], [37, 75]]]]], [], []]], ["loc", [null, [37, 32], [37, 77]]]], ["inline", "input", [], ["type", "checkbox", "checked", ["subexpr", "@mut", [["get", "moveCopy", ["loc", [null, [42, 61], [42, 69]]]]], [], []]], ["loc", [null, [42, 29], [42, 71]]]], ["element", "action", ["moveFile", ["get", "moveTarget", ["loc", [null, [47, 44], [47, 54]]]]], [], ["loc", [null, [47, 24], [47, 56]]]]],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 53,
              "column": 4
            },
            "end": {
              "line": 80,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-actions/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                New folder:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-primary");
          var el4 = dom.createTextNode("\n                    Add folder\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                Upload files:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-primary");
          var el4 = dom.createTextNode("\n                    Upload\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element1 = dom.childAt(fragment, [1]);
          var element2 = dom.childAt(element1, [5, 1]);
          var element3 = dom.childAt(fragment, [3]);
          var element4 = dom.childAt(element3, [5, 1]);
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(element1, [3]), 1, 1);
          morphs[1] = dom.createElementMorph(element2);
          morphs[2] = dom.createMorphAt(dom.childAt(element3, [3]), 1, 1);
          morphs[3] = dom.createElementMorph(element4);
          return morphs;
        },
        statements: [["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "newFolderName", ["loc", [null, [59, 30], [59, 43]]]]], [], []]], ["loc", [null, [59, 16], [59, 45]]]], ["element", "action", ["addSubfolder", ["get", "newFolderName", ["loc", [null, [62, 48], [62, 61]]]]], [], ["loc", [null, [62, 24], [62, 63]]]], ["inline", "file-chooser", [], ["files", ["subexpr", "@mut", [["get", "filesToUpload", ["loc", [null, [72, 37], [72, 50]]]]], [], []]], ["loc", [null, [72, 16], [72, 52]]]], ["element", "action", ["uploadFiles", ["get", "filesToUpload", ["loc", [null, [75, 47], [75, 60]]]]], [], ["loc", [null, [75, 24], [75, 62]]]]],
        locals: [],
        templates: []
      };
    })();
    var child2 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 80,
              "column": 4
            },
            "end": {
              "line": 100,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-actions/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          dom.setAttribute(el2, "colspan", "2");
          var el3 = dom.createTextNode("\n                Download:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("button");
          dom.setAttribute(el3, "class", "btn btn-primary");
          var el4 = dom.createTextNode("\n                    Download\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                Update file contents:\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          dom.setAttribute(el2, "colspan", "2");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1, 3, 1]);
          var morphs = new Array(2);
          morphs[0] = dom.createElementMorph(element0);
          morphs[1] = dom.createMorphAt(dom.childAt(fragment, [3, 3]), 1, 1);
          return morphs;
        },
        statements: [["element", "action", ["download"], [], ["loc", [null, [86, 24], [86, 45]]]], ["inline", "file-chooser", [], ["multiple", false, "onChoose", ["subexpr", "action", ["updateContents"], [], ["loc", [null, [97, 29], [97, 54]]]]], ["loc", [null, [96, 16], [97, 56]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 102,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/file-actions/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/file-actions/template.js ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("table");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element11 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(element11, 1, 1);
        morphs[1] = dom.createMorphAt(element11, 2, 2);
        return morphs;
      },
      statements: [["block", "unless", [["get", "file.isProvider", ["loc", [null, [3, 14], [3, 29]]]]], [], 0, null, ["loc", [null, [3, 4], [52, 15]]]], ["block", "if", [["get", "file.isFolder", ["loc", [null, [53, 10], [53, 23]]]]], [], 1, 2, ["loc", [null, [53, 4], [100, 11]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/components/file-browser-icon/component', ['exports', 'ember', 'ember-craft-repository/pods/components/file-browser-icon/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsFileBrowserIconTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsFileBrowserIconTemplate['default'],
        tagName: '',
        iconName: _ember['default'].computed('item', 'item.expanded', function () {
            // TODO: More icons!
            if (this.get('item.isNode')) {
                // TODO node types
                return 'cube';
            }
            if (this.get('item.isProvider')) {
                // TODO provider-specific icons
                return 'disk outline';
            }
            if (this.get('item.isFolder')) {
                return 'folder outline';
            }
            // TODO: More file types
            return 'file outline';
        })
    });
});
// app/pods/components/file-browser-icon/component.js
// import FileBrowserIcon from 'ember-osf/components/file-browser-icon/component';
define("ember-craft-repository/pods/components/file-browser-icon/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/file-browser-icon/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/file-browser-icon/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("i");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var morphs = new Array(1);
        morphs[0] = dom.createAttrMorph(element0, 'class');
        return morphs;
      },
      statements: [["attribute", "class", ["concat", ["ui ", ["get", "iconName", ["loc", [null, [2, 15], [2, 23]]]], " icon"]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/file-browser-item/component', ['exports', 'ember-osf/components/file-browser-item/component', 'ember-osf/components/file-browser-item/template'], function (exports, _emberOsfComponentsFileBrowserItemComponent, _emberOsfComponentsFileBrowserItemTemplate) {
    exports['default'] = _emberOsfComponentsFileBrowserItemComponent['default'].extend({
        layout: _emberOsfComponentsFileBrowserItemTemplate['default']
    });
});
// app/pods/components/file-browser-item/component.js
define('ember-craft-repository/pods/components/file-browser/component', ['exports', 'ember-osf/components/file-browser/component', 'ember-craft-repository/pods/components/file-browser/template', 'ember'], function (exports, _emberOsfComponentsFileBrowserComponent, _emberCraftRepositoryPodsComponentsFileBrowserTemplate, _ember) {
    exports['default'] = _emberOsfComponentsFileBrowserComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsFileBrowserTemplate['default'],
        fileManager: _ember['default'].inject.service(),
        toast: _ember['default'].inject.service(),
        classNames: ['file', 'browser'],
        attributeBindings: ['elementId:id'],
        elementId: 'file-browser',
        selectedFolder: null,
        init: function init() {
            this._super.apply(this, arguments);
            this.loadFileBrowser();
        },
        loadFileBrowser: function loadFileBrowser() {
            var fileProviders = this.get('files');
            // console.log(this.get('files'));
            var params = { provider: "osfstorage" };
            var provider = fileProviders.findBy('provider', params.provider);

            this.set('selectedFolder', provider);
        },
        actions: {
            uploadFiles: function uploadFiles(files) {
                var _this = this;

                var fm = this.get('fileManager');
                // console.log('File Manager', fm);

                var folder = this.get('selectedFolder');
                // console.log('Folder', folder);

                while (files && files.length) {
                    var file = files.pop();
                    // console.log(fm, folder, file.name, file);
                    fm.uploadFile(folder, file.name, file).then(function () {
                        _this.get('toast').success('File uploaded successfully');
                        _this.sendAction('refreshModel');
                    });
                }
            },
            openItem: function openItem(item) {
                // console.log(item);
                this.sendAction('openItem', item);
            },
            selectItem: function selectItem(item) {
                console.log(item.get('kind'));
                console.log(item);
                if (item.get('kind') === "file") {
                    console.log('Downloading...');
                    this.send('downloadFile', item);
                } else {
                    console.log('Selecting...');
                    this.sendAction('selectItem', item);
                }
            },
            downloadFile: function downloadFile(item) {
                console.log('...and still downloading...');
                var file = item;
                var url = file.get('links').download;
                console.log(url);
                window.open(url);
                console.log('Done!');
            }
        }
    });
});
// app/pods/components/file-browser/component.js
define("ember-craft-repository/pods/components/file-browser/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 20,
                "column": 40
              },
              "end": {
                "line": 22,
                "column": 40
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-browser/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("span");
            dom.setAttribute(el1, "class", "divider");
            var el2 = dom.createTextNode("/");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 16,
              "column": 36
            },
            "end": {
              "line": 23,
              "column": 36
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-browser/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                                        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("a");
          dom.setAttribute(el1, "class", "section");
          var el2 = dom.createTextNode("\n                                            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                                        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var morphs = new Array(4);
          morphs[0] = dom.createElementMorph(element0);
          morphs[1] = dom.createMorphAt(element0, 1, 1);
          morphs[2] = dom.createMorphAt(element0, 2, 2);
          morphs[3] = dom.createMorphAt(fragment, 3, 3, contextualElement);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["element", "action", ["navigateToItem", ["get", "item", ["loc", [null, [17, 69], [17, 73]]]]], [], ["loc", [null, [17, 43], [17, 75]]]], ["inline", "file-browser-icon", [], ["item", ["subexpr", "@mut", [["get", "item", ["loc", [null, [18, 69], [18, 73]]]]], [], []]], ["loc", [null, [18, 44], [18, 75]]]], ["content", "item.itemName", ["loc", [null, [18, 75], [18, 92]]]], ["block", "unless", [["get", "@last", ["loc", [null, [20, 50], [20, 55]]]]], [], 0, null, ["loc", [null, [20, 40], [22, 51]]]]],
        locals: ["item"],
        templates: [child0]
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 30,
              "column": 44
            },
            "end": {
              "line": 35,
              "column": 44
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-browser/template.hbs"
        },
        isEmpty: false,
        arity: 2,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                                                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["inline", "file-browser-item", [], ["item", ["subexpr", "@mut", [["get", "item", ["loc", [null, [31, 73], [31, 77]]]]], [], []], "navigateToItem", ["subexpr", "action", ["navigateToItem"], [], ["loc", [null, [32, 63], [32, 88]]]], "selectItem", ["subexpr", "action", ["selectItem"], [], ["loc", [null, [33, 59], [33, 80]]]], "openItem", ["subexpr", "action", ["openItem"], [], ["loc", [null, [34, 57], [34, 76]]]]], ["loc", [null, [31, 48], [34, 78]]]]],
        locals: ["item", "index"],
        templates: []
      };
    })();
    var child2 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 36,
              "column": 44
            },
            "end": {
              "line": 41,
              "column": 44
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-browser/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                                                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "ui active inverted dimmer");
          var el2 = dom.createTextNode("\n                                                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui mini loader");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                                                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                                                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 72,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/file-browser/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/file-browser/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui stackable grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui segments");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "ui segment");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "file-browser-header");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("h3");
        dom.setAttribute(el6, "class", "ui header");
        var el7 = dom.createTextNode("Files");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "ui segment");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "ui items");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("div");
        dom.setAttribute(el6, "class", "item");
        var el7 = dom.createTextNode("\n                        ");
        dom.appendChild(el6, el7);
        var el7 = dom.createElement("div");
        dom.setAttribute(el7, "class", "content");
        var el8 = dom.createTextNode("\n                            ");
        dom.appendChild(el7, el8);
        var el8 = dom.createElement("div");
        dom.setAttribute(el8, "class", "ui breadcrumb");
        var el9 = dom.createTextNode("\n                                ");
        dom.appendChild(el8, el9);
        var el9 = dom.createElement("div");
        dom.setAttribute(el9, "class", "header");
        var el10 = dom.createTextNode("\n");
        dom.appendChild(el9, el10);
        var el10 = dom.createComment("");
        dom.appendChild(el9, el10);
        var el10 = dom.createTextNode("                                ");
        dom.appendChild(el9, el10);
        dom.appendChild(el8, el9);
        var el9 = dom.createTextNode("\n                            ");
        dom.appendChild(el8, el9);
        dom.appendChild(el7, el8);
        var el8 = dom.createTextNode("\n                            ");
        dom.appendChild(el7, el8);
        var el8 = dom.createElement("div");
        dom.setAttribute(el8, "class", "ui segments");
        var el9 = dom.createTextNode("\n                                ");
        dom.appendChild(el8, el9);
        var el9 = dom.createElement("div");
        dom.setAttribute(el9, "class", "ui segment");
        var el10 = dom.createTextNode("\n                                    ");
        dom.appendChild(el9, el10);
        var el10 = dom.createElement("div");
        dom.setAttribute(el10, "class", "description");
        var el11 = dom.createTextNode("\n                                        ");
        dom.appendChild(el10, el11);
        var el11 = dom.createElement("div");
        dom.setAttribute(el11, "class", "file-browser-list");
        var el12 = dom.createTextNode("\n");
        dom.appendChild(el11, el12);
        var el12 = dom.createComment("");
        dom.appendChild(el11, el12);
        var el12 = dom.createComment("");
        dom.appendChild(el11, el12);
        var el12 = dom.createTextNode("                                        ");
        dom.appendChild(el11, el12);
        dom.appendChild(el10, el11);
        var el11 = dom.createTextNode("\n                                    ");
        dom.appendChild(el10, el11);
        dom.appendChild(el9, el10);
        var el10 = dom.createTextNode("\n                                ");
        dom.appendChild(el9, el10);
        dom.appendChild(el8, el9);
        var el9 = dom.createTextNode("\n                            ");
        dom.appendChild(el8, el9);
        dom.appendChild(el7, el8);
        var el8 = dom.createTextNode("\n                            ");
        dom.appendChild(el7, el8);
        var el8 = dom.createElement("div");
        dom.setAttribute(el8, "class", "ui segment");
        var el9 = dom.createTextNode("\n                                ");
        dom.appendChild(el8, el9);
        var el9 = dom.createElement("div");
        dom.setAttribute(el9, "class", "ui items");
        var el10 = dom.createTextNode("\n                                    ");
        dom.appendChild(el9, el10);
        var el10 = dom.createElement("div");
        dom.setAttribute(el10, "class", "item");
        var el11 = dom.createTextNode("\n                                        ");
        dom.appendChild(el10, el11);
        var el11 = dom.createElement("div");
        dom.setAttribute(el11, "class", "content");
        var el12 = dom.createTextNode("\n                                            ");
        dom.appendChild(el11, el12);
        var el12 = dom.createComment("");
        dom.appendChild(el11, el12);
        var el12 = dom.createTextNode("\n                                        ");
        dom.appendChild(el11, el12);
        dom.appendChild(el10, el11);
        var el11 = dom.createTextNode("\n                                    ");
        dom.appendChild(el10, el11);
        dom.appendChild(el9, el10);
        var el10 = dom.createTextNode("\n                                    ");
        dom.appendChild(el9, el10);
        var el10 = dom.createElement("div");
        dom.setAttribute(el10, "class", "item");
        var el11 = dom.createTextNode("\n                                        ");
        dom.appendChild(el10, el11);
        var el11 = dom.createElement("div");
        dom.setAttribute(el11, "class", "content");
        var el12 = dom.createTextNode("\n                                            ");
        dom.appendChild(el11, el12);
        var el12 = dom.createElement("button");
        dom.setAttribute(el12, "class", "ui blue button");
        var el13 = dom.createTextNode("\n                                                Upload\n                                            ");
        dom.appendChild(el12, el13);
        dom.appendChild(el11, el12);
        var el12 = dom.createTextNode("\n                                        ");
        dom.appendChild(el11, el12);
        dom.appendChild(el10, el11);
        var el11 = dom.createTextNode("\n                                    ");
        dom.appendChild(el10, el11);
        dom.appendChild(el9, el10);
        var el10 = dom.createTextNode("\n                                ");
        dom.appendChild(el9, el10);
        dom.appendChild(el8, el9);
        var el9 = dom.createTextNode("\n                            ");
        dom.appendChild(el8, el9);
        dom.appendChild(el7, el8);
        var el8 = dom.createTextNode("\n");
        dom.appendChild(el7, el8);
        var el8 = dom.createTextNode("                        ");
        dom.appendChild(el7, el8);
        dom.appendChild(el6, el7);
        var el7 = dom.createTextNode("\n                    ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element1 = dom.childAt(fragment, [2, 1, 1, 3, 1, 1, 1]);
        var element2 = dom.childAt(element1, [3, 1, 1, 1]);
        var element3 = dom.childAt(element1, [5, 1]);
        var element4 = dom.childAt(element3, [3, 1, 1]);
        var morphs = new Array(5);
        morphs[0] = dom.createMorphAt(dom.childAt(element1, [1, 1]), 1, 1);
        morphs[1] = dom.createMorphAt(element2, 1, 1);
        morphs[2] = dom.createMorphAt(element2, 2, 2);
        morphs[3] = dom.createMorphAt(dom.childAt(element3, [1, 1]), 1, 1);
        morphs[4] = dom.createElementMorph(element4);
        return morphs;
      },
      statements: [["block", "each", [["get", "breadcrumbs", ["loc", [null, [16, 44], [16, 55]]]]], [], 0, null, ["loc", [null, [16, 36], [23, 45]]]], ["block", "each", [["get", "items", ["loc", [null, [30, 52], [30, 57]]]]], [], 1, null, ["loc", [null, [30, 44], [35, 53]]]], ["block", "unless", [["get", "itemsLoaded", ["loc", [null, [36, 54], [36, 65]]]]], [], 2, null, ["loc", [null, [36, 44], [41, 55]]]], ["inline", "file-chooser", [], ["files", ["subexpr", "@mut", [["get", "filesToUpload", ["loc", [null, [50, 65], [50, 78]]]]], [], []]], ["loc", [null, [50, 44], [50, 80]]]], ["element", "action", ["uploadFiles", ["get", "filesToUpload", ["loc", [null, [55, 75], [55, 88]]]]], [], ["loc", [null, [55, 52], [55, 90]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/components/file-chooser/component', ['exports', 'ember-osf/components/file-chooser/component', 'ember-craft-repository/pods/components/file-chooser/template'], function (exports, _emberOsfComponentsFileChooserComponent, _emberCraftRepositoryPodsComponentsFileChooserTemplate) {
    exports['default'] = _emberOsfComponentsFileChooserComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsFileChooserTemplate['default']
    });
});
// app/pods/components/file-chooser/component.js
define("ember-craft-repository/pods/components/file-chooser/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 2,
              "column": 0
            },
            "end": {
              "line": 4,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-chooser/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["inline", "yield", [["get", "this", ["loc", [null, [3, 12], [3, 16]]]]], [], ["loc", [null, [3, 4], [3, 18]]]]],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 8,
                "column": 4
              },
              "end": {
                "line": 10,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-chooser/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            var el2 = dom.createTextNode("Error: ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            return morphs;
          },
          statements: [["content", "errorMessage", ["loc", [null, [9, 20], [9, 36]]]]],
          locals: [],
          templates: []
        };
      })();
      var child1 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 14,
                  "column": 12
                },
                "end": {
                  "line": 16,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/components/file-chooser/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("li");
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(1);
              morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 0, 0);
              return morphs;
            },
            statements: [["content", "file.name", ["loc", [null, [15, 20], [15, 33]]]]],
            locals: ["file"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 11,
                "column": 4
              },
              "end": {
                "line": 18,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-chooser/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("h4");
            dom.setAttribute(el1, "class", "ui header");
            var el2 = dom.createTextNode("Files Selected: ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("ul");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("        ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
            return morphs;
          },
          statements: [["block", "each", [["get", "files", ["loc", [null, [14, 20], [14, 25]]]]], [], 0, null, ["loc", [null, [14, 12], [16, 21]]]]],
          locals: [],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 4,
              "column": 0
            },
            "end": {
              "line": 19,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-chooser/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(3);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          morphs[1] = dom.createMorphAt(fragment, 5, 5, contextualElement);
          morphs[2] = dom.createMorphAt(fragment, 6, 6, contextualElement);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["inline", "input", [], ["type", "file", "multiple", ["subexpr", "@mut", [["get", "multiple", ["loc", [null, [5, 33], [5, 41]]]]], [], []], "change", ["subexpr", "action", ["onFileInputChange"], [], ["loc", [null, [5, 49], [5, 77]]]]], ["loc", [null, [5, 4], [5, 79]]]], ["block", "if", [["get", "errorMessage", ["loc", [null, [8, 10], [8, 22]]]]], [], 0, null, ["loc", [null, [8, 4], [10, 11]]]], ["block", "if", [["get", "files", ["loc", [null, [11, 10], [11, 15]]]]], [], 1, null, ["loc", [null, [11, 4], [18, 11]]]]],
        locals: [],
        templates: [child0, child1]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 20,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/file-chooser/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/file-chooser/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["block", "if", [["get", "hasBlock", ["loc", [null, [2, 6], [2, 14]]]]], [], 0, 1, ["loc", [null, [2, 0], [19, 7]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/file-tree/component', ['exports', 'ember', 'ember-craft-repository/pods/components/file-tree/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsFileTreeTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsFileTreeTemplate['default'],
        attributeBindings: ['elementId:id'],
        elementId: 'file-tree',
        classNames: ['file', 'tree']
    });
});
// app/pods/components/file-tree/component.js
define("ember-craft-repository/pods/components/file-tree/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 3,
              "column": 4
            },
            "end": {
              "line": 5,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("a");
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var morphs = new Array(2);
          morphs[0] = dom.createElementMorph(element0);
          morphs[1] = dom.createMorphAt(element0, 0, 0);
          return morphs;
        },
        statements: [["element", "action", [["get", "onClickFile", ["loc", [null, [4, 20], [4, 31]]]], ["get", "root", ["loc", [null, [4, 32], [4, 36]]]]], [], ["loc", [null, [4, 11], [4, 38]]]], ["content", "root.name", ["loc", [null, [4, 39], [4, 52]]]]],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 6,
                "column": 8
              },
              "end": {
                "line": 8,
                "column": 8
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
            return morphs;
          },
          statements: [["inline", "link-to", [["get", "root.name", ["loc", [null, [7, 22], [7, 31]]]], "projects.detail.files.provider", ["get", "project", ["loc", [null, [7, 65], [7, 72]]]], ["get", "root", ["loc", [null, [7, 73], [7, 77]]]]], [], ["loc", [null, [7, 12], [7, 79]]]]],
          locals: [],
          templates: []
        };
      })();
      var child1 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 8,
                "column": 8
              },
              "end": {
                "line": 11,
                "column": 8
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
            return morphs;
          },
          statements: [["inline", "link-to", [["get", "root.name", ["loc", [null, [9, 22], [9, 31]]]], "projects.detail.files.provider.file", ["get", "project", ["loc", [null, [10, 12], [10, 19]]]], ["get", "root.provider", ["loc", [null, [10, 20], [10, 33]]]], ["get", "root", ["loc", [null, [10, 34], [10, 38]]]]], [], ["loc", [null, [9, 12], [10, 40]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 5,
              "column": 4
            },
            "end": {
              "line": 12,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "if", [["get", "root.isProvider", ["loc", [null, [6, 14], [6, 29]]]]], [], 0, 1, ["loc", [null, [6, 8], [11, 15]]]]],
        locals: [],
        templates: [child0, child1]
      };
    })();
    var child2 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 15,
                "column": 12
              },
              "end": {
                "line": 19,
                "column": 12
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("li");
            var el2 = dom.createTextNode("\n                    ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            return morphs;
          },
          statements: [["inline", "file-tree", [], ["root", ["subexpr", "@mut", [["get", "file", ["loc", [null, [17, 37], [17, 41]]]]], [], []], "project", ["subexpr", "@mut", [["get", "project", ["loc", [null, [17, 50], [17, 57]]]]], [], []]], ["loc", [null, [17, 20], [17, 59]]]]],
          locals: ["file"],
          templates: []
        };
      })();
      var child1 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 19,
                "column": 12
              },
              "end": {
                "line": 21,
                "column": 12
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("li");
            var el2 = dom.createTextNode("(empty folder)");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 13,
              "column": 4
            },
            "end": {
              "line": 23,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("ul");
          dom.setAttribute(el1, "class", "folder-list");
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
          return morphs;
        },
        statements: [["block", "each", [["get", "root.files", ["loc", [null, [15, 20], [15, 30]]]]], [], 0, 1, ["loc", [null, [15, 12], [21, 21]]]]],
        locals: [],
        templates: [child0, child1]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 25,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/file-tree/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/file-tree/template.js ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "file-tree");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element1 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(element1, 1, 1);
        morphs[1] = dom.createMorphAt(element1, 2, 2);
        return morphs;
      },
      statements: [["block", "if", [["get", "onClickFile", ["loc", [null, [3, 10], [3, 21]]]]], [], 0, 1, ["loc", [null, [3, 4], [12, 11]]]], ["block", "if", [["get", "root.isFolder", ["loc", [null, [13, 10], [13, 23]]]]], [], 2, null, ["loc", [null, [13, 4], [23, 11]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/components/file-widget/component', ['exports', 'ember-osf/components/oauth-popup/component', 'ember-craft-repository/pods/components/file-widget/template'], function (exports, _emberOsfComponentsOauthPopupComponent, _emberCraftRepositoryPodsComponentsFileWidgetTemplate) {

    // TODO:0 issue:3 Develop file-widget
    exports['default'] = _emberOsfComponentsOauthPopupComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsFileWidgetTemplate['default'],
        attributeBindings: ['elementId:id'],
        elementId: 'file-widget',
        classNames: ['file', 'widget']
    });
});
// app/pods/components/file-widget/component.js
define("ember-craft-repository/pods/components/file-widget/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 14,
                  "column": 24
                },
                "end": {
                  "line": 18,
                  "column": 24
                }
              },
              "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                            ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("button");
              dom.setAttribute(el1, "class", "ui green login button");
              var el2 = dom.createTextNode("\n                                Login to OSF\n                            ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element3 = dom.childAt(fragment, [1]);
              var morphs = new Array(1);
              morphs[0] = dom.createAttrMorph(element3, 'onclick');
              return morphs;
            },
            statements: [["attribute", "onclick", ["subexpr", "action", ["login"], ["target", ["get", "popup", ["loc", [null, [15, 98], [15, 103]]]]], ["loc", [null, [15, 74], [15, 105]]]]]],
            locals: ["popup"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 13,
                "column": 20
              },
              "end": {
                "line": 19,
                "column": 20
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
            dom.insertBoundary(fragment, 0);
            dom.insertBoundary(fragment, null);
            return morphs;
          },
          statements: [["block", "oauth-popup", [], ["authUrl", ["subexpr", "@mut", [["get", "authUrl", ["loc", [null, [14, 47], [14, 54]]]]], [], []], "loginSuccess", ["subexpr", "action", ["loginSuccess"], [], ["loc", [null, [14, 68], [14, 91]]]], "loginFail", ["subexpr", "action", ["loginFail"], [], ["loc", [null, [14, 102], [14, 122]]]]], 0, null, ["loc", [null, [14, 24], [18, 40]]]]],
          locals: [],
          templates: [child0]
        };
      })();
      var child1 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 21,
                  "column": 24
                },
                "end": {
                  "line": 24,
                  "column": 24
                }
              },
              "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                            ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("img");
              dom.setAttribute(el1, "class", "icon-flag");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("strong");
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element2 = dom.childAt(fragment, [1]);
              var morphs = new Array(2);
              morphs[0] = dom.createAttrMorph(element2, 'src');
              morphs[1] = dom.createMorphAt(dom.childAt(fragment, [2]), 0, 0);
              return morphs;
            },
            statements: [["attribute", "src", ["concat", [["get", "country.flagUrl", ["loc", [null, [23, 40], [23, 55]]]]]]], ["content", "project.title", ["loc", [null, [23, 85], [23, 102]]]]],
            locals: ["project"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 19,
                "column": 20
              },
              "end": {
                "line": 25,
                "column": 20
              }
            },
            "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("label");
            var el2 = dom.createTextNode("Choose an OSF project:");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 3, 3, contextualElement);
            dom.insertBoundary(fragment, null);
            return morphs;
          },
          statements: [["block", "power-select", [], ["options", ["subexpr", "@mut", [["get", "userNodes", ["loc", [null, [21, 48], [21, 57]]]]], [], []], "closeOnSelect", false, "searchField", "title", "selected", ["subexpr", "@mut", [["get", "selectedNode", ["loc", [null, [21, 107], [21, 119]]]]], [], []], "onchange", ["subexpr", "action", [["subexpr", "mut", [["get", "selectedNode", ["loc", [null, [22, 46], [22, 58]]]]], [], ["loc", [null, [22, 41], [22, 59]]]]], [], ["loc", [null, [22, 33], [22, 60]]]]], 0, null, ["loc", [null, [21, 24], [24, 41]]]]],
          locals: [],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 5,
              "column": 12
            },
            "end": {
              "line": 27,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "column");
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "dropzone box");
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "column");
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(2);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1, 1]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
          return morphs;
        },
        statements: [["inline", "dropzone-widget", [], ["preUpload", ["subexpr", "@mut", [["get", "attrs.preUpload", ["loc", [null, [8, 52], [8, 67]]]]], [], []], "buildUrl", ["subexpr", "@mut", [["get", "buildUrl", ["loc", [null, [8, 77], [8, 85]]]]], [], []], "listeners", ["subexpr", "@mut", [["get", "dropzoneListeners", ["loc", [null, [8, 96], [8, 113]]]]], [], []], "options", ["subexpr", "@mut", [["get", "dropzoneOptions", ["loc", [null, [9, 36], [9, 51]]]]], [], []]], ["loc", [null, [8, 24], [9, 53]]]], ["block", "if", [["subexpr", "not", [["get", "session.isAuthenticated", ["loc", [null, [13, 31], [13, 54]]]]], [], ["loc", [null, [13, 26], [13, 55]]]]], [], 0, 1, ["loc", [null, [13, 20], [25, 27]]]]],
        locals: [],
        templates: [child0, child1]
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 27,
              "column": 12
            },
            "end": {
              "line": 33,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui green button");
          var el3 = dom.createTextNode("Back");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [3]);
          var morphs = new Array(3);
          morphs[0] = dom.createMorphAt(element0, 1, 1);
          morphs[1] = dom.createElementMorph(element1);
          morphs[2] = dom.createMorphAt(fragment, 3, 3, contextualElement);
          return morphs;
        },
        statements: [["content", "selectedNode.title", ["loc", [null, [29, 20], [29, 42]]]], ["element", "action", ["deselectNode"], [], ["loc", [null, [30, 52], [30, 77]]]], ["inline", "file-browser", [], ["rootNode", ["subexpr", "@mut", [["get", "selectedNode", ["loc", [null, [32, 40], [32, 52]]]]], [], []], "onClickFile", ["subexpr", "action", ["selectNodeFile"], [], ["loc", [null, [32, 65], [32, 90]]]]], ["loc", [null, [32, 16], [32, 92]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 37,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/file-widget/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/file-widget/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "eosf file widget box");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui two column grid");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "row");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [2, 1, 1]), 1, 1);
        return morphs;
      },
      statements: [["block", "if", [["subexpr", "not", [["get", "selectedNode", ["loc", [null, [5, 23], [5, 35]]]]], [], ["loc", [null, [5, 18], [5, 36]]]]], [], 0, 1, ["loc", [null, [5, 12], [33, 19]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/footer-main/component', ['exports', 'ember', 'ember-craft-repository/pods/components/footer-main/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsFooterMainTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsFooterMainTemplate['default'],
        attributeBindings: ['elementId:id'],
        elementId: 'footer-main',
        classNames: ['footer', 'main']
    });
});
// app/pods/components/footer-main/component.js
define("ember-craft-repository/pods/components/footer-main/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 15,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/footer-main/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/footer-main/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui inverted segment");
        dom.setAttribute(el1, "style", "margin:0; padding:10px");
        var el2 = dom.createTextNode("\n\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui stackable grid");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "eight wide column");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("img");
        dom.setAttribute(el4, "src", "/assets/images/darpa.png");
        dom.setAttribute(el4, "width", "120");
        dom.setAttribute(el4, "style", "width 120px");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "eight wide right aligned column");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("br");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n                ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("a");
        dom.setAttribute(el4, "href", "mailto:support@craftproject.org?Subject=Support%20Request");
        dom.setAttribute(el4, "target", "_top");
        var el5 = dom.createElement("i");
        dom.setAttribute(el5, "class", "icon mail");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode(" Contact");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/loading-widget/component', ['exports', 'ember', 'ember-craft-repository/pods/components/loading-widget/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsLoadingWidgetTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsLoadingWidgetTemplate['default'],
        classNames: ['loading', 'widget'],
        classNameBindings: ['isPrivate:private', 'isPublic:public'],
        isPrivate: false,
        isPublic: false,
        isLoading: null
    });
});
// app/pods/components/loading-widget/component.js
define("ember-craft-repository/pods/components/loading-widget/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 14,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/loading-widget/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/loading-widget/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active inverted dimmer");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui big text loader");
        var el3 = dom.createTextNode("\n        Loading...\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/log-detail/component', ['exports', 'ember', 'ember-craft-repository/pods/components/log-detail/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsLogDetailTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsLogDetailTemplate['default'],
        tagName: '',
        classNames: ['ui', 'segments', 'log', 'detail']
    });
});
// app/pods/components/log-detail/component.js
define("ember-craft-repository/pods/components/log-detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 37,
                "column": 28
              },
              "end": {
                "line": 41,
                "column": 28
              }
            },
            "moduleName": "ember-craft-repository/pods/components/log-detail/template.hbs"
          },
          isEmpty: false,
          arity: 2,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "ui small label");
            var el2 = dom.createTextNode("\n                                    ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                                ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            return morphs;
          },
          statements: [["content", "key", ["loc", [null, [39, 36], [39, 43]]]]],
          locals: ["key", "value"],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 19,
              "column": 16
            },
            "end": {
              "line": 46,
              "column": 16
            }
          },
          "moduleName": "ember-craft-repository/pods/components/log-detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("a");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment(":  {{project-log.originalNode.id}}");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("a");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("a");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment(": {{project-log.node.id}}");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createTextNode("\n");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [3, 1]);
          var element2 = dom.childAt(element0, [5, 1]);
          var element3 = dom.childAt(element0, [7, 1]);
          var element4 = dom.childAt(element0, [11]);
          var morphs = new Array(11);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
          morphs[1] = dom.createAttrMorph(element1, 'href');
          morphs[2] = dom.createMorphAt(element1, 0, 0);
          morphs[3] = dom.createAttrMorph(element2, 'href');
          morphs[4] = dom.createMorphAt(element2, 0, 0);
          morphs[5] = dom.createAttrMorph(element3, 'href');
          morphs[6] = dom.createMorphAt(element3, 0, 0);
          morphs[7] = dom.createMorphAt(dom.childAt(element0, [9]), 1, 1);
          morphs[8] = dom.createMorphAt(element4, 1, 1);
          morphs[9] = dom.createMorphAt(element4, 3, 3);
          morphs[10] = dom.createMorphAt(element4, 5, 5);
          return morphs;
        },
        statements: [["content", "project-log.action", ["loc", [null, [22, 28], [22, 50]]]], ["attribute", "href", ["concat", [["get", "project-log.originalNode.links.html", ["loc", [null, [25, 39], [25, 74]]]]]]], ["content", "project-log.originalNode.title", ["loc", [null, [25, 78], [25, 112]]]], ["attribute", "href", ["concat", [["get", "project-log.user.links.html", ["loc", [null, [28, 39], [28, 66]]]]]]], ["content", "project-log.user.givenName", ["loc", [null, [28, 70], [28, 100]]]], ["attribute", "href", ["concat", [["get", "project-log.node.links.html", ["loc", [null, [31, 39], [31, 66]]]]]]], ["content", "project-log.node.title", ["loc", [null, [31, 70], [31, 96]]]], ["inline", "moment-from-now", [["get", "project-log.date", ["loc", [null, [34, 46], [34, 62]]]]], [], ["loc", [null, [34, 28], [34, 64]]]], ["block", "each-in", [["get", "project-log.params", ["loc", [null, [37, 39], [37, 57]]]]], [], 0, null, ["loc", [null, [37, 28], [41, 40]]]], ["inline", "if", [["get", "project-log.linkedNode", ["loc", [null, [42, 33], [42, 55]]]], "linked_node"], [], ["loc", [null, [42, 28], [42, 71]]]], ["inline", "if", [["get", "project-log.templateNode", ["loc", [null, [43, 33], [43, 57]]]], "template_node"], [], ["loc", [null, [43, 28], [43, 75]]]]],
        locals: ["project-log"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 51,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/log-detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/log-detail/template.js ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segments");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("h4");
        dom.setAttribute(el3, "class", "ui header");
        var el4 = dom.createTextNode("Recent Activity");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        dom.setAttribute(el2, "style", "height: 500px; overflow-y: scroll;");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("table");
        dom.setAttribute(el3, "class", "ui compact tiny celled striped table");
        dom.setAttribute(el3, "style", "font-size: 0.9em");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("thead");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("tr");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Action");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Original Project");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("User");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Current Project");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Date");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("th");
        var el7 = dom.createTextNode("Additional Params Included");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("tbody");
        var el5 = dom.createTextNode("\n");
        dom.appendChild(el4, el5);
        var el5 = dom.createComment("");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [2, 3, 1, 3]), 1, 1);
        return morphs;
      },
      statements: [["block", "each", [["get", "model-logs", ["loc", [null, [19, 24], [19, 34]]]]], [], 0, null, ["loc", [null, [19, 16], [46, 25]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/login-register-selector/component', ['exports', 'ember'], function (exports, _ember) {
  exports['default'] = _ember['default'].Component.extend({
    store: _ember['default'].inject.service(),
    tagName: '',
    actions: {
      selectCard: function selectCard(name) {
        this.sendAction('action', name);
      }
    }
  });
});
// app/pods/components/login-register-selector/component.js
define("ember-craft-repository/pods/components/login-register-selector/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 25,
                "column": 6
              },
              "end": {
                "line": 45,
                "column": 6
              }
            },
            "moduleName": "ember-craft-repository/pods/components/login-register-selector/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("          ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            var el2 = dom.createTextNode("\n              ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("div");
            dom.setAttribute(el2, "class", "ui fluid card");
            var el3 = dom.createTextNode("\n                  ");
            dom.appendChild(el2, el3);
            var el3 = dom.createElement("div");
            dom.setAttribute(el3, "class", "image login register");
            var el4 = dom.createTextNode("\n                      ");
            dom.appendChild(el3, el4);
            var el4 = dom.createElement("img");
            dom.appendChild(el3, el4);
            var el4 = dom.createTextNode("\n                  ");
            dom.appendChild(el3, el4);
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode("\n                  ");
            dom.appendChild(el2, el3);
            var el3 = dom.createElement("div");
            dom.setAttribute(el3, "class", "content");
            var el4 = dom.createTextNode("\n                      ");
            dom.appendChild(el3, el4);
            var el4 = dom.createElement("div");
            dom.setAttribute(el4, "class", "header");
            var el5 = dom.createComment("");
            dom.appendChild(el4, el5);
            dom.appendChild(el3, el4);
            var el4 = dom.createTextNode("\n                      ");
            dom.appendChild(el3, el4);
            var el4 = dom.createElement("div");
            dom.setAttribute(el4, "class", "description");
            var el5 = dom.createTextNode("\n                        ");
            dom.appendChild(el4, el5);
            var el5 = dom.createComment("");
            dom.appendChild(el4, el5);
            var el5 = dom.createTextNode("\n                      ");
            dom.appendChild(el4, el5);
            dom.appendChild(el3, el4);
            var el4 = dom.createTextNode("\n                  ");
            dom.appendChild(el3, el4);
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode("\n                  ");
            dom.appendChild(el2, el3);
            var el3 = dom.createElement("div");
            dom.setAttribute(el3, "class", "extra content");
            var el4 = dom.createTextNode("\n                      ");
            dom.appendChild(el3, el4);
            var el4 = dom.createElement("div");
            dom.setAttribute(el4, "class", "ui fluid blue button");
            var el5 = dom.createTextNode("\n                          ");
            dom.appendChild(el4, el5);
            var el5 = dom.createElement("i");
            dom.setAttribute(el5, "class", "checkmark icon");
            dom.appendChild(el4, el5);
            var el5 = dom.createTextNode("\n                          ");
            dom.appendChild(el4, el5);
            var el5 = dom.createComment("");
            dom.appendChild(el4, el5);
            dom.appendChild(el3, el4);
            var el4 = dom.createTextNode("\n                  ");
            dom.appendChild(el3, el4);
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode("\n\n              ");
            dom.appendChild(el2, el3);
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n          ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element0 = dom.childAt(fragment, [1]);
            var element1 = dom.childAt(element0, [1]);
            var element2 = dom.childAt(element1, [1, 1]);
            var element3 = dom.childAt(element1, [3]);
            var element4 = dom.childAt(element1, [5, 1]);
            var morphs = new Array(6);
            morphs[0] = dom.createAttrMorph(element0, 'class');
            morphs[1] = dom.createAttrMorph(element2, 'src');
            morphs[2] = dom.createMorphAt(dom.childAt(element3, [1]), 0, 0);
            morphs[3] = dom.createMorphAt(dom.childAt(element3, [3]), 1, 1);
            morphs[4] = dom.createElementMorph(element4);
            morphs[5] = dom.createMorphAt(element4, 3, 3);
            return morphs;
          },
          statements: [["attribute", "class", ["concat", [["get", "item.active", ["loc", [null, [26, 24], [26, 35]]]], " side"]]], ["attribute", "src", ["concat", ["/assets/icons/", ["get", "item.image", ["loc", [null, [29, 48], [29, 58]]]]]]], ["content", "item.name", ["loc", [null, [32, 42], [32, 55]]]], ["content", "item.description", ["loc", [null, [34, 24], [34, 44]]]], ["element", "action", ["selectCard", ["get", "item.name", ["loc", [null, [38, 78], [38, 87]]]]], [], ["loc", [null, [38, 56], [38, 89]]]], ["content", "item.name", ["loc", [null, [40, 26], [40, 39]]]]],
          locals: ["item"],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 2,
              "column": 0
            },
            "end": {
              "line": 48,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/login-register-selector/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "shape three d controls");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui tiny button");
          dom.setAttribute(el2, "title", "Flip Up");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "up arrow icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui tiny button");
          dom.setAttribute(el2, "title", "Flip Left");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "left arrow icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui tiny icon button");
          dom.setAttribute(el2, "title", "Flip Right");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "right arrow icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui tiny icon button");
          dom.setAttribute(el2, "title", "Flip Down");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "down arrow icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui tiny button");
          dom.setAttribute(el2, "title", "Flip Over");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "retweet icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui tiny button");
          dom.setAttribute(el2, "title", "Flip Back");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "flipped retweet icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "sides");
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element5 = dom.childAt(fragment, [1]);
          var element6 = dom.childAt(element5, [1]);
          var element7 = dom.childAt(element5, [3]);
          var element8 = dom.childAt(element5, [5]);
          var element9 = dom.childAt(element5, [7]);
          var element10 = dom.childAt(element5, [9]);
          var element11 = dom.childAt(element5, [11]);
          var morphs = new Array(7);
          morphs[0] = dom.createElementMorph(element6);
          morphs[1] = dom.createElementMorph(element7);
          morphs[2] = dom.createElementMorph(element8);
          morphs[3] = dom.createElementMorph(element9);
          morphs[4] = dom.createElementMorph(element10);
          morphs[5] = dom.createElementMorph(element11);
          morphs[6] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
          return morphs;
        },
        statements: [["element", "action", [["get", "execute", ["loc", [null, [4, 61], [4, 68]]]], "flip up"], [], ["loc", [null, [4, 52], [4, 80]]]], ["element", "action", [["get", "execute", ["loc", [null, [7, 63], [7, 70]]]], "flip left"], [], ["loc", [null, [7, 54], [7, 84]]]], ["element", "action", [["get", "execute", ["loc", [null, [10, 69], [10, 76]]]], "flip right"], [], ["loc", [null, [10, 60], [10, 91]]]], ["element", "action", [["get", "execute", ["loc", [null, [13, 68], [13, 75]]]], "flip down"], [], ["loc", [null, [13, 59], [13, 89]]]], ["element", "action", [["get", "execute", ["loc", [null, [16, 63], [16, 70]]]], "flip over"], [], ["loc", [null, [16, 54], [16, 84]]]], ["element", "action", [["get", "execute", ["loc", [null, [19, 63], [19, 70]]]], "flip back"], [], ["loc", [null, [19, 54], [19, 84]]]], ["block", "each", [["get", "data", ["loc", [null, [25, 14], [25, 18]]]]], [], 0, null, ["loc", [null, [25, 6], [45, 15]]]]],
        locals: ["execute"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 49,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/login-register-selector/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/login-register-selector/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["block", "ui-shape", [], ["class", "Choices"], 0, null, ["loc", [null, [2, 0], [48, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/navbar-main/component', ['exports', 'ember', 'ember-craft-repository/pods/components/navbar-main/template', 'ember-get-config'], function (exports, _ember, _emberCraftRepositoryPodsComponentsNavbarMainTemplate, _emberGetConfig) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsNavbarMainTemplate['default'],
        session: _ember['default'].inject.service(),
        currentUser: _ember['default'].inject.service(),
        routing: _ember['default'].inject.service('-routing'),
        tagName: '',
        attributeBindings: ['elementId:id'],
        elementId: 'navbar-main',
        classNames: ['navbar', 'main'],
        onSearchPage: false,
        hideSearch: false,
        user: null,
        signupUrl: _emberGetConfig['default'].OSF.url + 'register',
        gravatarUrl: _ember['default'].computed('user', function () {
            var imgLink = this.get('user.links.profile_image');
            if (imgLink) {
                imgLink += '&s=25';
            }
            return imgLink;
        }),
        fullName: null,
        host: _emberGetConfig['default'].OSF.url,
        isAuthenticated: _ember['default'].on('init', _ember['default'].observer('session.isAuthenticated', function () {
            var _this = this;

            this.get('currentUser').load().then(function (user) {
                return _this.set('user', user);
            });
        })),
        showSearch: false,
        // TODO: These parameters are defined in osf settings.py; make sure ember config matches.
        allowLogin: true,
        enableInstitutions: true,
        actions: {
            toggleSearch: function toggleSearch() {
                this.toggleProperty('showSearch');
            },
            logout: function logout() {
                // TODO: May not work well if logging out from page that requires login- check?
                // TODO: Remove cookies on logout should be implemented
                this.get('session').invalidate();
                this.get("routing").transitionTo('login');
            },
            toggleSidebar: function toggleSidebar(subSidebarName) {
                // this.sendAction(...arguments);
                $('#' + subSidebarName).sidebar('setting', 'transition', 'push').sidebar('toggle');
            }
        }
    });
});
// app/pods/components/navbar-main/component.js
define("ember-craft-repository/pods/components/navbar-main/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 7,
              "column": 8
            },
            "end": {
              "line": 10,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/components/navbar-main/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("img");
          dom.setAttribute(el1, "class", "ui right spaced image logo header");
          dom.setAttribute(el1, "src", "/assets/images/craft.png");
          dom.setAttribute(el1, "alt", "CRAFT Logo");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          var el2 = dom.createTextNode("REPOSITORY");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 21,
                  "column": 20
                },
                "end": {
                  "line": 23,
                  "column": 20
                }
              },
              "moduleName": "ember-craft-repository/pods/components/navbar-main/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                        ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("i");
              dom.setAttribute(el1, "class", "user icon");
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode(" Profile\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes() {
              return [];
            },
            statements: [],
            locals: [],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 14,
                "column": 12
              },
              "end": {
                "line": 28,
                "column": 12
              }
            },
            "moduleName": "ember-craft-repository/pods/components/navbar-main/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "ui black user login");
            var el2 = dom.createTextNode("\n                    ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("img");
            dom.setAttribute(el2, "class", "ui avatar image");
            dom.setAttribute(el2, "alt", "User gravatar");
            dom.setAttribute(el2, "width", "25px");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                    ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "dropdown icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "menu");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("                    ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("div");
            dom.setAttribute(el2, "class", "item");
            var el3 = dom.createTextNode("\n                        ");
            dom.appendChild(el2, el3);
            var el3 = dom.createElement("i");
            dom.setAttribute(el3, "class", "sign out icon");
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode(" Logout\n                    ");
            dom.appendChild(el2, el3);
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element0 = dom.childAt(fragment, [1]);
            var element1 = dom.childAt(element0, [1]);
            var element2 = dom.childAt(fragment, [5]);
            var element3 = dom.childAt(element2, [3]);
            var morphs = new Array(4);
            morphs[0] = dom.createAttrMorph(element1, 'src');
            morphs[1] = dom.createMorphAt(element0, 3, 3);
            morphs[2] = dom.createMorphAt(element2, 1, 1);
            morphs[3] = dom.createElementMorph(element3);
            return morphs;
          },
          statements: [["attribute", "src", ["concat", [["get", "gravatarUrl", ["loc", [null, [16, 56], [16, 67]]]]]]], ["content", "user.fullName", ["loc", [null, [17, 20], [17, 37]]]], ["block", "link-to", ["profile"], ["class", "right item"], 0, null, ["loc", [null, [21, 20], [23, 32]]]], ["element", "action", ["logout"], [], ["loc", [null, [24, 38], [24, 57]]]]],
          locals: [],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 13,
              "column": 8
            },
            "end": {
              "line": 33,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/components/navbar-main/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "ui-dropdown", [], ["class", "item"], 0, null, ["loc", [null, [14, 12], [28, 28]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 36,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/navbar-main/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/navbar-main/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui inverted menu main navbar");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui big black button item");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("i");
        dom.setAttribute(el3, "class", "white list icon");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "header item logo");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "right menu");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element4 = dom.childAt(fragment, [2]);
        var element5 = dom.childAt(element4, [1]);
        var morphs = new Array(3);
        morphs[0] = dom.createElementMorph(element5);
        morphs[1] = dom.createMorphAt(dom.childAt(element4, [3]), 1, 1);
        morphs[2] = dom.createMorphAt(dom.childAt(element4, [5]), 1, 1);
        return morphs;
      },
      statements: [["element", "action", ["toggleSidebar", "sub-sidebar"], [], ["loc", [null, [3, 42], [3, 82]]]], ["block", "link-to", ["index"], [], 0, null, ["loc", [null, [7, 8], [10, 20]]]], ["block", "if", [["get", "session.isAuthenticated", ["loc", [null, [13, 14], [13, 37]]]]], [], 1, null, ["loc", [null, [13, 8], [33, 15]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/navbar-sidebar/component', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Component.extend({
        tagName: '',
        attributeBindings: ['elementId:id'],
        elementId: 'navbar-sidebar',
        classNames: ['navbar', 'sidebar'],
        actions: {
            closeMenu: function closeMenu() {
                $('.sidebar').sidebar("toggle");
            }
        }
    });
});
// app/pods/components/navbar-sidebar/component.js
define("ember-craft-repository/pods/components/navbar-sidebar/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 4,
                "column": 4
              },
              "end": {
                "line": 7,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/components/navbar-sidebar/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "dashboard icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        Dashboard\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      var child1 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 8,
                "column": 4
              },
              "end": {
                "line": 11,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/components/navbar-sidebar/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "list icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        My Projects\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      var child2 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 12,
                "column": 4
              },
              "end": {
                "line": 15,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/components/navbar-sidebar/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "users icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        Users\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      var child3 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 16,
                "column": 4
              },
              "end": {
                "line": 19,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/components/navbar-sidebar/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "users icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        My Registrations\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 2,
              "column": 0
            },
            "end": {
              "line": 20,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/navbar-sidebar/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          morphs[1] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          morphs[2] = dom.createMorphAt(fragment, 2, 2, contextualElement);
          morphs[3] = dom.createMorphAt(fragment, 3, 3, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "link-to", ["index"], ["invokeAction", ["subexpr", "action", ["closeMenu"], [], ["loc", [null, [4, 36], [4, 56]]]], "class", "item"], 0, null, ["loc", [null, [4, 4], [7, 16]]]], ["block", "link-to", ["projects"], ["invokeAction", ["subexpr", "action", ["closeMenu"], [], ["loc", [null, [8, 39], [8, 59]]]], "class", "item"], 1, null, ["loc", [null, [8, 4], [11, 16]]]], ["block", "link-to", ["users"], ["invokeAction", ["subexpr", "action", ["closeMenu"], [], ["loc", [null, [12, 36], [12, 56]]]], "class", "item"], 2, null, ["loc", [null, [12, 4], [15, 16]]]], ["block", "link-to", ["registrations"], ["invokeAction", ["subexpr", "action", ["closeMenu"], [], ["loc", [null, [16, 44], [16, 64]]]], "class", "item"], 3, null, ["loc", [null, [16, 4], [19, 16]]]]],
        locals: [],
        templates: [child0, child1, child2, child3]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 21,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/navbar-sidebar/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/navbar-sidebar/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["block", "ui-sidebar", [], ["class", "ui inverted left compact vertical sidebar labeled icon menu", "context", ".component.context", "id", "sub-sidebar"], 0, null, ["loc", [null, [2, 0], [20, 15]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/oauth-popup/component', ['exports', 'ember-osf/components/oauth-popup/component', 'ember-craft-repository/pods/components/oauth-popup/template'], function (exports, _emberOsfComponentsOauthPopupComponent, _emberCraftRepositoryPodsComponentsOauthPopupTemplate) {
    exports['default'] = _emberOsfComponentsOauthPopupComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsOauthPopupTemplate['default'],
        tagName: '',
        classNames: ['oauth']
    });
});
// app/pods/components/oauth-popup/component.js
define("ember-craft-repository/pods/components/oauth-popup/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 2,
              "column": 0
            },
            "end": {
              "line": 4,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/oauth-popup/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("button");
          dom.setAttribute(el1, "class", "ui yellow button");
          var el2 = dom.createTextNode("Login");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var morphs = new Array(1);
          morphs[0] = dom.createElementMorph(element0);
          return morphs;
        },
        statements: [["element", "action", ["login"], [], ["loc", [null, [3, 12], [3, 30]]]]],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 4,
              "column": 0
            },
            "end": {
              "line": 6,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/oauth-popup/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["inline", "yield", [["get", "this", ["loc", [null, [5, 12], [5, 16]]]]], [], ["loc", [null, [5, 4], [5, 18]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 7,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/oauth-popup/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/oauth-popup/template.js ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["block", "if", [["subexpr", "not", [["get", "hasBlock", ["loc", [null, [2, 11], [2, 19]]]]], [], ["loc", [null, [2, 6], [2, 20]]]]], [], 0, 1, ["loc", [null, [2, 0], [6, 7]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/pagination-control-ui/component', ['exports', 'ember-osf/components/pagination-control/component', 'ember-craft-repository/pods/components/pagination-control-ui/template'], function (exports, _emberOsfComponentsPaginationControlComponent, _emberCraftRepositoryPodsComponentsPaginationControlUiTemplate) {
    exports['default'] = _emberOsfComponentsPaginationControlComponent['default'].extend({
        // TODO:0 ember-issue:11678 Cannot use input helper with onchange attribute issue:2
        layout: _emberCraftRepositoryPodsComponentsPaginationControlUiTemplate['default'],
        tagName: '',
        classNames: ['pagination']
    });
});
// app/pods/components/pagination-control/component.js
define("ember-craft-repository/pods/components/pagination-control-ui/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 29,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/pagination-control-ui/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/pagination-control/template.js ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui two item stackable mini secondary pagination menu");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "item");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui form pagination-form");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "inline field");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "ui small right labeled input");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("label");
        dom.setAttribute(el6, "class", "ui basic label");
        var el7 = dom.createTextNode("Page");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                        ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("input");
        dom.setAttribute(el6, "type", "text");
        dom.setAttribute(el6, "class", "page-input");
        dom.setAttribute(el6, "size", "4");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("label");
        dom.setAttribute(el6, "class", "ui basic label");
        var el7 = dom.createTextNode(" of ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("label");
        dom.setAttribute(el6, "class", "ui basic label");
        var el7 = dom.createComment("");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "item");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "field");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("button");
        dom.setAttribute(el4, "class", "tiny ui left attached button");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("i");
        dom.setAttribute(el5, "class", "fitted left arrow icon");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                Previous\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("button");
        dom.setAttribute(el4, "class", "tiny right attached ui button");
        var el5 = dom.createTextNode("\n                Next\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("i");
        dom.setAttribute(el5, "class", "fitted right arrow icon");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var element1 = dom.childAt(element0, [1, 1, 1, 1]);
        var element2 = dom.childAt(element1, [3]);
        var element3 = dom.childAt(element0, [3, 1]);
        var element4 = dom.childAt(element3, [1]);
        var element5 = dom.childAt(element3, [3]);
        var morphs = new Array(7);
        morphs[0] = dom.createAttrMorph(element2, 'value');
        morphs[1] = dom.createAttrMorph(element2, 'onchange');
        morphs[2] = dom.createMorphAt(dom.childAt(element1, [7]), 0, 0);
        morphs[3] = dom.createAttrMorph(element4, 'disabled');
        morphs[4] = dom.createElementMorph(element4);
        morphs[5] = dom.createAttrMorph(element5, 'disabled');
        morphs[6] = dom.createElementMorph(element5);
        return morphs;
      },
      statements: [["attribute", "value", ["get", "currentPage", ["loc", [null, [8, 51], [8, 62]]]]], ["attribute", "onchange", ["subexpr", "action", ["goToPage"], ["value", "target.value"], ["loc", [null, [8, 74], [8, 116]]]]], ["content", "pageCount", ["loc", [null, [11, 50], [11, 63]]]], ["attribute", "disabled", ["get", "disablePageReverse", ["loc", [null, [18, 90], [18, 108]]]]], ["element", "action", ["previous"], [], ["loc", [null, [18, 57], [18, 78]]]], ["attribute", "disabled", ["get", "disablePageForward", ["loc", [null, [22, 87], [22, 105]]]]], ["element", "action", ["next"], [], ["loc", [null, [22, 58], [22, 75]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/project-child-create/component', ['exports', 'ember', 'ember-craft-repository/pods/components/project-child-create/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectChildCreateTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsProjectChildCreateTemplate['default'],
        tagName: '',
        classNames: ['project', 'child', 'create'],
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        toast: _ember['default'].inject.service(),
        actions: {
            requestProjectChildCreate: function requestProjectChildCreate(name) {
                // jshint ignore:line
                $('.ui.modal.project.child.create').modal('setting', 'closable', false).modal('show'); // jshint ignore:line
            },
            confirmProjectChildCreate: function confirmProjectChildCreate(name) {
                // jshint ignore:line
                var self = this;
                var project = this.get('store').createRecord('node', {
                    title: this.get('title'),
                    category: 'project',
                    description: this.get('description') || null
                });

                project.save().then(function () {
                    console.log("Success!");
                    self.set('title', '');
                    self.set('description', '');
                    self.get('toast').success('File uploaded successfully');
                    _ember['default'].run.once(function () {
                        self.sendAction('reloadRoute');
                    });
                }, function (error) {
                    console.log("Error Saving Record: " + error.message);self.set('title', '');
                    self.set('description', '');
                    self.get('toast').error('There was an error creating your project.');
                });
            },
            cancelProjectChildCreate: function cancelProjectChildCreate(name) {
                // jshint ignore:line
                this.set('title', '');
                this.set('description', '');
                $('.ui.modal.project.child.create').modal().modal('hide'); // jshint ignore:line
            }
        }
    });
});
// app/pods/components/child-project-create/component.js
define("ember-craft-repository/pods/components/project-child-create/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 8,
              "column": 0
            },
            "end": {
              "line": 37,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-child-create/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "close icon");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "header");
          var el2 = dom.createTextNode("\n        Create Child Project?\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "content");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui two column stackable grid");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "column");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          dom.setAttribute(el4, "class", "bold");
          var el5 = dom.createTextNode("Title:");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "ui fluid input");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "column");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          dom.setAttribute(el4, "class", "bold");
          var el5 = dom.createTextNode("Description (optional):");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "ui fluid input");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "actions");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui black cancel button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "close icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Cancel\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui green approve right labeled icon button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "checkmark icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Create\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [5, 1]);
          var element1 = dom.childAt(fragment, [7]);
          var element2 = dom.childAt(element1, [1]);
          var element3 = dom.childAt(element1, [3]);
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 3]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element0, [3, 3]), 1, 1);
          morphs[2] = dom.createElementMorph(element2);
          morphs[3] = dom.createElementMorph(element3);
          return morphs;
        },
        statements: [["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "title", ["loc", [null, [18, 46], [18, 51]]]]], [], []], "placeholder", "Project Title", "required", true], ["loc", [null, [18, 20], [18, 95]]]], ["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "description", ["loc", [null, [24, 46], [24, 57]]]]], [], []], "placeholder", "Project Description"], ["loc", [null, [24, 20], [24, 93]]]], ["element", "action", ["cancelProjectChildCreate", "project-create"], [], ["loc", [null, [30, 47], [30, 101]]]], ["element", "action", ["confirmProjectChildCreate"], [], ["loc", [null, [33, 67], [33, 105]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 59,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/project-child-create/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/child-project-create/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        dom.setAttribute(el1, "class", "ui tiny fluid button");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("i");
        dom.setAttribute(el2, "class", "plus icon");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode(" Create Child Project\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element4 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createElementMorph(element4);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        return morphs;
      },
      statements: [["element", "action", ["requestProjectChildCreate", "project-child-create"], [], ["loc", [null, [3, 37], [3, 98]]]], ["block", "ui-modal", [], ["name", "project-child-create", "class", "project child create"], 0, null, ["loc", [null, [8, 0], [37, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/project-create/component', ['exports', 'ember', 'ember-craft-repository/pods/components/project-create/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectCreateTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsProjectCreateTemplate['default'],
        tagName: '',
        classNames: ['project', 'create'],
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        toast: _ember['default'].inject.service(),
        actions: {
            requestProjectCreate: function requestProjectCreate(name) {
                // jshint ignore:line
                $('.ui.modal.project.create').modal('setting', 'closable', false).modal('show'); // jshint ignore:line
            },
            confirmProjectCreate: function confirmProjectCreate(name) {
                // jshint ignore:line
                var self = this;
                var project = this.get('store').createRecord('node', {
                    title: this.get('title'),
                    category: 'project',
                    description: this.get('description') || null
                });

                project.save().then(function () {
                    console.log("Success!");
                    self.set('title', '');
                    self.set('description', '');
                    self.get('toast').success('Project created successfully');
                    _ember['default'].run.once(function () {
                        self.sendAction('reloadRoute');
                    });
                }, function (error) {
                    console.log("Error Saving Record: " + error.message);
                    self.set('title', '');
                    self.set('description', '');
                    self.get('toast').error('There was an error creating your project.');
                });
            },
            cancelProjectCreate: function cancelProjectCreate(name) {
                // jshint ignore:line
                this.set('title', '');
                this.set('description', '');
                $('.ui.modal.project.create').modal().modal('hide'); // jshint ignore:line
            }
        }
    });
});
// app/pods/components/projects-list/component.js
define("ember-craft-repository/pods/components/project-create/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 8,
              "column": 0
            },
            "end": {
              "line": 37,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-create/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "close icon");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "header");
          var el2 = dom.createTextNode("\n        Create Project?\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "content");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui two column stackable grid");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "column");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          dom.setAttribute(el4, "class", "bold");
          var el5 = dom.createTextNode("Title:");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "ui fluid input");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "column");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("label");
          dom.setAttribute(el4, "class", "bold");
          var el5 = dom.createTextNode("Description (optional):");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "ui fluid input");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "actions");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui black cancel button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "close icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Cancel\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui green approve right labeled icon button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "checkmark icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Create\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [5, 1]);
          var element1 = dom.childAt(fragment, [7]);
          var element2 = dom.childAt(element1, [1]);
          var element3 = dom.childAt(element1, [3]);
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 3]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element0, [3, 3]), 1, 1);
          morphs[2] = dom.createElementMorph(element2);
          morphs[3] = dom.createElementMorph(element3);
          return morphs;
        },
        statements: [["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "title", ["loc", [null, [18, 46], [18, 51]]]]], [], []], "placeholder", "Project Title", "required", true], ["loc", [null, [18, 20], [18, 95]]]], ["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "description", ["loc", [null, [24, 46], [24, 57]]]]], [], []], "placeholder", "Project Description"], ["loc", [null, [24, 20], [24, 93]]]], ["element", "action", ["cancelProjectCreate", "project-create"], [], ["loc", [null, [30, 47], [30, 96]]]], ["element", "action", ["confirmProjectCreate"], [], ["loc", [null, [33, 67], [33, 100]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 59,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/project-create/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/project-create.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        dom.setAttribute(el1, "class", "ui blue button");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("i");
        dom.setAttribute(el2, "class", "plus icon");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode(" Create Project\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element4 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createElementMorph(element4);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        return morphs;
      },
      statements: [["element", "action", ["requestProjectCreate", "create-project"], [], ["loc", [null, [3, 31], [3, 81]]]], ["block", "ui-modal", [], ["name", "project-create", "class", "project create"], 0, null, ["loc", [null, [8, 0], [37, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/project-delete/component', ['exports', 'ember', 'ember-craft-repository/pods/components/project-delete/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectDeleteTemplate) {
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsProjectDeleteTemplate['default'],
        tagName: '',
        classNames: ['project', 'delete'],
        toast: _ember['default'].inject.service(),
        routing: _ember['default'].inject.service('-routing'),
        selectedModel: '',
        actions: {
            requestDelete: function requestDelete(name) {
                this.set('selectedModel', this.get('project'));
                this.selectedModel.deleteRecord();
                $('.ui.project.delete.modal').modal('setting', 'closable', false).modal('show'); // jshint ignore:line
            },
            confirmDelete: function confirmDelete() {
                // TODO: Need to add error handling
                var self = this;
                this.selectedModel.save().then(function () {
                    self.get('toast').success('Project deleted successfully');
                    self.get('routing').transitionTo('projects.index');
                });
            },
            cancelDelete: function cancelDelete() {
                this.selectedModel.rollbackAttributes();
            }
        }
    });
});
// app/pods/components/project-edit/component.js
define("ember-craft-repository/pods/components/project-delete/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 9,
              "column": 0
            },
            "end": {
              "line": 25,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-delete/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "close icon");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "header");
          var el2 = dom.createTextNode("\n        Delete Project?\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "content");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createTextNode("Are you sure you want to delete this project: ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("?");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "actions");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui black cancel button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "close icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Cancel\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui red approve right labeled icon button");
          var el3 = dom.createTextNode("\n            Delete?");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "checkmark icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [5, 1]), 1, 1);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [15, 57], [15, 74]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 26,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/project-delete/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/project-delete/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        dom.setAttribute(el1, "class", "ui tiny fluid button");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("i");
        dom.setAttribute(el2, "class", "remove icon");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    Delete this Project\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createElementMorph(element0);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["element", "action", ["requestDelete", "delete-project"], [], ["loc", [null, [3, 37], [3, 80]]]], ["block", "ui-modal", [], ["name", "project-delete", "class", "project delete", "onApprove", ["subexpr", "action", ["confirmDelete"], [], ["loc", [null, [9, 67], [9, 91]]]], "onDeny", ["subexpr", "action", ["cancelDelete"], [], ["loc", [null, [9, 99], [9, 122]]]]], 0, null, ["loc", [null, [9, 0], [25, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/project-edit/component', ['exports', 'ember', 'ember-craft-repository/pods/components/project-edit/template', 'ember-osf/mixins/node-actions'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectEditTemplate, _emberOsfMixinsNodeActions) {
    exports['default'] = _ember['default'].Component.extend(_emberOsfMixinsNodeActions['default'], {
        layout: _emberCraftRepositoryPodsComponentsProjectEditTemplate['default'],
        tagName: '',
        classNames: ['project', 'edit'],
        toast: _ember['default'].inject.service(),
        isSaving: false,
        editedTitle: null,
        editedDescription: null,
        isPublic: null,
        editedCategory: null,
        categories: null,
        selectedCategory: null,
        init: function init() {
            this._super.apply(this, arguments);
            this.set('selectedCategory', this.get('project.category'));

            var categories = [{
                "value": "analysis",
                "description": "Analysis"
            }, {
                "value": "communication",
                "description": "Communication"
            }, {
                "value": "data",
                description: "Data"
            }, {
                "value": "hypothesis",
                "description": "Hypothesis"
            }, {
                "value": "instrumentation",
                "description": "Instrumentation"
            }, {
                "value": "methods and measures",
                "description": "Methods and Measures"
            }, {
                "value": "procedure",
                "description": "Procedure"
            }, {
                "value": "project",
                "description": "Project"
            }, {
                "value": "analysis",
                "description": "Analysis"
            }, {
                "value": "software",
                "description": "Software"
            }, {
                "value": "other",
                "description": "Other"
            }];

            this.set('categories', categories);
            this.set('selectedModel', this.get('project'));

            if (!this.get('_node')) {
                this.set('_node', this.get('selectedModel'));
            }
        },
        actions: {
            openProjectEdit: function openProjectEdit(name) {
                // jshint ignore:line
                $('.ui.project.edit.modal').modal('show'); // jshint ignore:line
            },
            categoryChange: function categoryChange(component) {
                this.set('editedCategory', component);
            },
            isPublicChange: function isPublicChange(value) {
                var prevSelection = this.get('project.public');

                if (value !== prevSelection) {
                    this.set('isPublic', value);
                } else {
                    this.set('isPublic', null);
                }
            },
            updateProject: function updateProject(editedTitle, editedDescription, editedCategory, isPublic) {
                this.set('isSaving', true);

                if (this.get('project.data.currentUserPermissions') === "read,write,admin") {
                    this.send('updateNode', editedTitle, editedDescription, editedCategory, isPublic);
                    this.get('toast').success('Project updated successfully');
                    this.set('editedTitle', null);
                    this.set('editedDescription', null);
                    this.set('editedCategory', null);
                    this.set('isPublic', null);
                    this.set('isSaving', false);
                } else {
                    this.set('isSaving', false);
                    this.selectedModel.rollbackAttributes();
                    this.get('toast').error('You do not have permission to edit this project');
                    console.log("You do not have permission to edit this project");
                }
            },
            cancelProjectEdit: function cancelProjectEdit() {
                this.selectedModel.rollbackAttributes();
            }
        }
    });
});
// app/pods/components/project-edit/component.js
define("ember-craft-repository/pods/components/project-edit/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 37,
                  "column": 32
                },
                "end": {
                  "line": 41,
                  "column": 32
                }
              },
              "moduleName": "ember-craft-repository/pods/components/project-edit/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                                    ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("div");
              dom.setAttribute(el1, "class", "item");
              var el2 = dom.createTextNode("\n                                        ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("\n                                    ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var element0 = dom.childAt(fragment, [1]);
              var morphs = new Array(2);
              morphs[0] = dom.createAttrMorph(element0, 'data-value');
              morphs[1] = dom.createMorphAt(element0, 1, 1);
              return morphs;
            },
            statements: [["attribute", "data-value", ["concat", [["subexpr", "map-value", [["get", "mapper", ["loc", [null, [38, 78], [38, 84]]]], ["get", "category.value", ["loc", [null, [38, 85], [38, 99]]]]], [], ["loc", [null, [38, 66], [38, 101]]]]]]], ["content", "category.description", ["loc", [null, [39, 40], [39, 64]]]]],
            locals: ["category"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 32,
                "column": 24
              },
              "end": {
                "line": 43,
                "column": 24
              }
            },
            "moduleName": "ember-craft-repository/pods/components/project-edit/template.hbs"
          },
          isEmpty: false,
          arity: 2,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "default text");
            var el2 = dom.createTextNode("Categories");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "dropdown icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                            ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "menu");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("                            ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [5]), 1, 1);
            return morphs;
          },
          statements: [["block", "each", [["get", "categories", ["loc", [null, [37, 40], [37, 50]]]]], [], 0, null, ["loc", [null, [37, 32], [41, 41]]]]],
          locals: ["execute", "mapper"],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 9,
              "column": 0
            },
            "end": {
              "line": 72,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-edit/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "close icon");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "header");
          var el2 = dom.createTextNode("\n        Edit Project: ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "content");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui form");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "ui two column stackable grid");
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "column");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("label");
          dom.setAttribute(el5, "class", "bold");
          var el6 = dom.createTextNode("Title:");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "ui fluid input");
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          var el6 = dom.createComment("");
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                    ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "column");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("label");
          dom.setAttribute(el5, "class", "bold");
          var el6 = dom.createTextNode("Description (optional):");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "ui fluid input");
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          var el6 = dom.createComment("");
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                    ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "column");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("label");
          dom.setAttribute(el5, "class", "bold");
          var el6 = dom.createTextNode("Category:");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "ui fluid input");
          var el6 = dom.createTextNode("\n");
          dom.appendChild(el5, el6);
          var el6 = dom.createComment("");
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("                    ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "column");
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("label");
          dom.setAttribute(el5, "class", "bold");
          var el6 = dom.createTextNode("Privacy Settings:");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "inline fields");
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          var el6 = dom.createElement("div");
          dom.setAttribute(el6, "class", "inline field");
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createComment("");
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                        ");
          dom.appendChild(el6, el7);
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          var el6 = dom.createElement("div");
          dom.setAttribute(el6, "class", "inline field");
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          var el7 = dom.createComment("");
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                        ");
          dom.appendChild(el6, el7);
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                    ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n            ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "actions");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui black deny button");
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "close icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("Cancel\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "ui positive right labeled icon button");
          var el3 = dom.createTextNode("\n            Save changes\n            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("i");
          dom.setAttribute(el3, "class", "checkmark icon");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element1 = dom.childAt(fragment, [5, 1, 1]);
          var element2 = dom.childAt(element1, [7, 3]);
          var element3 = dom.childAt(fragment, [7]);
          var element4 = dom.childAt(element3, [1]);
          var element5 = dom.childAt(element3, [3]);
          var morphs = new Array(9);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element1, [1, 3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element1, [3, 3]), 1, 1);
          morphs[3] = dom.createMorphAt(dom.childAt(element1, [5, 3]), 1, 1);
          morphs[4] = dom.createMorphAt(dom.childAt(element2, [1]), 1, 1);
          morphs[5] = dom.createMorphAt(dom.childAt(element2, [3]), 1, 1);
          morphs[6] = dom.createElementMorph(element4);
          morphs[7] = dom.createAttrMorph(element5, 'disabled');
          morphs[8] = dom.createElementMorph(element5);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [12, 22], [12, 39]]]], ["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "editedTitle", ["loc", [null, [20, 50], [20, 61]]]]], [], []], "placeholder", "Project Title"], ["loc", [null, [20, 24], [20, 91]]]], ["inline", "input", [], ["type", "text", "value", ["subexpr", "@mut", [["get", "editedDescription", ["loc", [null, [26, 50], [26, 67]]]]], [], []], "placeholder", "Project Description"], ["loc", [null, [26, 24], [26, 103]]]], ["block", "ui-dropdown", [], ["class", "selection", "selected", ["subexpr", "@mut", [["get", "selectedCategory", ["loc", [null, [32, 66], [32, 82]]]]], [], []], "onChange", ["subexpr", "action", ["categoryChange"], [], ["loc", [null, [33, 37], [33, 62]]]]], 0, null, ["loc", [null, [32, 24], [43, 40]]]], ["inline", "ui-radio", [], ["name", "isPublic", "value", true, "current", ["subexpr", "@mut", [["get", "project.public", ["loc", [null, [50, 74], [50, 88]]]]], [], []], "label", "Public", "onChange", ["subexpr", "action", ["isPublicChange"], ["value", ["get", "target.value", ["loc", [null, [51, 72], [51, 84]]]]], ["loc", [null, [51, 41], [51, 85]]]]], ["loc", [null, [50, 28], [51, 87]]]], ["inline", "ui-radio", [], ["name", "isPublic", "value", false, "current", ["subexpr", "@mut", [["get", "project.public", ["loc", [null, [54, 75], [54, 89]]]]], [], []], "label", "Private", "onChange", ["subexpr", "action", ["isPublicChange"], ["value", ["get", "target.value", ["loc", [null, [55, 72], [55, 84]]]]], ["loc", [null, [55, 41], [55, 85]]]]], ["loc", [null, [54, 28], [55, 87]]]], ["element", "action", ["cancelProjectEdit", "project-edit"], [], ["loc", [null, [63, 16], [63, 61]]]], ["attribute", "disabled", ["get", "isSaving", ["loc", [null, [66, 27], [66, 35]]]]], ["element", "action", ["updateProject", ["get", "editedTitle", ["loc", [null, [66, 63], [66, 74]]]], ["get", "editedDescription", ["loc", [null, [66, 75], [66, 92]]]], ["get", "editedCategory", ["loc", [null, [67, 8], [67, 22]]]], ["get", "isPublic", ["loc", [null, [67, 23], [67, 31]]]]], [], ["loc", [null, [66, 38], [67, 33]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 73,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/project-edit/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/project-edit/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        dom.setAttribute(el1, "class", "ui tiny fluid button");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("i");
        dom.setAttribute(el2, "class", "edit icon");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    Edit Project\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element6 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createElementMorph(element6);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["element", "action", ["openProjectEdit", "project-edit"], [], ["loc", [null, [3, 8], [3, 51]]]], ["block", "ui-modal", [], ["name", "project-edit", "class", "project edit", "onDeny", ["subexpr", "action", ["cancelProjectEdit"], [], ["loc", [null, [9, 60], [9, 88]]]]], 0, null, ["loc", [null, [9, 0], [72, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/project-summary/component', ['exports', 'ember', 'ember-craft-repository/pods/components/project-summary/template'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectSummaryTemplate) {
    var _slice = Array.prototype.slice;
    exports['default'] = _ember['default'].Component.extend({
        layout: _emberCraftRepositoryPodsComponentsProjectSummaryTemplate['default'],
        attributeBindings: ['elementId:id'],
        elementId: 'project-summary',
        classNames: ['project', 'summary', 'ui', 'segments'],
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        // init() {
        //     this._super(...arguments);
        // },
        actions: {
            addATag: function addATag() {
                this.sendAction.apply(this, ['addATag'].concat(_slice.call(arguments)));
            },
            removeATag: function removeATag() {
                this.sendAction.apply(this, ['removeATag'].concat(_slice.call(arguments)));
            }
        }
    });
});
// app/pods/components/project-summary/component.js
define("ember-craft-repository/pods/components/project-summary/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 9,
              "column": 16
            },
            "end": {
              "line": 11,
              "column": 16
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-summary/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("a");
          dom.setAttribute(el1, "class", "ui large black label");
          var el2 = dom.createTextNode("Public");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 11,
              "column": 16
            },
            "end": {
              "line": 13,
              "column": 16
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-summary/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("a");
          dom.setAttribute(el1, "class", "ui large black label");
          var el2 = dom.createTextNode("Private");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    var child2 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 37,
              "column": 16
            },
            "end": {
              "line": 44,
              "column": 16
            }
          },
          "moduleName": "ember-craft-repository/pods/components/project-summary/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "item");
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "content");
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("span");
          dom.setAttribute(el3, "class", "left floated ui blue header");
          var el4 = dom.createTextNode("Description: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                        ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("span");
          dom.setAttribute(el3, "class", "right floated");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode(" ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                    ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1, 1, 3]), 0, 0);
          return morphs;
        },
        statements: [["content", "model.description", ["loc", [null, [41, 52], [41, 73]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 74,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/project-summary/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/project-summary/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("    ");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segment");
        var el2 = dom.createTextNode("\n        ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui two column grid");
        var el3 = dom.createTextNode("\n            ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "column");
        var el4 = dom.createTextNode("\n                ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("h3");
        dom.setAttribute(el4, "class", "ui header");
        var el5 = dom.createComment("");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n            ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "right aligned column");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("            ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n    ");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segment");
        var el2 = dom.createTextNode("\n            ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui middle aligned divided list");
        var el3 = dom.createTextNode("\n                ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "item");
        var el4 = dom.createTextNode("\n                    ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "content");
        var el5 = dom.createTextNode("\n                        ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("span");
        dom.setAttribute(el5, "class", "left floated ui blue header");
        var el6 = dom.createTextNode("Date Created: ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                        ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("span");
        dom.setAttribute(el5, "class", "right floated");
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                    ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n                ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n                ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "item");
        var el4 = dom.createTextNode("\n                    ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "content");
        var el5 = dom.createTextNode("\n                        ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("span");
        dom.setAttribute(el5, "class", "left floated ui blue header");
        var el6 = dom.createTextNode("Date Modified: ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                        ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("span");
        dom.setAttribute(el5, "class", "right floated");
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                    ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n                ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n                ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "item");
        var el4 = dom.createTextNode("\n                    ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "content");
        var el5 = dom.createTextNode("\n                        ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("span");
        dom.setAttribute(el5, "class", "left floated ui blue header");
        var el6 = dom.createTextNode("Type: ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                        ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("span");
        dom.setAttribute(el5, "class", "right floated");
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                    ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n                ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("            ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n            ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui header");
        var el3 = dom.createTextNode("Tags");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n            ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n    ");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui stackable grid segment");
        var el2 = dom.createTextNode("\n        ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "six wide column");
        var el3 = dom.createTextNode("\n            ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui header");
        var el4 = dom.createTextNode("Tools");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n        ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ten wide column");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("                ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n                    ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "style", "margin: 2px");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("                ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n            ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "style", "margin: 2px");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("                ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("        ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [3, 1]);
        var element1 = dom.childAt(fragment, [5]);
        var element2 = dom.childAt(element1, [1]);
        var element3 = dom.childAt(fragment, [7, 3]);
        var morphs = new Array(10);
        morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 1]), 0, 0);
        morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
        morphs[2] = dom.createMorphAt(dom.childAt(element2, [1, 1, 3]), 0, 0);
        morphs[3] = dom.createMorphAt(dom.childAt(element2, [3, 1, 3]), 0, 0);
        morphs[4] = dom.createMorphAt(dom.childAt(element2, [5, 1, 3]), 0, 0);
        morphs[5] = dom.createMorphAt(element2, 7, 7);
        morphs[6] = dom.createMorphAt(element1, 5, 5);
        morphs[7] = dom.createMorphAt(element3, 2, 2);
        morphs[8] = dom.createMorphAt(element3, 7, 7);
        morphs[9] = dom.createMorphAt(element3, 12, 12);
        return morphs;
      },
      statements: [["content", "model.title", ["loc", [null, [6, 38], [6, 53]]]], ["block", "if", [["get", "model.public", ["loc", [null, [9, 22], [9, 34]]]]], [], 0, 1, ["loc", [null, [9, 16], [13, 23]]]], ["inline", "moment-from-now", [["get", "model.dateCreated", ["loc", [null, [22, 70], [22, 87]]]]], [], ["loc", [null, [22, 52], [22, 89]]]], ["inline", "moment-from-now", [["get", "model.dateModified", ["loc", [null, [28, 70], [28, 88]]]]], [], ["loc", [null, [28, 52], [28, 90]]]], ["inline", "capitalize", [["get", "model.category", ["loc", [null, [34, 65], [34, 79]]]]], [], ["loc", [null, [34, 52], [34, 81]]]], ["block", "if", [["get", "model.description", ["loc", [null, [37, 22], [37, 39]]]]], [], 2, null, ["loc", [null, [37, 16], [44, 23]]]], ["inline", "tags-widget", [], ["addATag", ["subexpr", "action", ["addATag", ["get", "model", ["loc", [null, [47, 52], [47, 57]]]]], [], ["loc", [null, [47, 34], [47, 58]]]], "removeATag", ["subexpr", "action", ["removeATag", ["get", "model", ["loc", [null, [47, 91], [47, 96]]]]], [], ["loc", [null, [47, 70], [47, 97]]]], "tags", ["subexpr", "@mut", [["get", "model.tags", ["loc", [null, [47, 103], [47, 113]]]]], [], []]], ["loc", [null, [47, 12], [47, 115]]]], ["inline", "project-edit", [], ["project", ["subexpr", "@mut", [["get", "model", ["loc", [null, [56, 39], [56, 44]]]]], [], []]], ["loc", [null, [56, 16], [56, 46]]]], ["content", "project-child-create", ["loc", [null, [59, 16], [59, 40]]]], ["inline", "project-delete", [], ["project", ["subexpr", "@mut", [["get", "model", ["loc", [null, [63, 41], [63, 46]]]]], [], []]], ["loc", [null, [63, 16], [63, 48]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/components/projects-cards/component', ['exports', 'ember', 'ember-craft-repository/pods/components/projects-cards/template', 'ember-craft-repository/mixins/paginated-component'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectsCardsTemplate, _emberCraftRepositoryMixinsPaginatedComponent) {
    exports['default'] = _ember['default'].Component.extend(_emberCraftRepositoryMixinsPaginatedComponent['default'], {
        layout: _emberCraftRepositoryPodsComponentsProjectsCardsTemplate['default'],
        currentUser: _ember['default'].inject.service(),
        user: null,
        attributeBindings: ['elementId:id'],
        elementId: 'projects-cards',
        classNames: ['projects', 'cards'],
        isLoading: true,
        pageSize: null,
        isPublic: false,
        init: function init() {
            this._super.apply(this, arguments);

            if (this.get('session.isAuthenticated')) {
                this._setCurrentUser();
            }
        },
        _setCurrentUser: function _setCurrentUser() {
            var _this = this;

            this.get('currentUser').load().then(function (user) {
                return _this.set('user', user);
            });
        },
        onGetCurrentUser: _ember['default'].observer('user', function () {
            this.loadProfileList();
        }),
        loadProfileList: function loadProfileList() {
            var _this2 = this;

            var user = this.get('user');

            if (user) {
                this.set('user', user);
            } else {
                user = this.get('store').findRecord('user', 'me');
                this.set('user', user);
            }

            var routeParams = {
                page: this.get('page'),
                page_size: this.get('pageSize')
            };

            var userParams = {
                filter: {
                    contributors: this.get('user.id'),
                    'public': this.get('isPublic')
                }
            };

            // console.log('Page: ', this.get('page'));
            this.queryForComponent('node', routeParams, userParams).then(function () {
                _this2.send('hideLoading');
            });
        },
        actions: {
            next: function next() {
                this.send('showLoading');
                this.incrementProperty('page', 1);
                this.loadProfileList();
            },
            previous: function previous() {
                this.send('showLoading');
                this.decrementProperty('page', 1);
                this.loadProfileList();
            },
            goToPage: function goToPage(pageNumber) {
                this.send('showLoading');
                this.set('page', pageNumber);
                this.loadProfileList();
            },
            hideLoading: function hideLoading() {
                this.set('isLoading', false);
                if (!this.get('isLoading')) {
                    $('.loading.widget.private').hide();
                }
            },
            showLoading: function showLoading() {
                this.set('isLoading', true);
                if (this.get('isLoading')) {
                    $('.loading.widget.private').show();
                }
            }
        }
    });
});
// app/pods/components/projects-cards/component.js
define("ember-craft-repository/pods/components/projects-cards/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 22,
                "column": 16
              },
              "end": {
                "line": 24,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/components/projects-cards/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                 Detail ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "expand icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 6,
              "column": 4
            },
            "end": {
              "line": 27,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/projects-cards/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "ui fluid card");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "fluid image");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("img");
          dom.setAttribute(el3, "src", "/assets/images/chip.jpg");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "content");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "header");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "meta");
          var el4 = dom.createTextNode("\n                    ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("span");
          dom.setAttribute(el4, "class", "date");
          var el5 = dom.createTextNode("Last Updated on ");
          dom.appendChild(el4, el5);
          var el5 = dom.createComment("");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("br");
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                    Type: ");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "description");
          var el4 = dom.createTextNode("\n                    ");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "extra content");
          var el3 = dom.createTextNode("\n");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [3]);
          var element2 = dom.childAt(element1, [3]);
          var morphs = new Array(5);
          morphs[0] = dom.createMorphAt(dom.childAt(element1, [1]), 0, 0);
          morphs[1] = dom.createMorphAt(dom.childAt(element2, [1]), 1, 1);
          morphs[2] = dom.createMorphAt(element2, 4, 4);
          morphs[3] = dom.createMorphAt(dom.childAt(element1, [5]), 1, 1);
          morphs[4] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [12, 36], [12, 53]]]], ["inline", "moment-from-now", [["get", "project.dateModified", ["loc", [null, [14, 73], [14, 93]]]]], [], ["loc", [null, [14, 55], [14, 95]]]], ["inline", "capitalize", [["get", "project.category", ["loc", [null, [15, 39], [15, 55]]]]], [], ["loc", [null, [15, 26], [15, 57]]]], ["content", "project.description", ["loc", [null, [18, 20], [18, 43]]]], ["block", "link-to", ["projects.detail", ["get", "project.id", ["loc", [null, [22, 45], [22, 55]]]]], ["class", "ui bottom attached red labeled icon button"], 0, null, ["loc", [null, [22, 16], [24, 28]]]]],
        locals: ["project"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 40,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/projects-cards/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/projects-cards/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui three stackable doubling cards");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segment pagination");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element3 = dom.childAt(fragment, [2]);
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(element3, 2, 2);
        morphs[1] = dom.createMorphAt(element3, 4, 4);
        morphs[2] = dom.createMorphAt(dom.childAt(fragment, [4]), 1, 1);
        return morphs;
      },
      statements: [["inline", "loading-widget", [], ["isPrivate", true], ["loc", [null, [4, 4], [4, 37]]]], ["block", "each", [["get", "list", ["loc", [null, [6, 12], [6, 16]]]]], [], 0, null, ["loc", [null, [6, 4], [27, 13]]]], ["inline", "pagination-control-ui", [], ["currentPage", ["subexpr", "@mut", [["get", "page", ["loc", [null, [33, 20], [33, 24]]]]], [], []], "pageCount", ["subexpr", "@mut", [["get", "totalPages", ["loc", [null, [34, 18], [34, 28]]]]], [], []], "next", ["subexpr", "action", ["next"], [], ["loc", [null, [35, 13], [35, 28]]]], "previous", ["subexpr", "action", ["previous"], [], ["loc", [null, [36, 17], [36, 36]]]], "goToPage", ["subexpr", "action", ["goToPage"], [], ["loc", [null, [37, 17], [37, 36]]]]], ["loc", [null, [32, 4], [38, 6]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/projects-list/component', ['exports', 'ember', 'ember-craft-repository/pods/components/projects-list/template', 'ember-craft-repository/mixins/paginated-component'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectsListTemplate, _emberCraftRepositoryMixinsPaginatedComponent) {
    exports['default'] = _ember['default'].Component.extend(_emberCraftRepositoryMixinsPaginatedComponent['default'], {
        layout: _emberCraftRepositoryPodsComponentsProjectsListTemplate['default'],
        currentUser: _ember['default'].inject.service(),
        user: null,
        tagName: '',
        classNames: ['projects', 'list'],
        isLoading: true,
        init: function init() {
            this._super.apply(this, arguments);

            if (this.get('session.isAuthenticated')) {
                this._setCurrentUser();
            }
        },
        _setCurrentUser: function _setCurrentUser() {
            var _this = this;

            this.get('currentUser').load().then(function (user) {
                return _this.set('user', user);
            });
        },
        onGetCurrentUser: _ember['default'].observer('user', function () {
            this.loadProfileList();
        }),
        loadProfileList: function loadProfileList() {
            var user = this.get('user');

            if (user) {
                this.set('user', user);
            } else {
                user = this.get('store').findRecord('user', 'me');
                this.set('user', user);
            }

            var routeParams = {
                page: this.get('page'),
                page_size: null
            };

            var userParams = {
                filter: {
                    contributors: this.get('user.id')
                }
            };

            this.queryForComponent('node', routeParams, userParams);
        },
        willUpdate: function willUpdate() {
            this.set('isLoading', false);
            // console.log(this.get('isLoading', false));
        },
        actions: {
            next: function next() {
                this.incrementProperty('page', 1);
                this.loadProfileList();
            },
            previous: function previous() {
                this.decrementProperty('page', 1);
                this.loadProfileList();
            },
            goToPage: function goToPage(pageNumber) {
                this.set('page', pageNumber);
                this.loadProfileList();
            }
        }
    });
});
// app/pods/components/projects-list/component.js
define("ember-craft-repository/pods/components/projects-list/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 22,
              "column": 8
            },
            "end": {
              "line": 35,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/components/projects-list/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "ui active inverted dimmer");
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "ui big text loader");
          var el3 = dom.createTextNode("\n                    Loading...\n                ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 38,
                "column": 16
              },
              "end": {
                "line": 48,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/components/projects-list/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "left floated left aligned column");
            var el2 = dom.createTextNode("\n                        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("div");
            dom.setAttribute(el2, "class", "ui brown header");
            var el3 = dom.createTextNode("\n                            ");
            dom.appendChild(el2, el3);
            var el3 = dom.createElement("i");
            dom.setAttribute(el3, "class", "grey archive icon");
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode("\n                            ");
            dom.appendChild(el2, el3);
            var el3 = dom.createComment("");
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode("\n                        ");
            dom.appendChild(el2, el3);
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("div");
            dom.setAttribute(el1, "class", "right floated right aligned column");
            var el2 = dom.createTextNode("\n                        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(2);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1, 1]), 3, 3);
            morphs[1] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
            return morphs;
          },
          statements: [["content", "project.title", ["loc", [null, [42, 28], [42, 45]]]], ["inline", "moment-format", [["get", "project.dateModified", ["loc", [null, [46, 40], [46, 60]]]]], [], ["loc", [null, [46, 24], [46, 62]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 37,
              "column": 12
            },
            "end": {
              "line": 49,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/components/projects-list/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "link-to", ["projects.detail", ["get", "project.id", ["loc", [null, [38, 45], [38, 55]]]]], ["class", "row"], 0, null, ["loc", [null, [38, 16], [48, 28]]]]],
        locals: ["project"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 63,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/projects-list/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/templates/components/projects-list.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segments");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui inverted black segment");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui two column grid fluid");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "row");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "left floated left aligned column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("div");
        dom.setAttribute(el6, "class", "bold");
        var el7 = dom.createTextNode("\n                        Projects\n                    ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "right floated right aligned column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("div");
        dom.setAttribute(el6, "class", "content");
        var el7 = dom.createTextNode("\n                        Total Projects: ");
        dom.appendChild(el6, el7);
        var el7 = dom.createComment("");
        dom.appendChild(el6, el7);
        var el7 = dom.createTextNode("\n                    ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui segment");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui two column grid vertically fluid");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui inverted black segment pagination footbar");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var element1 = dom.childAt(element0, [3]);
        var morphs = new Array(4);
        morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 1, 1, 3, 1]), 1, 1);
        morphs[1] = dom.createMorphAt(element1, 1, 1);
        morphs[2] = dom.createMorphAt(dom.childAt(element1, [3]), 1, 1);
        morphs[3] = dom.createMorphAt(dom.childAt(element0, [6]), 1, 1);
        return morphs;
      },
      statements: [["content", "pagination.total", ["loc", [null, [14, 40], [14, 60]]]], ["block", "if", [["get", "isLoading", ["loc", [null, [22, 14], [22, 23]]]]], [], 0, null, ["loc", [null, [22, 8], [35, 15]]]], ["block", "each", [["get", "list", ["loc", [null, [37, 20], [37, 24]]]]], [], 1, null, ["loc", [null, [37, 12], [49, 21]]]], ["inline", "pagination-control-ui", [], ["currentPage", ["subexpr", "@mut", [["get", "page", ["loc", [null, [55, 24], [55, 28]]]]], [], []], "pageCount", ["subexpr", "@mut", [["get", "totalPages", ["loc", [null, [56, 22], [56, 32]]]]], [], []], "next", ["subexpr", "action", ["next"], [], ["loc", [null, [57, 17], [57, 32]]]], "previous", ["subexpr", "action", ["previous"], [], ["loc", [null, [58, 21], [58, 40]]]], "goToPage", ["subexpr", "action", ["goToPage"], [], ["loc", [null, [59, 21], [59, 40]]]]], ["loc", [null, [54, 8], [60, 10]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/components/projects-public-cards/component', ['exports', 'ember', 'ember-craft-repository/pods/components/projects-public-cards/template', 'ember-craft-repository/mixins/paginated-component'], function (exports, _ember, _emberCraftRepositoryPodsComponentsProjectsPublicCardsTemplate, _emberCraftRepositoryMixinsPaginatedComponent) {
    exports['default'] = _ember['default'].Component.extend(_emberCraftRepositoryMixinsPaginatedComponent['default'], {
        layout: _emberCraftRepositoryPodsComponentsProjectsPublicCardsTemplate['default'],
        currentUser: _ember['default'].inject.service(),
        user: null,
        attributeBindings: ['elementId:id'],
        elementId: 'projects-public-cards',
        classNames: ['projects', 'public', 'cards'],
        isLoading: true,
        pageSize: null,
        isPublic: false,
        init: function init() {
            this._super.apply(this, arguments);

            if (this.get('session.isAuthenticated')) {
                this._setCurrentUser();
            }
        },
        _setCurrentUser: function _setCurrentUser() {
            var _this = this;

            this.get('currentUser').load().then(function (user) {
                return _this.set('user', user);
            });
        },
        onGetCurrentUser: _ember['default'].observer('user', function () {
            this.loadProfileList();
        }),
        loadProfileList: function loadProfileList() {
            var _this2 = this;

            var user = this.get('user');

            if (user) {
                this.set('user', user);
            } else {
                user = this.get('store').findRecord('user', 'me');
                this.set('user', user);
            }

            var routeParams = {
                page: this.get('page'),
                page_size: this.get('pageSize')
            };

            var userParams = {
                filter: {
                    contributors: this.get('user.id'),
                    'public': this.get('isPublic')
                }
            };

            // console.log('Page: ', this.get('page'));
            this.queryForComponent('node', routeParams, userParams).then(function () {
                _this2.send('hideLoading');
            });
        },
        actions: {
            next: function next() {
                this.send('showLoading');
                this.incrementProperty('page', 1);
                this.loadProfileList();
            },
            previous: function previous() {
                this.send('showLoading');
                this.decrementProperty('page', 1);
                this.loadProfileList();
            },
            goToPage: function goToPage(pageNumber) {
                this.send('showLoading');
                this.set('page', pageNumber);
                this.loadProfileList();
            },
            hideLoading: function hideLoading() {
                this.set('isLoading', false);
                if (!this.get('isLoading')) {
                    $('.loading.widget.public').hide();
                }
            },
            showLoading: function showLoading() {
                this.set('isLoading', true);
                if (this.get('isLoading')) {
                    $('.loading.widget.public').show();
                }
            }
        }
    });
});
// app/pods/components/projects-public-cards/component.js
// import Ember from 'ember';
//
// export default Ember.Component.extend({});
define("ember-craft-repository/pods/components/projects-public-cards/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 17,
                "column": 20
              },
              "end": {
                "line": 21,
                "column": 20
              }
            },
            "moduleName": "ember-craft-repository/pods/components/projects-public-cards/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("span");
            dom.setAttribute(el1, "class", "contributor");
            var el2 = dom.createTextNode("\n                            ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n                        ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            return morphs;
          },
          statements: [["content", "contributor.users.fullName", ["loc", [null, [19, 28], [19, 58]]]]],
          locals: ["contributor"],
          templates: []
        };
      })();
      var child1 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 25,
                "column": 16
              },
              "end": {
                "line": 27,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/components/projects-public-cards/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    Detail ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("i");
            dom.setAttribute(el1, "class", "expand icon");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes() {
            return [];
          },
          statements: [],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 8,
              "column": 4
            },
            "end": {
              "line": 30,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/components/projects-public-cards/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "ui fluid card");
          dom.setAttribute(el1, "style", "min-height: 200px");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "content");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "header");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "description");
          var el4 = dom.createTextNode("\n                    ");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "meta contributor");
          var el4 = dom.createTextNode("\n                    by\n");
          dom.appendChild(el3, el4);
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "extra content");
          var el3 = dom.createTextNode("\n");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [1]);
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(element1, [1]), 0, 0);
          morphs[1] = dom.createMorphAt(dom.childAt(element1, [3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element1, [5]), 1, 1);
          morphs[3] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [11, 36], [11, 53]]]], ["content", "project.description", ["loc", [null, [13, 20], [13, 43]]]], ["block", "each", [["get", "project.contributors", ["loc", [null, [17, 28], [17, 48]]]]], [], 0, null, ["loc", [null, [17, 20], [21, 29]]]], ["block", "link-to", ["projects.detail", ["get", "project.id", ["loc", [null, [25, 45], [25, 55]]]]], ["class", "ui bottom attached labeled icon button"], 1, null, ["loc", [null, [25, 16], [27, 28]]]]],
        locals: ["project"],
        templates: [child0, child1]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 43,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/projects-public-cards/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/projects-public-cards/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui two doubling cards");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui segment pagination");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element2 = dom.childAt(fragment, [2]);
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(element2, 2, 2);
        morphs[1] = dom.createMorphAt(element2, 4, 4);
        morphs[2] = dom.createMorphAt(dom.childAt(fragment, [4]), 1, 1);
        return morphs;
      },
      statements: [["inline", "loading-widget", [], ["isPublic", true], ["loc", [null, [6, 4], [6, 36]]]], ["block", "each", [["get", "list", ["loc", [null, [8, 12], [8, 16]]]]], [], 0, null, ["loc", [null, [8, 4], [30, 13]]]], ["inline", "pagination-control-ui", [], ["currentPage", ["subexpr", "@mut", [["get", "page", ["loc", [null, [36, 20], [36, 24]]]]], [], []], "pageCount", ["subexpr", "@mut", [["get", "totalPages", ["loc", [null, [37, 18], [37, 28]]]]], [], []], "next", ["subexpr", "action", ["next"], [], ["loc", [null, [38, 13], [38, 28]]]], "previous", ["subexpr", "action", ["previous"], [], ["loc", [null, [39, 17], [39, 36]]]], "goToPage", ["subexpr", "action", ["goToPage"], [], ["loc", [null, [40, 17], [40, 36]]]]], ["loc", [null, [35, 4], [41, 6]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/components/projects-search/component', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Component.extend({
        tagName: '',
        classNames: ['project', 'search']
    });
});
// app/pods/components/projects-search/component.js
define("ember-craft-repository/pods/components/projects-search/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 9,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/projects-search/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/projects-search/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui fluid left icon input");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("i");
        dom.setAttribute(el2, "class", "search icon");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("input");
        dom.setAttribute(el2, "type", "text");
        dom.setAttribute(el2, "placeholder", "Search through your projects...");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "results");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/components/tags-widget/component', ['exports', 'ember-osf/components/tags-widget/component', 'ember-craft-repository/pods/components/tags-widget/template'], function (exports, _emberOsfComponentsTagsWidgetComponent, _emberCraftRepositoryPodsComponentsTagsWidgetTemplate) {
    exports['default'] = _emberOsfComponentsTagsWidgetComponent['default'].extend({
        layout: _emberCraftRepositoryPodsComponentsTagsWidgetTemplate['default'],
        classNames: ['tags', 'widget']
    });
});
// app/pods/components/tags-widget/component.js
define("ember-craft-repository/pods/components/tags-widget/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 2,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/components/tags-widget/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/components/tags-widget/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/cookielogin/controller', ['exports', 'ember', 'ember-osf/mixins/osf-cookie-login-controller'], function (exports, _ember, _emberOsfMixinsOsfCookieLoginController) {
  exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsOsfCookieLoginController['default'], {});
});
// app/pods/cookielogin/controller.js
define('ember-craft-repository/pods/cookielogin/route', ['exports', 'ember', 'ember-osf/mixins/osf-cookie-login-route'], function (exports, _ember, _emberOsfMixinsOsfCookieLoginRoute) {
  exports['default'] = _ember['default'].Route.extend(_emberOsfMixinsOsfCookieLoginRoute['default'], {});
});
define("ember-craft-repository/pods/cookielogin/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 3,
              "column": 0
            },
            "end": {
              "line": 3,
              "column": 39
            }
          },
          "moduleName": "ember-craft-repository/pods/cookielogin/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("To Projects Page");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 4,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/cookielogin/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/cookielogin/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("a");
        dom.setAttribute(el1, "class", "ui green button");
        var el2 = dom.createTextNode("Login");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var morphs = new Array(2);
        morphs[0] = dom.createAttrMorph(element0, 'href');
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        return morphs;
      },
      statements: [["attribute", "href", ["get", "authUrl", ["loc", [null, [2, 34], [2, 41]]]]], ["block", "link-to", ["projects"], [], 0, null, ["loc", [null, [3, 0], [3, 51]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/index/controller', ['exports', 'ember', 'ember-osf/mixins/osf-token-login-controller', 'ember-osf/mixins/paginated-controller'], function (exports, _ember, _emberOsfMixinsOsfTokenLoginController, _emberOsfMixinsPaginatedController) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsOsfTokenLoginController['default'], _emberOsfMixinsPaginatedController['default'], {
        _url: null,
        // TODO: Comeback to the dropzone later
        dropzoneOptions: {
            method: 'PUT'
        },
        actions: {
            buildUrl: function buildUrl() {
                return this.get('_url');
            },
            preUpload: function preUpload(comp, drop, file) {
                var _this = this;

                this.set('openModal', true);
                this.set('latestFileName', file.name);
                var promise = new _ember['default'].RSVP.Promise(function (resolve) {
                    _this.set('resolve', resolve);
                });
                return promise;
            }
        }
    });
});
// app/pods/index/controller.js
define('ember-craft-repository/pods/index/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        session: _ember['default'].inject.service(),
        store: _ember['default'].inject.service(),
        setupController: function setupController(controller) {
            this._super(controller);
            var user = this.modelFor('application');

            if (user) {
                controller.set('currentUser', user);
            } else {
                this.get('store').findRecord('user', 'me').then(function (user) {
                    controller.set('currentUser', user);
                });
            }
        },
        actions: {
            reloadProjectListRoute: function reloadProjectListRoute() {
                window.location.reload(true);
            }
        }
    });
});
// app/pods/index/route.js
define("ember-craft-repository/pods/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 51,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui stackable grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "two wide column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "twelve wide column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui stackable grid");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "row");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "eight wide column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("h2");
        dom.setAttribute(el6, "class", "ui header");
        var el7 = dom.createTextNode("DASHBOARD");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "eight wide right aligned column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("div");
        dom.setAttribute(el6, "class", "right aligned column ");
        var el7 = dom.createTextNode("\n                        ");
        dom.appendChild(el6, el7);
        var el7 = dom.createComment("");
        dom.appendChild(el6, el7);
        var el7 = dom.createTextNode("\n                    ");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "row");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "sixteen wide column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui header");
        var el4 = dom.createTextNode("Private Projects");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "two wide column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui horizontal divider");
        var el2 = dom.createTextNode("\n    OR\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui inverted grey segment");
        dom.setAttribute(el1, "style", "background-color: #666666");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui stackable grid");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "two wide column");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "twelve wide column");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "ui header");
        dom.setAttribute(el4, "style", "color: #ffffff");
        var el5 = dom.createTextNode("Public Projects");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "two wide column");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2, 3]);
        var element1 = dom.childAt(element0, [1]);
        var morphs = new Array(4);
        morphs[0] = dom.createMorphAt(dom.childAt(element1, [1, 3, 1]), 1, 1);
        morphs[1] = dom.createMorphAt(dom.childAt(element1, [3, 1]), 1, 1);
        morphs[2] = dom.createMorphAt(element0, 5, 5);
        morphs[3] = dom.createMorphAt(dom.childAt(fragment, [6, 1, 3]), 3, 3);
        return morphs;
      },
      statements: [["inline", "project-create", [], ["reloadRoute", "reloadProjectListRoute"], ["loc", [null, [12, 24], [12, 79]]]], ["content", "projects-search", ["loc", [null, [18, 20], [18, 39]]]], ["inline", "projects-cards", [], ["pageSize", 3, "isPublic", false], ["loc", [null, [23, 8], [23, 52]]]], ["inline", "projects-public-cards", [], ["pageSize", 4, "isPublic", true], ["loc", [null, [37, 12], [37, 62]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/pods/institutions/detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 14,
              "column": 16
            },
            "end": {
              "line": 21,
              "column": 16
            }
          },
          "moduleName": "ember-craft-repository/pods/institutions/detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n                    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(2);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [16, 24], [16, 41]]]], ["content", "project.description", ["loc", [null, [19, 24], [19, 47]]]]],
        locals: ["project"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 26,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/institutions/detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/institutions/detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "panel");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Description: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Logo URL: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Auth URL: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("hr");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Projects");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("p");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("table");
        dom.setAttribute(el4, "class", "table");
        var el5 = dom.createTextNode("\n");
        dom.appendChild(el4, el5);
        var el5 = dom.createComment("");
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [6]);
        var morphs = new Array(7);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
        morphs[3] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
        morphs[4] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
        morphs[5] = dom.createMorphAt(dom.childAt(element0, [7]), 1, 1);
        morphs[6] = dom.createMorphAt(dom.childAt(element0, [11, 3, 1]), 1, 1);
        return morphs;
      },
      statements: [["inline", "page-title", ["Institution"], [], ["loc", [null, [2, 0], [2, 23]]]], ["inline", "link-to", ["Back to list", "institutions"], ["class", "btn btn-default"], ["loc", [null, [3, 0], [3, 65]]]], ["content", "model.name", ["loc", [null, [5, 28], [5, 42]]]], ["content", "model.description", ["loc", [null, [6, 35], [6, 56]]]], ["content", "model.logoPath", ["loc", [null, [7, 32], [7, 50]]]], ["content", "model.authUrl", ["loc", [null, [8, 32], [8, 49]]]], ["block", "each", [["get", "model.nodes", ["loc", [null, [14, 24], [14, 35]]]]], [], 0, null, ["loc", [null, [14, 16], [21, 25]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define("ember-craft-repository/pods/institutions/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 4,
              "column": 0
            },
            "end": {
              "line": 19,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/institutions/index/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("hr");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "panel");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Name: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Description: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Logo URL: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Auth URL: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          dom.setAttribute(el2, "class", "btn-group");
          var el3 = dom.createTextNode("\n");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [3]);
          var morphs = new Array(5);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
          morphs[3] = dom.createMorphAt(dom.childAt(element0, [7]), 1, 1);
          morphs[4] = dom.createMorphAt(dom.childAt(element0, [9]), 2, 2);
          return morphs;
        },
        statements: [["content", "inst.name", ["loc", [null, [7, 32], [7, 45]]]], ["content", "inst.description", ["loc", [null, [8, 39], [8, 59]]]], ["content", "inst.logoPath", ["loc", [null, [9, 36], [9, 53]]]], ["content", "inst.authUrl", ["loc", [null, [10, 36], [10, 52]]]], ["inline", "link-to", ["Detail", "institutions.detail", ["get", "inst.id", ["loc", [null, [16, 53], [16, 60]]]]], ["class", "btn btn-primary"], ["loc", [null, [16, 12], [16, 86]]]]],
        locals: ["inst"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 20,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/institutions/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/institutions/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h4");
        var el2 = dom.createTextNode("All Institutions");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 6, 6, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "page-title", ["Institutions"], [], ["loc", [null, [2, 0], [2, 24]]]], ["block", "each", [["get", "model", ["loc", [null, [4, 8], [4, 13]]]]], [], 0, null, ["loc", [null, [4, 0], [19, 9]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define("ember-craft-repository/pods/institutions/loading/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/institutions/loading/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/loading/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active centered large text inline loader");
        var el2 = dom.createTextNode("Loading");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/institutions/route', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model() {
            return this.store.findAll('institution');
        }
    });
});
// app/pods/institutions/route.js
define("ember-craft-repository/pods/institutions/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/institutions/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/institutions/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        return morphs;
      },
      statements: [["content", "focusing-outlet", ["loc", [null, [2, 0], [2, 19]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/pods/loading/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/loading/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/loading/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active centered large text inline loader");
        var el2 = dom.createTextNode("Loading");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/login/controller', ['exports', 'ember-craft-repository/config/environment', 'ember', 'ember-osf/mixins/osf-token-login-controller'], function (exports, _emberCraftRepositoryConfigEnvironment, _ember, _emberOsfMixinsOsfTokenLoginController) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsOsfTokenLoginController['default'], {
        session: _ember['default'].inject.service(),
        init: function init() {
            if (this.get('session.isAuthenticated')) {
                this.loginSuccess();
            }
        },
        loginSuccess: function loginSuccess() {
            this.transitionToRoute('index');
        },
        loginChoices: [{
            name: 'Login',
            image: 'login.jpg',
            description: 'Please Login into your account.',
            active: "active"
        }, {
            name: 'Register',
            image: 'register.png',
            description: 'Register as a user for Craft',
            active: ""
        }],
        actions: {
            gotoAction: function gotoAction(name) {
                if (name === "Login") {
                    this.send('login');
                } else {
                    if (_emberCraftRepositoryConfigEnvironment['default'].environment === 'development') {
                        window.open('https://staging.osf.io/register/');
                    }
                }
            }
        }
    });
});
// app/pods/login/controller.js
define('ember-craft-repository/pods/login/route', ['exports', 'ember', 'ember-osf/mixins/osf-token-login-route'], function (exports, _ember, _emberOsfMixinsOsfTokenLoginRoute) {
  exports['default'] = _ember['default'].Route.extend(_emberOsfMixinsOsfTokenLoginRoute['default']);
});
// app/pods/login/route.js
define("ember-craft-repository/pods/login/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 11,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/login/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/login/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui large centered grey header");
        var el2 = dom.createTextNode("Select Login or Register");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui three column centered grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column centered row");
        var el3 = dom.createTextNode("\n            ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [4, 3]), 1, 1);
        return morphs;
      },
      statements: [["inline", "login-register-selector", [], ["action", "gotoAction", "data", ["subexpr", "@mut", [["get", "loginChoices", ["loc", [null, [7, 63], [7, 75]]]]], [], []]], ["loc", [null, [7, 12], [7, 77]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/prereg/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        fileManager: _ember['default'].inject.service(),
        actions: {
            preregister: function preregister(name, files) {
                var fileNames = files.mapBy('name').join(', ');

                // TODO:20 This page is just a file-chooser demo at this point
                window.alert('Files: ' + fileNames);

                // store.createRecord('node', { title: name, ... })
                // for (let file of files) {
                //     this.get('fileManager').uploadFile(...)
                // }
            }
        }
    });
});
// app/pods/prereg/route.js
define("ember-craft-repository/pods/prereg/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 19,
                  "column": 20
                },
                "end": {
                  "line": 21,
                  "column": 20
                }
              },
              "moduleName": "ember-craft-repository/pods/prereg/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                        ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("li");
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(1);
              morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 0, 0);
              return morphs;
            },
            statements: [["content", "file.name", ["loc", [null, [20, 28], [20, 41]]]]],
            locals: ["file"],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 16,
                "column": 12
              },
              "end": {
                "line": 23,
                "column": 12
              }
            },
            "moduleName": "ember-craft-repository/pods/prereg/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("h4");
            var el2 = dom.createTextNode("Selected files");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("ul");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("                ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
            return morphs;
          },
          statements: [["block", "each", [["get", "files", ["loc", [null, [19, 28], [19, 33]]]]], [], 0, null, ["loc", [null, [19, 20], [21, 29]]]]],
          locals: [],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 7,
              "column": 8
            },
            "end": {
              "line": 24,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/prereg/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n                Drag your preregistration files here!\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n                Or choose them, if you're not into HTML5:\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(2);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
          morphs[1] = dom.createMorphAt(fragment, 5, 5, contextualElement);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["inline", "input", [], ["type", "file", "change", ["subexpr", "action", ["onFileInputChange"], ["target", ["get", "component", ["loc", [null, [14, 62], [14, 71]]]]], ["loc", [null, [14, 27], [14, 72]]]]], ["loc", [null, [13, 16], [14, 74]]]], ["block", "if", [["get", "files", ["loc", [null, [16, 18], [16, 23]]]]], [], 0, null, ["loc", [null, [16, 12], [23, 19]]]]],
        locals: ["component"],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 32,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/prereg/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/prereg/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Name: ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("button");
        var el4 = dom.createTextNode("\n            Submit preregistration\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var element1 = dom.childAt(element0, [5, 1]);
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 1]), 1, 1);
        morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
        morphs[2] = dom.createElementMorph(element1);
        return morphs;
      },
      statements: [["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "name", ["loc", [null, [4, 35], [4, 39]]]]], [], []]], ["loc", [null, [4, 21], [4, 41]]]], ["block", "file-chooser", [], ["files", ["subexpr", "@mut", [["get", "files", ["loc", [null, [7, 30], [7, 35]]]]], [], []]], 0, null, ["loc", [null, [7, 8], [24, 25]]]], ["element", "action", ["preregister", ["get", "name", ["loc", [null, [27, 39], [27, 43]]]], ["get", "files", ["loc", [null, [27, 44], [27, 49]]]]], [], ["loc", [null, [27, 16], [27, 51]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/profile/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        model: function model() {
            return this.get('store').findRecord('user', 'me');
        },
        setupController: function setupController(controller, model) {
            controller.set('editedFullName', model.get('fullName'));
            this._super.apply(this, arguments);
        },
        actions: {
            /**
            * Edit user name
            *
            * @method editExisting
            * @param {String} value User fullName
            * @return {Promise} Returns a promise that resolves to the updated user
            */
            editExisting: function editExisting(value) {
                // TODO:0 Should test PUT or PATCH
                var user = this.modelFor(this.routeName);
                user.set('fullName', value);
                user.save();
            }
        }
    });
});
// app/pods/profile/route.js
define("ember-craft-repository/pods/profile/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 18,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/profile/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/profile/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h2");
        var el2 = dom.createTextNode("Profile Information");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "panel");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Full Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Given Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Middle Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Family Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h2");
        var el3 = dom.createTextNode("Edit Your Profile");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Full Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("button");
        dom.setAttribute(el2, "class", "ui green button");
        var el3 = dom.createTextNode("Edit Record");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [6]);
        var element1 = dom.childAt(element0, [14]);
        var morphs = new Array(7);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
        morphs[2] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
        morphs[3] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
        morphs[4] = dom.createMorphAt(dom.childAt(element0, [7]), 1, 1);
        morphs[5] = dom.createMorphAt(dom.childAt(element0, [12]), 1, 1);
        morphs[6] = dom.createElementMorph(element1);
        return morphs;
      },
      statements: [["inline", "page-title", [["get", "model.fullName", ["loc", [null, [2, 8], [2, 22]]]]], [], ["loc", [null, [2, 0], [2, 24]]]], ["content", "model.fullName", ["loc", [null, [5, 33], [5, 51]]]], ["content", "model.givenName", ["loc", [null, [6, 34], [6, 53]]]], ["content", "model.middleName", ["loc", [null, [7, 35], [7, 55]]]], ["content", "model.familyName", ["loc", [null, [8, 35], [8, 55]]]], ["inline", "input", [], ["value", ["subexpr", "@mut", [["get", "editedFullName", ["loc", [null, [15, 47], [15, 61]]]]], [], []]], ["loc", [null, [15, 33], [15, 63]]]], ["element", "action", ["editExisting", ["get", "editedFullName", ["loc", [null, [16, 36], [16, 50]]]]], [], ["loc", [null, [16, 12], [16, 52]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/children/route', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model() {
            var project = this.modelFor('projects.detail');
            return project.get('children');
        }
    });
});
// app/pods/projects/detail/children/route.js
define("ember-craft-repository/pods/projects/detail/children/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 5,
              "column": 4
            },
            "end": {
              "line": 7,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/children/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("li");
          var el2 = dom.createElement("a");
          var el3 = dom.createTextNode(" ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode(" ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode(" ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1, 0]);
          var morphs = new Array(2);
          morphs[0] = dom.createAttrMorph(element0, 'href');
          morphs[1] = dom.createMorphAt(element0, 1, 1);
          return morphs;
        },
        statements: [["attribute", "href", ["concat", [["get", "child.links.html", ["loc", [null, [6, 23], [6, 39]]]]]]], ["content", "child.title", ["loc", [null, [6, 44], [6, 59]]]]],
        locals: ["child"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 9,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/children/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/children/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("hr");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h2");
        var el2 = dom.createTextNode("Components");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("ul");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [6]), 1, 1);
        return morphs;
      },
      statements: [["block", "each", [["get", "model", ["loc", [null, [5, 12], [5, 17]]]]], [], 0, null, ["loc", [null, [5, 4], [7, 13]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/draft-registrations/detail/controller', ['exports', 'ember', 'ember-osf/mixins/registration-actions'], function (exports, _ember, _emberOsfMixinsRegistrationActions) {
    function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsRegistrationActions['default'], {
        editedMetadata: {},
        embargoSelected: false,
        registrationChoice: 'immediate',
        liftEmbargo: '',
        actions: {
            /**
            * Toggle whether registration form is displayed.
            *
            * @method regForm
            */
            regForm: function regForm() {
                this.toggleProperty('formDisplayed');
            },
            /**
            * Build new registration metadata in format that server is expecting.  Different
            * schemas will have different levels of nesting.  Each time a question is
            * answered on a draft registration, the response will be added to the editedMetadata object.
            *
            * @method buildForm
            * @param {Object} target Response to draft question
            */
            buildForm: function buildForm(target) {
                var response = '';
                var question = target.name;
                if (question.indexOf(':') !== -1) {
                    var pieces = question.split(':');
                    question = pieces[0];
                    var subquestion = pieces[1];
                    var subsubquestion = '';
                    if (pieces.length === 3) {
                        subsubquestion = pieces[2];
                        response = { value: _defineProperty({}, subsubquestion, { value: target.value }) };
                    } else {
                        response = { value: target.value };
                    }
                    if (this.editedMetadata[question]) {
                        if (this.editedMetadata[question].value[subquestion]) {
                            if (pieces.length === 3) {
                                this.editedMetadata[question].value[subquestion].value[subsubquestion] = { value: target.value };
                            }
                        } else {
                            this.editedMetadata[question].value[subquestion] = response;
                        }
                    } else {
                        this.editedMetadata[question] = { value: _defineProperty({}, subquestion, response) };
                    }
                } else {
                    this.editedMetadata[question] = {
                        value: target.value
                    };
                }
            },
            /**
            * Update registrationChoice (either "immediate" or "embargo") and toggles whether
            * embargo end date is displayed in the UI
            *
            * @method changeRegistrationChoice
            * @param {String} newChoice New registration choice (either "immediate"/"embargo")
            */
            changeRegistrationChoice: function changeRegistrationChoice(newChoice) {
                this.toggleProperty('embargoSelected');
                this.set('registrationChoice', newChoice);
            },
            /**
            * Update embargoEndDate.  Takes calendar date and appends time info onto the end,
            * in the format that the APIv2 is expecting
            *
            * @method changeEmbargoEndDate
            * @param {Date} newDate Date to lift the embargo
            */
            changeEmbargoEndDate: function changeEmbargoEndDate(newDate) {
                this.set('liftEmbargo', newDate + 'T12:00:00');
            }
        }
    });
});
// app/pods/projects/detail/draft-registrations/detail/controller.js
define('ember-craft-repository/pods/projects/detail/draft-registrations/detail/route', ['exports', 'ember', 'ember-get-config'], function (exports, _ember, _emberGetConfig) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model(params) {
            var project = this.modelFor('projects.detail');
            this.store.adapterFor('draft-registration').set('namespace', _emberGetConfig['default'].OSF.apiNamespace + '/projects/' + project.id);
            var draft = this.store.findRecord('draft-registration', params.draft_registration_id);
            return draft;
        },
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            controller.set('project', this.modelFor('projects.detail'));
        }
    });
});
// app/pods/projects/detail/draft-registrations/detail/route.js
define("ember-craft-repository/pods/projects/detail/draft-registrations/detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 21,
                  "column": 8
                },
                "end": {
                  "line": 23,
                  "column": 8
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("            ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("p");
              var el2 = dom.createTextNode(" ");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode(" ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(1);
              morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
              return morphs;
            },
            statements: [["content", "question.description", ["loc", [null, [22, 16], [22, 40]]]]],
            locals: [],
            templates: []
          };
        })();
        var child1 = (function () {
          var child0 = (function () {
            return {
              meta: {
                "fragmentReason": false,
                "revision": "Ember@2.4.6",
                "loc": {
                  "source": null,
                  "start": {
                    "line": 25,
                    "column": 12
                  },
                  "end": {
                    "line": 27,
                    "column": 12
                  }
                },
                "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
              },
              isEmpty: false,
              arity: 0,
              cachedFragment: null,
              hasRendered: false,
              buildFragment: function buildFragment(dom) {
                var el0 = dom.createDocumentFragment();
                var el1 = dom.createTextNode("                ");
                dom.appendChild(el0, el1);
                var el1 = dom.createElement("p");
                var el2 = dom.createTextNode(" ");
                dom.appendChild(el1, el2);
                var el2 = dom.createElement("em");
                var el3 = dom.createTextNode(" Please choose ");
                dom.appendChild(el2, el3);
                dom.appendChild(el1, el2);
                var el2 = dom.createTextNode(" ");
                dom.appendChild(el1, el2);
                dom.appendChild(el0, el1);
                var el1 = dom.createTextNode("\n");
                dom.appendChild(el0, el1);
                return el0;
              },
              buildRenderNodes: function buildRenderNodes() {
                return [];
              },
              statements: [],
              locals: [],
              templates: []
            };
          })();
          var child1 = (function () {
            var child0 = (function () {
              return {
                meta: {
                  "fragmentReason": false,
                  "revision": "Ember@2.4.6",
                  "loc": {
                    "source": null,
                    "start": {
                      "line": 30,
                      "column": 20
                    },
                    "end": {
                      "line": 32,
                      "column": 20
                    }
                  },
                  "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                },
                isEmpty: false,
                arity: 0,
                cachedFragment: null,
                hasRendered: false,
                buildFragment: function buildFragment(dom) {
                  var el0 = dom.createDocumentFragment();
                  var el1 = dom.createTextNode("                        ");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createElement("p");
                  var el2 = dom.createTextNode(" ");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createElement("input");
                  dom.setAttribute(el2, "type", "radio");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createTextNode(" ");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createComment("");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createTextNode(" ");
                  dom.appendChild(el1, el2);
                  dom.appendChild(el0, el1);
                  var el1 = dom.createTextNode("\n");
                  dom.appendChild(el0, el1);
                  return el0;
                },
                buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                  var element13 = dom.childAt(fragment, [1]);
                  var element14 = dom.childAt(element13, [1]);
                  if (this.cachedFragment) {
                    dom.repairClonedNode(element14, [], true);
                  }
                  var morphs = new Array(5);
                  morphs[0] = dom.createAttrMorph(element14, 'onchange');
                  morphs[1] = dom.createAttrMorph(element14, 'name');
                  morphs[2] = dom.createAttrMorph(element14, 'value');
                  morphs[3] = dom.createAttrMorph(element14, 'checked');
                  morphs[4] = dom.createMorphAt(element13, 3, 3);
                  return morphs;
                },
                statements: [["attribute", "onchange", ["subexpr", "action", ["buildForm"], ["value", "target"], ["loc", [null, [31, 44], [31, 81]]]]], ["attribute", "name", ["get", "question.qid", ["loc", [null, [31, 102], [31, 114]]]]], ["attribute", "value", ["get", "option", ["loc", [null, [31, 125], [31, 131]]]]], ["attribute", "checked", ["subexpr", "selected-helper", [["get", "option", ["loc", [null, [31, 160], [31, 166]]]], ["subexpr", "draft-text-input", [["get", "model.registrationMetadata", ["loc", [null, [31, 185], [31, 211]]]], ["get", "question", ["loc", [null, [31, 212], [31, 220]]]]], [], ["loc", [null, [31, 167], [31, 221]]]]], [], ["loc", [null, [31, 142], [31, 223]]]]], ["content", "option", ["loc", [null, [31, 225], [31, 235]]]]],
                locals: [],
                templates: []
              };
            })();
            var child1 = (function () {
              return {
                meta: {
                  "fragmentReason": false,
                  "revision": "Ember@2.4.6",
                  "loc": {
                    "source": null,
                    "start": {
                      "line": 32,
                      "column": 20
                    },
                    "end": {
                      "line": 34,
                      "column": 20
                    }
                  },
                  "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                },
                isEmpty: false,
                arity: 0,
                cachedFragment: null,
                hasRendered: false,
                buildFragment: function buildFragment(dom) {
                  var el0 = dom.createDocumentFragment();
                  var el1 = dom.createTextNode("                        ");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createElement("p");
                  var el2 = dom.createTextNode(" ");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createElement("input");
                  dom.setAttribute(el2, "type", "radio");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createTextNode(" ");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createComment("");
                  dom.appendChild(el1, el2);
                  var el2 = dom.createTextNode(" ");
                  dom.appendChild(el1, el2);
                  dom.appendChild(el0, el1);
                  var el1 = dom.createTextNode("\n");
                  dom.appendChild(el0, el1);
                  return el0;
                },
                buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                  var element11 = dom.childAt(fragment, [1]);
                  var element12 = dom.childAt(element11, [1]);
                  if (this.cachedFragment) {
                    dom.repairClonedNode(element12, [], true);
                  }
                  var morphs = new Array(5);
                  morphs[0] = dom.createAttrMorph(element12, 'onchange');
                  morphs[1] = dom.createAttrMorph(element12, 'name');
                  morphs[2] = dom.createAttrMorph(element12, 'value');
                  morphs[3] = dom.createAttrMorph(element12, 'checked');
                  morphs[4] = dom.createMorphAt(element11, 3, 3);
                  return morphs;
                },
                statements: [["attribute", "onchange", ["subexpr", "action", ["buildForm"], ["value", "target"], ["loc", [null, [33, 44], [33, 81]]]]], ["attribute", "name", ["get", "question.qid", ["loc", [null, [33, 102], [33, 114]]]]], ["attribute", "value", ["get", "option.text", ["loc", [null, [33, 125], [33, 136]]]]], ["attribute", "checked", ["subexpr", "selected-helper", [["get", "option.text", ["loc", [null, [33, 165], [33, 176]]]], ["subexpr", "draft-text-input", [["get", "model.registrationMetadata", ["loc", [null, [33, 195], [33, 221]]]], ["get", "question", ["loc", [null, [33, 222], [33, 230]]]]], [], ["loc", [null, [33, 177], [33, 231]]]]], [], ["loc", [null, [33, 147], [33, 233]]]]], ["content", "option.text", ["loc", [null, [33, 235], [33, 250]]]]],
                locals: [],
                templates: []
              };
            })();
            return {
              meta: {
                "fragmentReason": false,
                "revision": "Ember@2.4.6",
                "loc": {
                  "source": null,
                  "start": {
                    "line": 29,
                    "column": 16
                  },
                  "end": {
                    "line": 35,
                    "column": 16
                  }
                },
                "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
              },
              isEmpty: false,
              arity: 1,
              cachedFragment: null,
              hasRendered: false,
              buildFragment: function buildFragment(dom) {
                var el0 = dom.createDocumentFragment();
                var el1 = dom.createComment("");
                dom.appendChild(el0, el1);
                return el0;
              },
              buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                var morphs = new Array(1);
                morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                dom.insertBoundary(fragment, 0);
                dom.insertBoundary(fragment, null);
                return morphs;
              },
              statements: [["block", "if", [["subexpr", "eq", [["subexpr", "check-data-type", [["get", "option", ["loc", [null, [30, 47], [30, 53]]]]], [], ["loc", [null, [30, 30], [30, 54]]]], "string"], [], ["loc", [null, [30, 26], [30, 64]]]]], [], 0, 1, ["loc", [null, [30, 20], [34, 27]]]]],
              locals: ["option"],
              templates: [child0, child1]
            };
          })();
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 24,
                  "column": 8
                },
                "end": {
                  "line": 37,
                  "column": 8
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createComment("");
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("            ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("form");
              var el2 = dom.createTextNode("\n");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("            ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(2);
              morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
              morphs[1] = dom.createMorphAt(dom.childAt(fragment, [2]), 1, 1);
              dom.insertBoundary(fragment, 0);
              return morphs;
            },
            statements: [["block", "unless", [["get", "question.description", ["loc", [null, [25, 22], [25, 42]]]]], [], 0, null, ["loc", [null, [25, 12], [27, 23]]]], ["block", "each", [["get", "question.options", ["loc", [null, [29, 24], [29, 40]]]]], [], 1, null, ["loc", [null, [29, 16], [35, 25]]]]],
            locals: [],
            templates: [child0, child1]
          };
        })();
        var child2 = (function () {
          var child0 = (function () {
            var child0 = (function () {
              var child0 = (function () {
                return {
                  meta: {
                    "fragmentReason": false,
                    "revision": "Ember@2.4.6",
                    "loc": {
                      "source": null,
                      "start": {
                        "line": 39,
                        "column": 16
                      },
                      "end": {
                        "line": 41,
                        "column": 16
                      }
                    },
                    "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                  },
                  isEmpty: false,
                  arity: 0,
                  cachedFragment: null,
                  hasRendered: false,
                  buildFragment: function buildFragment(dom) {
                    var el0 = dom.createDocumentFragment();
                    var el1 = dom.createTextNode("                    ");
                    dom.appendChild(el0, el1);
                    var el1 = dom.createElement("p");
                    var el2 = dom.createComment("");
                    dom.appendChild(el1, el2);
                    dom.appendChild(el0, el1);
                    var el1 = dom.createTextNode("\n");
                    dom.appendChild(el0, el1);
                    return el0;
                  },
                  buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                    var morphs = new Array(1);
                    morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 0, 0);
                    return morphs;
                  },
                  statements: [["content", "subquestion.description", ["loc", [null, [40, 23], [40, 50]]]]],
                  locals: [],
                  templates: []
                };
              })();
              var child1 = (function () {
                return {
                  meta: {
                    "fragmentReason": false,
                    "revision": "Ember@2.4.6",
                    "loc": {
                      "source": null,
                      "start": {
                        "line": 42,
                        "column": 16
                      },
                      "end": {
                        "line": 49,
                        "column": 16
                      }
                    },
                    "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                  },
                  isEmpty: false,
                  arity: 0,
                  cachedFragment: null,
                  hasRendered: false,
                  buildFragment: function buildFragment(dom) {
                    var el0 = dom.createDocumentFragment();
                    var el1 = dom.createTextNode("                    ");
                    dom.appendChild(el0, el1);
                    var el1 = dom.createElement("p");
                    var el2 = dom.createTextNode("\n                        You may attach up to 5 files to this question.\n                        You may attach files that you already have in this OSF project, or upload a new file from your computer.\n                        Uploaded files will automatically be added to this project so that they can be registered.\n                    ");
                    dom.appendChild(el1, el2);
                    dom.appendChild(el0, el1);
                    var el1 = dom.createTextNode("\n                    ");
                    dom.appendChild(el0, el1);
                    var el1 = dom.createElement("a");
                    dom.setAttribute(el1, "href", "#");
                    var el2 = dom.createTextNode(" Attach File (not implemented) ");
                    dom.appendChild(el1, el2);
                    dom.appendChild(el0, el1);
                    var el1 = dom.createTextNode("\n");
                    dom.appendChild(el0, el1);
                    return el0;
                  },
                  buildRenderNodes: function buildRenderNodes() {
                    return [];
                  },
                  statements: [],
                  locals: [],
                  templates: []
                };
              })();
              var child2 = (function () {
                var child0 = (function () {
                  var child0 = (function () {
                    var child0 = (function () {
                      return {
                        meta: {
                          "fragmentReason": false,
                          "revision": "Ember@2.4.6",
                          "loc": {
                            "source": null,
                            "start": {
                              "line": 52,
                              "column": 28
                            },
                            "end": {
                              "line": 54,
                              "column": 28
                            }
                          },
                          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                        },
                        isEmpty: false,
                        arity: 0,
                        cachedFragment: null,
                        hasRendered: false,
                        buildFragment: function buildFragment(dom) {
                          var el0 = dom.createDocumentFragment();
                          var el1 = dom.createTextNode("                                ");
                          dom.appendChild(el0, el1);
                          var el1 = dom.createElement("p");
                          var el2 = dom.createComment("");
                          dom.appendChild(el1, el2);
                          dom.appendChild(el0, el1);
                          var el1 = dom.createTextNode("\n");
                          dom.appendChild(el0, el1);
                          return el0;
                        },
                        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                          var morphs = new Array(1);
                          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 0, 0);
                          return morphs;
                        },
                        statements: [["content", "item.description", ["loc", [null, [53, 35], [53, 55]]]]],
                        locals: [],
                        templates: []
                      };
                    })();
                    return {
                      meta: {
                        "fragmentReason": false,
                        "revision": "Ember@2.4.6",
                        "loc": {
                          "source": null,
                          "start": {
                            "line": 51,
                            "column": 24
                          },
                          "end": {
                            "line": 56,
                            "column": 24
                          }
                        },
                        "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                      },
                      isEmpty: false,
                      arity: 1,
                      cachedFragment: null,
                      hasRendered: false,
                      buildFragment: function buildFragment(dom) {
                        var el0 = dom.createDocumentFragment();
                        var el1 = dom.createComment("");
                        dom.appendChild(el0, el1);
                        var el1 = dom.createTextNode("                            ");
                        dom.appendChild(el0, el1);
                        var el1 = dom.createElement("p");
                        var el2 = dom.createElement("textarea");
                        dom.appendChild(el1, el2);
                        dom.appendChild(el0, el1);
                        var el1 = dom.createTextNode("\n");
                        dom.appendChild(el0, el1);
                        return el0;
                      },
                      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                        var element10 = dom.childAt(fragment, [2, 0]);
                        var morphs = new Array(4);
                        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                        morphs[1] = dom.createAttrMorph(element10, 'onchange');
                        morphs[2] = dom.createAttrMorph(element10, 'name');
                        morphs[3] = dom.createAttrMorph(element10, 'value');
                        dom.insertBoundary(fragment, 0);
                        return morphs;
                      },
                      statements: [["block", "if", [["get", "item.description", ["loc", [null, [52, 34], [52, 50]]]]], [], 0, null, ["loc", [null, [52, 28], [54, 35]]]], ["attribute", "onchange", ["subexpr", "action", ["buildForm"], ["value", "target"], ["loc", [null, [55, 50], [55, 87]]]]], ["attribute", "name", ["concat", [["get", "question.qid", ["loc", [null, [55, 96], [55, 108]]]], ":", ["get", "subquestion.id", ["loc", [null, [55, 113], [55, 127]]]], ":", ["get", "item.id", ["loc", [null, [55, 132], [55, 139]]]]]]], ["attribute", "value", ["subexpr", "draft-text-input", [["get", "model.registrationMetadata", ["loc", [null, [55, 168], [55, 194]]]], ["get", "question", ["loc", [null, [55, 195], [55, 203]]]], ["get", "subquestion", ["loc", [null, [55, 204], [55, 215]]]], ["get", "item", ["loc", [null, [55, 216], [55, 220]]]]], [], ["loc", [null, [55, 149], [55, 222]]]]]],
                      locals: ["item"],
                      templates: [child0]
                    };
                  })();
                  return {
                    meta: {
                      "fragmentReason": false,
                      "revision": "Ember@2.4.6",
                      "loc": {
                        "source": null,
                        "start": {
                          "line": 50,
                          "column": 20
                        },
                        "end": {
                          "line": 57,
                          "column": 20
                        }
                      },
                      "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                    },
                    isEmpty: false,
                    arity: 0,
                    cachedFragment: null,
                    hasRendered: false,
                    buildFragment: function buildFragment(dom) {
                      var el0 = dom.createDocumentFragment();
                      var el1 = dom.createComment("");
                      dom.appendChild(el0, el1);
                      return el0;
                    },
                    buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                      var morphs = new Array(1);
                      morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                      dom.insertBoundary(fragment, 0);
                      dom.insertBoundary(fragment, null);
                      return morphs;
                    },
                    statements: [["block", "each", [["get", "subquestion.properties", ["loc", [null, [51, 32], [51, 54]]]]], [], 0, null, ["loc", [null, [51, 24], [56, 33]]]]],
                    locals: [],
                    templates: [child0]
                  };
                })();
                var child1 = (function () {
                  return {
                    meta: {
                      "fragmentReason": false,
                      "revision": "Ember@2.4.6",
                      "loc": {
                        "source": null,
                        "start": {
                          "line": 57,
                          "column": 20
                        },
                        "end": {
                          "line": 59,
                          "column": 20
                        }
                      },
                      "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                    },
                    isEmpty: false,
                    arity: 0,
                    cachedFragment: null,
                    hasRendered: false,
                    buildFragment: function buildFragment(dom) {
                      var el0 = dom.createDocumentFragment();
                      var el1 = dom.createTextNode("                        ");
                      dom.appendChild(el0, el1);
                      var el1 = dom.createElement("p");
                      var el2 = dom.createElement("textarea");
                      dom.appendChild(el1, el2);
                      dom.appendChild(el0, el1);
                      var el1 = dom.createTextNode("\n");
                      dom.appendChild(el0, el1);
                      return el0;
                    },
                    buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                      var element9 = dom.childAt(fragment, [1, 0]);
                      var morphs = new Array(3);
                      morphs[0] = dom.createAttrMorph(element9, 'onchange');
                      morphs[1] = dom.createAttrMorph(element9, 'name');
                      morphs[2] = dom.createAttrMorph(element9, 'value');
                      return morphs;
                    },
                    statements: [["attribute", "onchange", ["subexpr", "action", ["buildForm"], ["value", "target"], ["loc", [null, [58, 46], [58, 83]]]]], ["attribute", "name", ["concat", [["get", "question.qid", ["loc", [null, [58, 92], [58, 104]]]], ":", ["get", "subquestion.id", ["loc", [null, [58, 109], [58, 123]]]]]]], ["attribute", "value", ["subexpr", "draft-text-input", [["get", "model.registrationMetadata", ["loc", [null, [58, 152], [58, 178]]]], ["get", "question", ["loc", [null, [58, 179], [58, 187]]]], ["get", "subquestion", ["loc", [null, [58, 188], [58, 199]]]]], [], ["loc", [null, [58, 133], [58, 201]]]]]],
                    locals: [],
                    templates: []
                  };
                })();
                return {
                  meta: {
                    "fragmentReason": false,
                    "revision": "Ember@2.4.6",
                    "loc": {
                      "source": null,
                      "start": {
                        "line": 49,
                        "column": 16
                      },
                      "end": {
                        "line": 60,
                        "column": 16
                      }
                    },
                    "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                  },
                  isEmpty: false,
                  arity: 0,
                  cachedFragment: null,
                  hasRendered: false,
                  buildFragment: function buildFragment(dom) {
                    var el0 = dom.createDocumentFragment();
                    var el1 = dom.createComment("");
                    dom.appendChild(el0, el1);
                    return el0;
                  },
                  buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                    var morphs = new Array(1);
                    morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                    dom.insertBoundary(fragment, 0);
                    dom.insertBoundary(fragment, null);
                    return morphs;
                  },
                  statements: [["block", "if", [["get", "subquestion.properties", ["loc", [null, [50, 26], [50, 48]]]]], [], 0, 1, ["loc", [null, [50, 20], [59, 27]]]]],
                  locals: [],
                  templates: [child0, child1]
                };
              })();
              return {
                meta: {
                  "fragmentReason": false,
                  "revision": "Ember@2.4.6",
                  "loc": {
                    "source": null,
                    "start": {
                      "line": 38,
                      "column": 12
                    },
                    "end": {
                      "line": 61,
                      "column": 12
                    }
                  },
                  "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
                },
                isEmpty: false,
                arity: 1,
                cachedFragment: null,
                hasRendered: false,
                buildFragment: function buildFragment(dom) {
                  var el0 = dom.createDocumentFragment();
                  var el1 = dom.createComment("");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createComment("");
                  dom.appendChild(el0, el1);
                  return el0;
                },
                buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                  var morphs = new Array(2);
                  morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                  morphs[1] = dom.createMorphAt(fragment, 1, 1, contextualElement);
                  dom.insertBoundary(fragment, 0);
                  dom.insertBoundary(fragment, null);
                  return morphs;
                },
                statements: [["block", "if", [["get", "subquestion.description", ["loc", [null, [39, 22], [39, 45]]]]], [], 0, null, ["loc", [null, [39, 16], [41, 23]]]], ["block", "if", [["subexpr", "eq", [["get", "subquestion.type", ["loc", [null, [42, 26], [42, 42]]]], "osf-upload"], [], ["loc", [null, [42, 22], [42, 56]]]]], [], 1, 2, ["loc", [null, [42, 16], [60, 23]]]]],
                locals: ["subquestion"],
                templates: [child0, child1, child2]
              };
            })();
            return {
              meta: {
                "fragmentReason": false,
                "revision": "Ember@2.4.6",
                "loc": {
                  "source": null,
                  "start": {
                    "line": 37,
                    "column": 8
                  },
                  "end": {
                    "line": 62,
                    "column": 8
                  }
                },
                "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
              },
              isEmpty: false,
              arity: 0,
              cachedFragment: null,
              hasRendered: false,
              buildFragment: function buildFragment(dom) {
                var el0 = dom.createDocumentFragment();
                var el1 = dom.createComment("");
                dom.appendChild(el0, el1);
                return el0;
              },
              buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                var morphs = new Array(1);
                morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                dom.insertBoundary(fragment, 0);
                dom.insertBoundary(fragment, null);
                return morphs;
              },
              statements: [["block", "each", [["get", "question.properties", ["loc", [null, [38, 20], [38, 39]]]]], [], 0, null, ["loc", [null, [38, 12], [61, 21]]]]],
              locals: [],
              templates: [child0]
            };
          })();
          var child1 = (function () {
            return {
              meta: {
                "fragmentReason": false,
                "revision": "Ember@2.4.6",
                "loc": {
                  "source": null,
                  "start": {
                    "line": 62,
                    "column": 8
                  },
                  "end": {
                    "line": 64,
                    "column": 8
                  }
                },
                "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
              },
              isEmpty: false,
              arity: 0,
              cachedFragment: null,
              hasRendered: false,
              buildFragment: function buildFragment(dom) {
                var el0 = dom.createDocumentFragment();
                var el1 = dom.createTextNode("            ");
                dom.appendChild(el0, el1);
                var el1 = dom.createElement("textarea");
                var el2 = dom.createTextNode(" ");
                dom.appendChild(el1, el2);
                dom.appendChild(el0, el1);
                var el1 = dom.createTextNode("\n        ");
                dom.appendChild(el0, el1);
                return el0;
              },
              buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                var element8 = dom.childAt(fragment, [1]);
                var morphs = new Array(3);
                morphs[0] = dom.createAttrMorph(element8, 'onchange');
                morphs[1] = dom.createAttrMorph(element8, 'name');
                morphs[2] = dom.createAttrMorph(element8, 'value');
                return morphs;
              },
              statements: [["attribute", "onchange", ["subexpr", "action", ["buildForm"], ["value", "target"], ["loc", [null, [63, 31], [63, 68]]]]], ["attribute", "name", ["get", "question.qid", ["loc", [null, [63, 76], [63, 88]]]]], ["attribute", "value", ["subexpr", "draft-text-input", [["get", "model.registrationMetadata", ["loc", [null, [63, 116], [63, 142]]]], ["get", "question", ["loc", [null, [63, 143], [63, 151]]]]], [], ["loc", [null, [63, 97], [63, 153]]]]]],
              locals: [],
              templates: []
            };
          })();
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 37,
                  "column": 8
                },
                "end": {
                  "line": 64,
                  "column": 8
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createComment("");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(1);
              morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
              dom.insertBoundary(fragment, 0);
              dom.insertBoundary(fragment, null);
              return morphs;
            },
            statements: [["block", "if", [["subexpr", "eq", [["get", "question.type", ["loc", [null, [37, 22], [37, 35]]]], "object"], [], ["loc", [null, [37, 18], [37, 45]]]]], [], 0, 1, ["loc", [null, [37, 8], [64, 8]]]]],
            locals: [],
            templates: [child0, child1]
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 19,
                "column": 4
              },
              "end": {
                "line": 66,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("label");
            var el3 = dom.createTextNode(" ");
            dom.appendChild(el2, el3);
            var el3 = dom.createComment("");
            dom.appendChild(el2, el3);
            var el3 = dom.createTextNode(" ");
            dom.appendChild(el2, el3);
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("hr");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(3);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1, 1]), 1, 1);
            morphs[1] = dom.createMorphAt(fragment, 3, 3, contextualElement);
            morphs[2] = dom.createMorphAt(fragment, 4, 4, contextualElement);
            return morphs;
          },
          statements: [["content", "question.title", ["loc", [null, [20, 20], [20, 38]]]], ["block", "if", [["get", "question.description", ["loc", [null, [21, 14], [21, 34]]]]], [], 0, null, ["loc", [null, [21, 8], [23, 15]]]], ["block", "if", [["subexpr", "eq", [["get", "question.type", ["loc", [null, [24, 18], [24, 31]]]], "choose"], [], ["loc", [null, [24, 14], [24, 41]]]]], [], 1, 2, ["loc", [null, [24, 8], [64, 15]]]]],
          locals: ["question"],
          templates: [child0, child1, child2]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 17,
              "column": 0
            },
            "end": {
              "line": 67,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "each", [["get", "page.questions", ["loc", [null, [19, 12], [19, 26]]]]], [], 0, null, ["loc", [null, [19, 4], [66, 13]]]]],
        locals: ["page"],
        templates: [child0]
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 76,
                "column": 4
              },
              "end": {
                "line": 79,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createElement("label");
            var el3 = dom.createTextNode(" Embargo End Date ");
            dom.appendChild(el2, el3);
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("input");
            dom.setAttribute(el1, "name", "liftEmbargo");
            dom.setAttribute(el1, "type", "date");
            dom.setAttribute(el1, "value", "liftEmbargo");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element3 = dom.childAt(fragment, [3]);
            var morphs = new Array(1);
            morphs[0] = dom.createAttrMorph(element3, 'onchange');
            return morphs;
          },
          statements: [["attribute", "onchange", ["subexpr", "action", ["changeEmbargoEndDate"], ["value", "target.value"], ["loc", [null, [78, 75], [78, 129]]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 69,
              "column": 0
            },
            "end": {
              "line": 85,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("h3");
          var el2 = dom.createTextNode(" Before you continue ... ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createElement("label");
          var el3 = dom.createTextNode(" Registration Choice ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("select");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("option");
          dom.setAttribute(el2, "value", "immediate");
          var el3 = dom.createTextNode(" Make registration public immediately ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("option");
          dom.setAttribute(el2, "value", "embargo");
          var el3 = dom.createTextNode(" Enter registration into embargo ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("br");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "btn btn-default");
          var el3 = dom.createTextNode("Cancel");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "btn btn-success");
          var el3 = dom.createTextNode("Continue");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element4 = dom.childAt(fragment, [5]);
          var element5 = dom.childAt(fragment, [12]);
          var element6 = dom.childAt(element5, [1]);
          var element7 = dom.childAt(element5, [3]);
          var morphs = new Array(4);
          morphs[0] = dom.createAttrMorph(element4, 'onchange');
          morphs[1] = dom.createMorphAt(fragment, 7, 7, contextualElement);
          morphs[2] = dom.createElementMorph(element6);
          morphs[3] = dom.createElementMorph(element7);
          return morphs;
        },
        statements: [["attribute", "onchange", ["subexpr", "action", ["changeRegistrationChoice"], ["value", "target.value"], ["loc", [null, [72, 21], [72, 79]]]]], ["block", "if", [["get", "embargoSelected", ["loc", [null, [76, 10], [76, 25]]]]], [], 0, null, ["loc", [null, [76, 4], [79, 11]]]], ["element", "action", ["regForm"], [], ["loc", [null, [82, 40], [82, 60]]]], ["element", "action", ["registerDraft", ["get", "editedMetadata", ["loc", [null, [83, 65], [83, 79]]]], ["get", "registrationChoice", ["loc", [null, [83, 80], [83, 98]]]], ["get", "liftEmbargo", ["loc", [null, [83, 99], [83, 110]]]]], [], ["loc", [null, [83, 40], [83, 112]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    var child2 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 85,
              "column": 0
            },
            "end": {
              "line": 90,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "btn btn-primary");
          var el3 = dom.createTextNode("Save as draft");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("button");
          dom.setAttribute(el2, "class", "btn btn-success");
          var el3 = dom.createTextNode("Register");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [1]);
          var element2 = dom.childAt(element0, [3]);
          var morphs = new Array(2);
          morphs[0] = dom.createElementMorph(element1);
          morphs[1] = dom.createElementMorph(element2);
          return morphs;
        },
        statements: [["element", "action", ["editDraft", ["get", "editedMetadata", ["loc", [null, [87, 61], [87, 75]]]], "draft"], [], ["loc", [null, [87, 40], [87, 85]]]], ["element", "action", ["regForm"], [], ["loc", [null, [88, 40], [88, 60]]]]],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 91,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/draft-registrations/detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h2");
        var el2 = dom.createTextNode(" ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode(" ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        var el2 = dom.createTextNode(" Initiated by: ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        var el2 = dom.createTextNode(" Started: ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode(" ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        var el2 = dom.createTextNode(" Last Updated: ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode(" ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("hr");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h3");
        var el2 = dom.createTextNode(" Edit Draft Registration ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(10);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(fragment, 6, 6, contextualElement);
        morphs[3] = dom.createMorphAt(fragment, 8, 8, contextualElement);
        morphs[4] = dom.createMorphAt(dom.childAt(fragment, [10]), 1, 1);
        morphs[5] = dom.createMorphAt(dom.childAt(fragment, [12]), 1, 1);
        morphs[6] = dom.createMorphAt(dom.childAt(fragment, [14]), 1, 1);
        morphs[7] = dom.createMorphAt(dom.childAt(fragment, [16]), 1, 1);
        morphs[8] = dom.createMorphAt(fragment, 22, 22, contextualElement);
        morphs[9] = dom.createMorphAt(fragment, 24, 24, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "page-title", ["OSF | Edit ", ["get", "model.branchedFrom.title", ["loc", [null, [3, 22], [3, 46]]]], " registration"], ["replace", true], ["loc", [null, [3, 0], [3, 77]]]], ["inline", "link-to", ["Back to Project", "projects.detail"], ["class", "btn btn-default"], ["loc", [null, [4, 0], [4, 71]]]], ["inline", "link-to", ["View registrations", "projects.detail.registrations"], ["class", "btn btn-primary"], ["loc", [null, [5, 0], [5, 88]]]], ["inline", "link-to", ["View draft registrations", "projects.detail.draft_registrations"], ["class", "btn btn-info"], ["loc", [null, [6, 0], [6, 97]]]], ["content", "model.registrationSchema.name", ["loc", [null, [9, 5], [9, 38]]]], ["content", "model.initiator.fullName", ["loc", [null, [10, 18], [10, 46]]]], ["inline", "moment-format", [["get", "model.datetimeInitiated", ["loc", [null, [11, 29], [11, 52]]]]], [], ["loc", [null, [11, 13], [11, 54]]]], ["inline", "moment-format", [["get", "model.datetimeUpdated", ["loc", [null, [12, 34], [12, 55]]]]], [], ["loc", [null, [12, 18], [12, 57]]]], ["block", "each", [["get", "model.registrationSchema.schema.pages", ["loc", [null, [17, 8], [17, 45]]]]], [], 0, null, ["loc", [null, [17, 0], [67, 9]]]], ["block", "if", [["get", "formDisplayed", ["loc", [null, [69, 6], [69, 19]]]]], [], 1, 2, ["loc", [null, [69, 0], [90, 7]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/draft-registrations/index/controller', ['exports', 'ember', 'ember-osf/mixins/registration-actions'], function (exports, _ember, _emberOsfMixinsRegistrationActions) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsRegistrationActions['default'], {
        actions: {
            /**
            * Toggles whether draft form is displayed.
            *
            * @method draftForm
            */
            draftForm: function draftForm() {
                this.toggleProperty('formDisplayed');
            }
        }
    });
});
// app/pods/projects/detail/draft-registrations/index/controller.js
define('ember-craft-repository/pods/projects/detail/draft-registrations/index/route', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model() {
            var project = this.modelFor('projects.detail');
            var drafts = project.get('draftRegistrations');
            return drafts;
        },
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            this.store.findAll('metaschema').then(function (metaschemas) {
                controller.set('metaschemas', metaschemas);
            });
            controller.set('project', this.modelFor('projects.detail'));
        }
    });
});
// app/pods/projects/detail/draft-registrations/index/route.js
define("ember-craft-repository/pods/projects/detail/draft-registrations/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 24,
                "column": 4
              },
              "end": {
                "line": 26,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element2 = dom.childAt(fragment, [1]);
            var morphs = new Array(2);
            morphs[0] = dom.createMorphAt(element2, 0, 0);
            morphs[1] = dom.createMorphAt(element2, 2, 2);
            return morphs;
          },
          statements: [["inline", "radio-button", [], ["name", "form", "value", ["subexpr", "@mut", [["get", "metaschema.id", ["loc", [null, [25, 44], [25, 57]]]]], [], []], "checked", ["subexpr", "@mut", [["get", "schema", ["loc", [null, [25, 66], [25, 72]]]]], [], []]], ["loc", [null, [25, 11], [25, 74]]]], ["content", "metaschema.name", ["loc", [null, [25, 75], [25, 94]]]]],
          locals: ["metaschema"],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 10,
              "column": 0
            },
            "end": {
              "line": 34,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("hr");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("h3");
          var el2 = dom.createTextNode(" Register ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n        Registration creates a frozen version of the project that can never be edited or deleted but can be withdrawn. Your original project remains editable but will now have the registration linked to it.\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode(" Things to know about registration: ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("ul");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("li");
          var el3 = dom.createTextNode(" Ensure your project is in the state you wish to freeze before registering. ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("li");
          var el3 = dom.createTextNode(" Consider turning links into forks. ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("li");
          var el3 = dom.createTextNode("Registrations can have embargo periods for up to four years. If you choose an embargo period, the registration will automatically become public when the embargo expires. ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("li");
          var el3 = dom.createTextNode(" Withdrawing a registration removes the contents of the registrations but will leave behind a log showing when the registration was created and withdrawn. ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode(" ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("strong");
          var el3 = dom.createTextNode(" Continue your registration by selecting a registration form: ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode(" ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("button");
          dom.setAttribute(el1, "type", "button");
          dom.setAttribute(el1, "class", "btn btn-default");
          var el2 = dom.createTextNode("\n        Cancel\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("button");
          dom.setAttribute(el1, "type", "button");
          dom.setAttribute(el1, "class", "btn btn-primary");
          var el2 = dom.createTextNode("\n        Create Draft\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element3 = dom.childAt(fragment, [15]);
          var element4 = dom.childAt(fragment, [17]);
          var morphs = new Array(3);
          morphs[0] = dom.createMorphAt(fragment, 13, 13, contextualElement);
          morphs[1] = dom.createElementMorph(element3);
          morphs[2] = dom.createElementMorph(element4);
          return morphs;
        },
        statements: [["block", "each", [["get", "metaschemas", ["loc", [null, [24, 12], [24, 23]]]]], [], 0, null, ["loc", [null, [24, 4], [26, 13]]]], ["element", "action", ["draftForm"], [], ["loc", [null, [28, 26], [28, 48]]]], ["element", "action", ["createDraft", ["get", "schema", ["loc", [null, [31, 49], [31, 55]]]]], [], ["loc", [null, [31, 26], [31, 57]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 34,
              "column": 0
            },
            "end": {
              "line": 38,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("button");
          dom.setAttribute(el1, "type", "button");
          dom.setAttribute(el1, "class", "btn btn-success");
          var el2 = dom.createTextNode("\n        New Registration\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element1 = dom.childAt(fragment, [1]);
          var morphs = new Array(1);
          morphs[0] = dom.createElementMorph(element1);
          return morphs;
        },
        statements: [["element", "action", ["draftForm"], [], ["loc", [null, [35, 26], [35, 48]]]]],
        locals: [],
        templates: []
      };
    })();
    var child2 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 49,
                  "column": 8
                },
                "end": {
                  "line": 51,
                  "column": 8
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("            ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("i");
              dom.setAttribute(el1, "class", "glyphicon glyphicon-pencil");
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("  Edit\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes() {
              return [];
            },
            statements: [],
            locals: [],
            templates: []
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 43,
                "column": 4
              },
              "end": {
                "line": 57,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("h3");
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createTextNode(" Initiated by: ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createTextNode(" Started: ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createTextNode(" Last Updated: ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n\n");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("button");
            dom.setAttribute(el1, "type", "button");
            dom.setAttribute(el1, "class", "btn btn-danger btn-sm");
            var el2 = dom.createTextNode("\n            ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("i");
            dom.setAttribute(el2, "class", "glyphicon glyphicon-remove");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("  Delete\n        ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("hr");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element0 = dom.childAt(fragment, [11]);
            var morphs = new Array(6);
            morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
            morphs[1] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
            morphs[2] = dom.createMorphAt(dom.childAt(fragment, [5]), 1, 1);
            morphs[3] = dom.createMorphAt(dom.childAt(fragment, [7]), 1, 1);
            morphs[4] = dom.createMorphAt(fragment, 9, 9, contextualElement);
            morphs[5] = dom.createElementMorph(element0);
            return morphs;
          },
          statements: [["content", "draft.registrationSchema.name", ["loc", [null, [44, 13], [44, 46]]]], ["content", "draft.initiator.fullName", ["loc", [null, [45, 26], [45, 54]]]], ["inline", "moment-format", [["get", "draft.datetimeInitiated", ["loc", [null, [46, 37], [46, 60]]]]], [], ["loc", [null, [46, 21], [46, 62]]]], ["inline", "moment-format", [["get", "draft.datetimeUpdated", ["loc", [null, [47, 42], [47, 63]]]]], [], ["loc", [null, [47, 26], [47, 65]]]], ["block", "link-to", ["projects.detail.draft_registrations.detail", ["get", "draft.id", ["loc", [null, [49, 64], [49, 72]]]]], ["class", "btn btn-info btn-sm"], 0, null, ["loc", [null, [49, 8], [51, 20]]]], ["element", "action", ["deleteDraft", ["get", "draft", ["loc", [null, [53, 53], [53, 58]]]]], [], ["loc", [null, [53, 30], [53, 60]]]]],
          locals: ["draft"],
          templates: [child0]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 42,
              "column": 0
            },
            "end": {
              "line": 58,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "each", [["get", "model", ["loc", [null, [43, 12], [43, 17]]]]], [], 0, null, ["loc", [null, [43, 4], [57, 13]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 59,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/draft-registrations/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/draft-registrations/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h2");
        var el2 = dom.createTextNode(" Draft Registrations ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("hr");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(6);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(fragment, 6, 6, contextualElement);
        morphs[3] = dom.createMorphAt(fragment, 10, 10, contextualElement);
        morphs[4] = dom.createMorphAt(fragment, 12, 12, contextualElement);
        morphs[5] = dom.createMorphAt(fragment, 16, 16, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]], ["inline", "page-title", ["Draft Registrations"], [], ["loc", [null, [3, 0], [3, 31]]]], ["inline", "link-to", ["Back to Project", "projects.detail"], ["class", "btn btn-default"], ["loc", [null, [4, 0], [4, 71]]]], ["inline", "link-to", ["View Registrations", "projects.detail.registrations"], ["class", "btn btn-primary"], ["loc", [null, [8, 0], [8, 88]]]], ["block", "if", [["get", "formDisplayed", ["loc", [null, [10, 6], [10, 19]]]]], [], 0, 1, ["loc", [null, [10, 0], [38, 7]]]], ["block", "if", [["get", "model", ["loc", [null, [42, 6], [42, 11]]]]], [], 2, null, ["loc", [null, [42, 0], [58, 7]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/index/controller', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Controller.extend({
        actions: {
            fileDetail: function fileDetail(file) {
                this.transitionToRoute('projects.detail.files.provider.file', this.get('project'), file.get('provider'), file);
            },
            projectDetail: function projectDetail(project) {
                this.transitionToRoute('projects.detail', project);
            }
        }
    });
});
// app/pods/projects/detail/files/index/controller.js
define('ember-craft-repository/pods/projects/detail/files/index/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            var project = this.modelFor('projects.detail');
            controller.set('project', project);
        },
        actions: {
            refreshModel: function refreshModel() {
                this.modelFor('projects.detail.files.index').reload();
                this.refresh();
                console.log('Model reloaded.');
            }
        }
    });
});
// app/pods/projects/detail/files/index/route.js
define("ember-craft-repository/pods/projects/detail/files/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 20,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 3, 3, contextualElement);
        return morphs;
      },
      statements: [["inline", "file-browser", [], ["files", ["subexpr", "@mut", [["get", "model", ["loc", [null, [18, 21], [18, 26]]]]], [], []], "rootItem", ["subexpr", "@mut", [["get", "project", ["loc", [null, [18, 36], [18, 43]]]]], [], []], "openFile", ["subexpr", "action", ["fileDetail"], [], ["loc", [null, [18, 53], [18, 74]]]], "openNode", ["subexpr", "action", ["projectDetail"], [], ["loc", [null, [19, 13], [19, 37]]]], "refreshModel", "refreshModel"], ["loc", [null, [18, 0], [19, 67]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/provider/file/controller', ['exports', 'ember', 'ember-osf/mixins/commentable', 'ember-osf/mixins/taggable-mixin'], function (exports, _ember, _emberOsfMixinsCommentable, _emberOsfMixinsTaggableMixin) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsCommentable['default'], _emberOsfMixinsTaggableMixin['default'], {
        fileManager: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        checkedIn: _ember['default'].computed.none('model.checkout'),
        canCheckIn: _ember['default'].computed('model.checkout', 'session.data.authenticated.id', function () {
            var checkoutID = this.get('model.checkout');
            var userID = this.get('session.data.authenticated.id');
            return checkoutID === userID;
        }),
        canEdit: _ember['default'].computed.or('checkedIn', 'canCheckIn'),
        actions: {
            fileDetail: function fileDetail(file) {
                this.transitionToRoute('projects.detail.files.provider.file', this.get('project'), file.get('provider'), file);
            },

            projectDetail: function projectDetail(project) {
                this.transitionToRoute('projects.detail', project);
            },

            'delete': function _delete() {
                var _this = this;

                var file = this.get('model');
                this.get('fileManager').deleteFile(file).then(function () {
                    _this.transitionToRoute('projects.detail.files', _this.get('node'));
                });
            },

            checkOut: function checkOut() {
                var file = this.get('model');
                this.get('fileManager').checkOut(file);
            },

            checkIn: function checkIn() {
                var file = this.get('model');
                this.get('fileManager').checkIn(file);
            }
        }
    });
});
// app/pods/projects/detail/files/provider/file/controller.js
define("ember-craft-repository/pods/projects/detail/files/provider/file/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 2,
              "column": 0
            },
            "end": {
              "line": 4,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/index/template.hbs"
        },
        isEmpty: true,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 5,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/provider/file/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["block", "file-renderer", [], ["download", ["subexpr", "@mut", [["get", "model.links.download", ["loc", [null, [2, 26], [2, 46]]]]], [], []], "width", "800", "height", "1000"], 0, null, ["loc", [null, [2, 0], [4, 18]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/provider/file/revisions/route', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model() {
            var file = this.modelFor('projects.detail.files.provider.file');
            return file.get('versions');
        }
    });
});
// app/pods/projects/detail/files/provider/file/revisions/route.js
define("ember-craft-repository/pods/projects/detail/files/provider/file/revisions/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 12,
              "column": 8
            },
            "end": {
              "line": 14,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/revisions/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["inline", "file-version", [], ["version", ["subexpr", "@mut", [["get", "version", ["loc", [null, [13, 35], [13, 42]]]]], [], []], "download", "download"], ["loc", [null, [13, 12], [13, 64]]]]],
        locals: ["version"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 17,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/revisions/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/provider/file/revisions/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h3");
        var el2 = dom.createTextNode("Revisions");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("table");
        dom.setAttribute(el1, "class", "table table-bordered");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("thead");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("tr");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("Version");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("Size");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("Download");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("tbody");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [4, 3]), 1, 1);
        return morphs;
      },
      statements: [["block", "each", [["get", "model", ["loc", [null, [12, 16], [12, 21]]]]], [], 0, null, ["loc", [null, [12, 8], [14, 17]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/provider/file/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        fileManager: _ember['default'].inject.service(),
        model: function model(params) {
            // TODO:60 verify this file actually belongs to the parent project?
            return this.store.findRecord('file', params.file_id);
        },
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            var project = this.modelFor('projects.detail');
            controller.set('project', project);
        },
        actions: {
            download: function download(versionID) {
                var file = this.modelFor(this.routeName);
                var options = {};
                if (typeof versionID !== 'undefined') {
                    options.query = {
                        version: versionID
                    };
                }
                var url = this.get('fileManager').getDownloadUrl(file, options);
                window.open(url);
            }
        }
    });
});
// app/pods/projects/detail/files/provider/file/route.js
define("ember-craft-repository/pods/projects/detail/files/provider/file/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 4,
              "column": 4
            },
            "end": {
              "line": 6,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        Back to ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["content", "model.provider", ["loc", [null, [5, 16], [5, 34]]]]],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 13,
              "column": 8
            },
            "end": {
              "line": 18,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          dom.setAttribute(el1, "class", "bg-warning");
          var el2 = dom.createTextNode("\n                This file is checked out by a\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode(".\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
          return morphs;
        },
        statements: [["inline", "link-to", ["collaborator", "users.detail", ["get", "model.checkout", ["loc", [null, [16, 56], [16, 70]]]]], [], ["loc", [null, [16, 16], [16, 72]]]]],
        locals: [],
        templates: []
      };
    })();
    var child2 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 21,
                "column": 16
              },
              "end": {
                "line": 25,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("button");
            dom.setAttribute(el1, "class", "btn btn-sm btn-warning");
            var el2 = dom.createTextNode("\n                        Check in\n                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element2 = dom.childAt(fragment, [1]);
            var morphs = new Array(1);
            morphs[0] = dom.createElementMorph(element2);
            return morphs;
          },
          statements: [["element", "action", ["checkIn"], [], ["loc", [null, [22, 28], [22, 48]]]]],
          locals: [],
          templates: []
        };
      })();
      var child1 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 25,
                "column": 16
              },
              "end": {
                "line": 32,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("button");
            dom.setAttribute(el1, "class", "btn btn-sm btn-danger");
            var el2 = dom.createTextNode("\n                        Delete\n                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n                    ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("button");
            dom.setAttribute(el1, "class", "btn btn-sm btn-warning");
            var el2 = dom.createTextNode("\n                        Check out\n                    ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element0 = dom.childAt(fragment, [1]);
            var element1 = dom.childAt(fragment, [3]);
            var morphs = new Array(2);
            morphs[0] = dom.createElementMorph(element0);
            morphs[1] = dom.createElementMorph(element1);
            return morphs;
          },
          statements: [["element", "action", ["delete"], [], ["loc", [null, [26, 28], [26, 47]]]], ["element", "action", ["checkOut"], [], ["loc", [null, [29, 28], [29, 49]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 20,
              "column": 12
            },
            "end": {
              "line": 34,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          return morphs;
        },
        statements: [["block", "if", [["get", "canCheckIn", ["loc", [null, [21, 22], [21, 32]]]]], [], 0, 1, ["loc", [null, [21, 16], [32, 23]]]]],
        locals: [],
        templates: [child0, child1]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 76,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/file/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/provider/file/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "row");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "col-sm-5");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("h2");
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "col-sm-7");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "pull-right");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("button");
        dom.setAttribute(el4, "class", "btn btn-sm btn-primary");
        var el5 = dom.createTextNode("\n                Download\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("hr");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "row");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "col-md-3");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("p");
        var el5 = dom.createElement("label");
        var el6 = dom.createTextNode(" Tags ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "col-md-9");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "row");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element3 = dom.childAt(fragment, [6]);
        var element4 = dom.childAt(element3, [3]);
        var element5 = dom.childAt(element4, [3]);
        var element6 = dom.childAt(element5, [3]);
        var element7 = dom.childAt(fragment, [10]);
        var element8 = dom.childAt(element7, [1]);
        var morphs = new Array(12);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(dom.childAt(fragment, [4]), 1, 1);
        morphs[2] = dom.createMorphAt(dom.childAt(element3, [1, 1]), 0, 0);
        morphs[3] = dom.createMorphAt(element4, 1, 1);
        morphs[4] = dom.createMorphAt(element5, 1, 1);
        morphs[5] = dom.createElementMorph(element6);
        morphs[6] = dom.createMorphAt(element5, 5, 5);
        morphs[7] = dom.createMorphAt(element5, 7, 7);
        morphs[8] = dom.createMorphAt(element8, 1, 1);
        morphs[9] = dom.createMorphAt(dom.childAt(element8, [3]), 3, 3);
        morphs[10] = dom.createMorphAt(dom.childAt(element7, [3]), 1, 1);
        morphs[11] = dom.createMorphAt(dom.childAt(fragment, [12]), 1, 1);
        return morphs;
      },
      statements: [["inline", "page-title", ["OSF | ", ["get", "model.name", ["loc", [null, [2, 17], [2, 27]]]]], ["replace", true], ["loc", [null, [2, 0], [2, 42]]]], ["block", "link-to", ["projects.detail.files.provider", ["get", "node", ["loc", [null, [4, 48], [4, 52]]]], ["get", "model.provider", ["loc", [null, [4, 53], [4, 67]]]]], ["class", "ui button"], 0, null, ["loc", [null, [4, 4], [6, 16]]]], ["content", "model.name", ["loc", [null, [10, 12], [10, 26]]]], ["block", "unless", [["get", "canEdit", ["loc", [null, [13, 18], [13, 25]]]]], [], 1, null, ["loc", [null, [13, 8], [18, 19]]]], ["block", "if", [["get", "canEdit", ["loc", [null, [20, 18], [20, 25]]]]], [], 2, null, ["loc", [null, [20, 12], [34, 19]]]], ["element", "action", ["download"], [], ["loc", [null, [35, 20], [35, 41]]]], ["inline", "link-to", ["View", "projects.detail.files.provider.file.index", ["get", "node", ["loc", [null, [40, 16], [40, 20]]]], ["get", "model.provider", ["loc", [null, [40, 21], [40, 35]]]], ["get", "model", ["loc", [null, [40, 36], [40, 41]]]]], ["class", "btn btn-sm btn-primary"], ["loc", [null, [38, 12], [41, 48]]]], ["inline", "link-to", ["Revisions", "projects.detail.files.provider.file.revisions", ["get", "node", ["loc", [null, [44, 16], [44, 20]]]], ["get", "model.provider", ["loc", [null, [44, 21], [44, 35]]]], ["get", "model", ["loc", [null, [44, 36], [44, 41]]]]], ["class", "btn btn-sm btn-primary"], ["loc", [null, [42, 12], [45, 48]]]], ["inline", "file-browser", [], ["rootItem", ["subexpr", "@mut", [["get", "node", ["loc", [null, [52, 32], [52, 36]]]]], [], []], "selectedFile", ["subexpr", "@mut", [["get", "model", ["loc", [null, [53, 21], [53, 26]]]]], [], []], "openFile", ["subexpr", "action", ["fileDetail"], [], ["loc", [null, [54, 17], [54, 38]]]], "openNode", ["subexpr", "action", ["projectDetail"], [], ["loc", [null, [55, 17], [55, 41]]]]], ["loc", [null, [52, 8], [56, 10]]]], ["inline", "tags-widget", [], ["addATag", ["subexpr", "action", ["addATag", ["get", "model", ["loc", [null, [59, 52], [59, 57]]]]], [], ["loc", [null, [59, 34], [59, 58]]]], "removeATag", ["subexpr", "action", ["removeATag", ["get", "model", ["loc", [null, [59, 91], [59, 96]]]]], [], ["loc", [null, [59, 70], [59, 97]]]], "tags", ["subexpr", "@mut", [["get", "model.tags", ["loc", [null, [59, 103], [59, 113]]]]], [], []]], ["loc", [null, [59, 12], [59, 115]]]], ["content", "outlet", ["loc", [null, [63, 8], [63, 18]]]], ["inline", "comment-pane", [], ["comments", ["subexpr", "@mut", [["get", "comments", ["loc", [null, [69, 13], [69, 21]]]]], [], []], "addComment", ["subexpr", "action", ["addComment"], [], ["loc", [null, [70, 15], [70, 36]]]], "editComment", ["subexpr", "action", ["editComment"], [], ["loc", [null, [71, 16], [71, 38]]]], "deleteComment", ["subexpr", "action", ["deleteComment"], [], ["loc", [null, [72, 18], [72, 42]]]], "restoreComment", ["subexpr", "action", ["restoreComment"], [], ["loc", [null, [73, 19], [73, 44]]]], "reportComment", ["subexpr", "action", ["reportComment"], [], ["loc", [null, [74, 18], [74, 42]]]]], ["loc", [null, [68, 4], [74, 44]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/provider/index/controller', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Controller.extend({
        actions: {
            reloadFiles: function reloadFiles() {
                // TODO?
            }
        }
    });
});
// app/pods/projects/detail/files/provider/index/controller.js
define('ember-craft-repository/pods/projects/detail/files/provider/index/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            var project = this.modelFor('projects.detail');
            controller.set('project', project);
        }
    });
});
define("ember-craft-repository/pods/projects/detail/files/provider/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 20,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/provider/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "panel");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h2");
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("ID: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Provider: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Path: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h3");
        var el3 = dom.createTextNode("Files");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("hr");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h3");
        var el3 = dom.createTextNode("Actions");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2]);
        var morphs = new Array(7);
        morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
        morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 0, 0);
        morphs[2] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
        morphs[3] = dom.createMorphAt(dom.childAt(element0, [7]), 1, 1);
        morphs[4] = dom.createMorphAt(dom.childAt(element0, [9]), 1, 1);
        morphs[5] = dom.createMorphAt(element0, 13, 13);
        morphs[6] = dom.createMorphAt(element0, 19, 19);
        return morphs;
      },
      statements: [["inline", "link-to", ["Back to providers", "projects.detail.files", ["get", "model.node", ["loc", [null, [5, 8], [5, 18]]]]], ["class", "btn"], ["loc", [null, [4, 8], [5, 32]]]], ["content", "model.name", ["loc", [null, [7, 8], [7, 22]]]], ["content", "model.id", ["loc", [null, [8, 26], [8, 38]]]], ["content", "model.provider", ["loc", [null, [9, 32], [9, 50]]]], ["content", "model.path", ["loc", [null, [10, 28], [10, 42]]]], ["inline", "file-tree", [], ["root", ["subexpr", "@mut", [["get", "model", ["loc", [null, [13, 21], [13, 26]]]]], [], []], "project", ["subexpr", "@mut", [["get", "model.node", ["loc", [null, [13, 35], [13, 45]]]]], [], []]], ["loc", [null, [13, 4], [13, 47]]]], ["inline", "file-actions", [], ["file", ["subexpr", "@mut", [["get", "model", ["loc", [null, [18, 24], [18, 29]]]]], [], []], "onChange", ["subexpr", "action", ["reloadFiles"], [], ["loc", [null, [18, 39], [18, 61]]]]], ["loc", [null, [18, 4], [18, 63]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/provider/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        model: function model(params) {
            var fileProviders = this.modelFor('projects.detail.files');
            // console.log(params);
            // console.log(fileProviders);
            return fileProviders.findBy('provider', params.provider);
        }
    });
});
// app/pods/projects/detail/files/provider/route.js
define("ember-craft-repository/pods/projects/detail/files/provider/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/provider/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/provider/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/files/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        model: function model() {
            var project = this.modelFor('projects.detail');
            return project.get('files');
        },

        setupController: function setupController(controller, model) {
            this._super(controller, model);
            var project = this.modelFor('projects.detail');
            controller.set('project', project);
        }
    });
});
// app/pods/projects/detail/files/route.js
define("ember-craft-repository/pods/projects/detail/files/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 7,
              "column": 12
            },
            "end": {
              "line": 9,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                Back to Project: ");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
          return morphs;
        },
        statements: [["content", "project.title", ["loc", [null, [8, 33], [8, 50]]]]],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 12,
                "column": 16
              },
              "end": {
                "line": 14,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/files/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    Parent: ");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
            return morphs;
          },
          statements: [["content", "project.parent.title", ["loc", [null, [13, 28], [13, 52]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 10,
              "column": 12
            },
            "end": {
              "line": 15,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/files/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "up angle icon divider");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 3, 3, contextualElement);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "link-to", ["projects.detail", ["get", "model.parent", ["loc", [null, [12, 45], [12, 57]]]]], ["class", "section"], 0, null, ["loc", [null, [12, 16], [14, 28]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 21,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/files/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/files/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui two column doubling grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui breadcrumb");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("i");
        dom.setAttribute(el4, "class", "left angle icon divider");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [4, 1, 1]);
        var morphs = new Array(4);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(element0, 3, 3);
        morphs[2] = dom.createMorphAt(element0, 4, 4);
        morphs[3] = dom.createMorphAt(fragment, 6, 6, contextualElement);
        return morphs;
      },
      statements: [["inline", "page-title", ["| Files"], [], ["loc", [null, [2, 0], [2, 19]]]], ["block", "link-to", ["projects.detail"], ["class", "section"], 0, null, ["loc", [null, [7, 12], [9, 24]]]], ["block", "if", [["get", "project.parent", ["loc", [null, [10, 18], [10, 32]]]]], [], 1, null, ["loc", [null, [10, 12], [15, 19]]]], ["content", "outlet", ["loc", [null, [20, 0], [20, 10]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/index/controller', ['exports', 'ember', 'ember-osf/mixins/commentable', 'ember-osf/mixins/taggable-mixin', 'ember-osf/mixins/node-actions'], function (exports, _ember, _emberOsfMixinsCommentable, _emberOsfMixinsTaggableMixin, _emberOsfMixinsNodeActions) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsCommentable['default'], _emberOsfMixinsTaggableMixin['default'], _emberOsfMixinsNodeActions['default'], {
        responseSuccess: '',
        responseError: '',
        selectedModel: '',
        files: null,
        actions: {
            requestDelete: function requestDelete(project, name) {
                // jshint ignore:line
                this.set('selectedModel', project);
                this.selectedModel.deleteRecord();
                $('.ui.modal').modal('setting', 'closable', false).modal('show'); // jshint ignore:line
            },
            confirmDelete: function confirmDelete() {
                var self = this;
                this.selectedModel.save().then(function () {
                    self.transitionToRoute('projects.index');
                });
            },
            cancelDelete: function cancelDelete() {
                this.selectedModel.rollbackAttributes();
            },
            closeMessage: function closeMessage() {
                this.set('responseSuccess', '');
                this.set('responseError', '');
            },
            fileDetail: function fileDetail(file) {
                this.transitionToRoute('projects.detail.files.provider.file', this.get('project'), file.get('provider'), file);
            },
            projectDetail: function projectDetail(project) {
                this.transitionToRoute('projects.detail', project);
            }
        }
    });
});
// app/pods/projects/detail/index/controller.js
define('ember-craft-repository/pods/projects/detail/index/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        model: function model() {
            var project = this.modelFor('projects.detail');
            return project.get('files');
        },
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            var project = this.modelFor('projects.detail');
            controller.set('files', model);
            controller.set('model', project);
        },
        actions: {
            refreshModel: function refreshModel() {
                this.modelFor('projects.detail.files.index').reload();
                this.refresh();
                console.log(this);
                console.log('Model reloaded.');
            }
        }
    });
});
// app/pods/projects/detail/index/route.js
define("ember-craft-repository/pods/projects/detail/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 7,
              "column": 12
            },
            "end": {
              "line": 9,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/index/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                Back to Projects List\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    var child1 = (function () {
      var child0 = (function () {
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 12,
                "column": 16
              },
              "end": {
                "line": 14,
                "column": 16
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/index/template.hbs"
          },
          isEmpty: false,
          arity: 0,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("                    Parent: ");
            dom.appendChild(el0, el1);
            var el1 = dom.createComment("");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var morphs = new Array(1);
            morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
            return morphs;
          },
          statements: [["content", "model.parent.title", ["loc", [null, [13, 28], [13, 50]]]]],
          locals: [],
          templates: []
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 10,
              "column": 12
            },
            "end": {
              "line": 15,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/index/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("i");
          dom.setAttribute(el1, "class", "up angle icon divider");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 3, 3, contextualElement);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "link-to", ["projects.detail", ["get", "model.parent", ["loc", [null, [12, 45], [12, 57]]]]], ["class", "section"], 0, null, ["loc", [null, [12, 16], [14, 28]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 183,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui two column doubling grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui breadcrumb");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("i");
        dom.setAttribute(el4, "class", "left angle icon divider");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui two column stackable grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment(" TODO: Check this to make sure the ember-osf comment-pane works ");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui one column row");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "column");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui one column row");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "column");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "ui one column row");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "column");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment(" TODO: Delete this section of code after creating child project component is functioning. ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n    ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode(" ");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment(" TODO: Is this necessary? ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment(" TODO: Will work on all that follows later ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [2, 1, 1]);
        var element1 = dom.childAt(fragment, [4]);
        var morphs = new Array(8);
        morphs[0] = dom.createMorphAt(element0, 3, 3);
        morphs[1] = dom.createMorphAt(element0, 4, 4);
        morphs[2] = dom.createMorphAt(dom.childAt(element1, [1]), 2, 2);
        morphs[3] = dom.createMorphAt(dom.childAt(element1, [3]), 4, 4);
        morphs[4] = dom.createMorphAt(dom.childAt(element1, [5, 1]), 2, 2);
        morphs[5] = dom.createMorphAt(dom.childAt(element1, [7, 1]), 2, 2);
        morphs[6] = dom.createMorphAt(dom.childAt(element1, [9, 1]), 2, 2);
        morphs[7] = dom.createMorphAt(fragment, 7, 7, contextualElement);
        return morphs;
      },
      statements: [["block", "link-to", ["projects"], ["class", "section"], 0, null, ["loc", [null, [7, 12], [9, 24]]]], ["block", "if", [["get", "model.parent", ["loc", [null, [10, 18], [10, 30]]]]], [], 1, null, ["loc", [null, [10, 12], [15, 19]]]], ["inline", "project-summary", [], ["addATag", "addATag", "removeATag", "removeATag", "model", ["subexpr", "@mut", [["get", "model", ["loc", [null, [30, 74], [30, 79]]]]], [], []]], ["loc", [null, [30, 8], [30, 81]]]], ["inline", "comment-pane", [], ["comments", ["subexpr", "@mut", [["get", "comments", ["loc", [null, [36, 21], [36, 29]]]]], [], []], "addComment", ["subexpr", "action", ["addComment"], [], ["loc", [null, [37, 23], [37, 44]]]], "editComment", ["subexpr", "action", ["editComment"], [], ["loc", [null, [38, 24], [38, 46]]]], "deleteComment", ["subexpr", "action", ["deleteComment"], [], ["loc", [null, [39, 26], [39, 50]]]], "restoreComment", ["subexpr", "action", ["restoreComment"], [], ["loc", [null, [40, 27], [40, 52]]]], "reportComment", ["subexpr", "action", ["reportComment"], [], ["loc", [null, [41, 26], [41, 50]]]]], ["loc", [null, [35, 8], [42, 10]]]], ["inline", "log-detail", [], ["model-logs", ["subexpr", "@mut", [["get", "model.logs", ["loc", [null, [47, 36], [47, 46]]]]], [], []]], ["loc", [null, [47, 12], [47, 48]]]], ["inline", "contrib-manager", [], ["contributors", ["subexpr", "@mut", [["get", "model.contributors", ["loc", [null, [53, 43], [53, 61]]]]], [], []], "removeContributor", ["subexpr", "action", ["removeContributor"], [], ["loc", [null, [53, 80], [53, 108]]]], "editContributors", ["subexpr", "action", ["updateContributors"], [], ["loc", [null, [54, 33], [54, 62]]]], "addContributor", ["subexpr", "action", ["addContributor"], [], ["loc", [null, [54, 78], [54, 103]]]]], ["loc", [null, [53, 12], [54, 105]]]], ["inline", "file-browser", [], ["files", ["subexpr", "@mut", [["get", "files", ["loc", [null, [61, 33], [61, 38]]]]], [], []], "rootItem", ["subexpr", "@mut", [["get", "model", ["loc", [null, [61, 48], [61, 53]]]]], [], []], "openFile", ["subexpr", "action", ["fileDetail"], [], ["loc", [null, [61, 63], [61, 84]]]], "openNode", ["subexpr", "action", ["projectDetail"], [], ["loc", [null, [62, 25], [62, 49]]]]], ["loc", [null, [61, 12], [62, 51]]]], ["content", "outlet", ["loc", [null, [77, 0], [77, 10]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/registrations/route', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model() {
            var project = this.modelFor('projects.detail');
            var registrations = project.get('registrations');
            return registrations;
        }
    });
});
// app/pods/projects/detail/files/registraions/route.js
define("ember-craft-repository/pods/projects/detail/registrations/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      var child0 = (function () {
        var child0 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 15,
                  "column": 12
                },
                "end": {
                  "line": 17,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("strong");
              var el2 = dom.createTextNode(" Pending Registration ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes() {
              return [];
            },
            statements: [],
            locals: [],
            templates: []
          };
        })();
        var child1 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 18,
                  "column": 12
                },
                "end": {
                  "line": 20,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("strong");
              var el2 = dom.createTextNode(" Pending Embargo ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes() {
              return [];
            },
            statements: [],
            locals: [],
            templates: []
          };
        })();
        var child2 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 21,
                  "column": 12
                },
                "end": {
                  "line": 23,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("strong");
              var el2 = dom.createTextNode(" Pending Withdrawal ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes() {
              return [];
            },
            statements: [],
            locals: [],
            templates: []
          };
        })();
        var child3 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 24,
                  "column": 12
                },
                "end": {
                  "line": 26,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("strong");
              var el2 = dom.createTextNode(" Withdrawn ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes() {
              return [];
            },
            statements: [],
            locals: [],
            templates: []
          };
        })();
        var child4 = (function () {
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 27,
                  "column": 12
                },
                "end": {
                  "line": 29,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
            },
            isEmpty: false,
            arity: 0,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createComment("");
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n            ");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(1);
              morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
              return morphs;
            },
            statements: [["content", "registration.title", ["loc", [null, [28, 16], [28, 38]]]]],
            locals: [],
            templates: []
          };
        })();
        var child5 = (function () {
          var child0 = (function () {
            var child0 = (function () {
              return {
                meta: {
                  "fragmentReason": false,
                  "revision": "Ember@2.4.6",
                  "loc": {
                    "source": null,
                    "start": {
                      "line": 35,
                      "column": 24
                    },
                    "end": {
                      "line": 37,
                      "column": 24
                    }
                  },
                  "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
                },
                isEmpty: false,
                arity: 0,
                cachedFragment: null,
                hasRendered: false,
                buildFragment: function buildFragment(dom) {
                  var el0 = dom.createDocumentFragment();
                  var el1 = dom.createTextNode("                            ");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createComment("");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createTextNode(",\n");
                  dom.appendChild(el0, el1);
                  return el0;
                },
                buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                  var morphs = new Array(1);
                  morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
                  return morphs;
                },
                statements: [["content", "contrib.users.familyName", ["loc", [null, [36, 28], [36, 56]]]]],
                locals: [],
                templates: []
              };
            })();
            return {
              meta: {
                "fragmentReason": false,
                "revision": "Ember@2.4.6",
                "loc": {
                  "source": null,
                  "start": {
                    "line": 34,
                    "column": 20
                  },
                  "end": {
                    "line": 38,
                    "column": 20
                  }
                },
                "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
              },
              isEmpty: false,
              arity: 0,
              cachedFragment: null,
              hasRendered: false,
              buildFragment: function buildFragment(dom) {
                var el0 = dom.createDocumentFragment();
                var el1 = dom.createComment("");
                dom.appendChild(el0, el1);
                return el0;
              },
              buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                var morphs = new Array(1);
                morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                dom.insertBoundary(fragment, 0);
                dom.insertBoundary(fragment, null);
                return morphs;
              },
              statements: [["block", "link-to", ["users.detail", ["get", "contrib.users.id", ["loc", [null, [35, 50], [35, 66]]]]], [], 0, null, ["loc", [null, [35, 24], [37, 36]]]]],
              locals: [],
              templates: [child0]
            };
          })();
          var child1 = (function () {
            var child0 = (function () {
              return {
                meta: {
                  "fragmentReason": false,
                  "revision": "Ember@2.4.6",
                  "loc": {
                    "source": null,
                    "start": {
                      "line": 39,
                      "column": 24
                    },
                    "end": {
                      "line": 41,
                      "column": 24
                    }
                  },
                  "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
                },
                isEmpty: false,
                arity: 0,
                cachedFragment: null,
                hasRendered: false,
                buildFragment: function buildFragment(dom) {
                  var el0 = dom.createDocumentFragment();
                  var el1 = dom.createTextNode("                            ");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createComment("");
                  dom.appendChild(el0, el1);
                  var el1 = dom.createTextNode(",\n");
                  dom.appendChild(el0, el1);
                  return el0;
                },
                buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                  var morphs = new Array(1);
                  morphs[0] = dom.createMorphAt(fragment, 1, 1, contextualElement);
                  return morphs;
                },
                statements: [["content", "contrib.users.fullName", ["loc", [null, [40, 28], [40, 54]]]]],
                locals: [],
                templates: []
              };
            })();
            return {
              meta: {
                "fragmentReason": false,
                "revision": "Ember@2.4.6",
                "loc": {
                  "source": null,
                  "start": {
                    "line": 38,
                    "column": 20
                  },
                  "end": {
                    "line": 42,
                    "column": 20
                  }
                },
                "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
              },
              isEmpty: false,
              arity: 0,
              cachedFragment: null,
              hasRendered: false,
              buildFragment: function buildFragment(dom) {
                var el0 = dom.createDocumentFragment();
                var el1 = dom.createComment("");
                dom.appendChild(el0, el1);
                return el0;
              },
              buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
                var morphs = new Array(1);
                morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
                dom.insertBoundary(fragment, 0);
                dom.insertBoundary(fragment, null);
                return morphs;
              },
              statements: [["block", "link-to", ["users.detail", ["get", "contrib.users.id", ["loc", [null, [39, 50], [39, 66]]]]], [], 0, null, ["loc", [null, [39, 24], [41, 36]]]]],
              locals: [],
              templates: [child0]
            };
          })();
          return {
            meta: {
              "fragmentReason": false,
              "revision": "Ember@2.4.6",
              "loc": {
                "source": null,
                "start": {
                  "line": 32,
                  "column": 12
                },
                "end": {
                  "line": 44,
                  "column": 12
                }
              },
              "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
            },
            isEmpty: false,
            arity: 1,
            cachedFragment: null,
            hasRendered: false,
            buildFragment: function buildFragment(dom) {
              var el0 = dom.createDocumentFragment();
              var el1 = dom.createTextNode("                ");
              dom.appendChild(el0, el1);
              var el1 = dom.createElement("span");
              var el2 = dom.createTextNode("\n");
              dom.appendChild(el1, el2);
              var el2 = dom.createComment("");
              dom.appendChild(el1, el2);
              var el2 = dom.createTextNode("                ");
              dom.appendChild(el1, el2);
              dom.appendChild(el0, el1);
              var el1 = dom.createTextNode("\n");
              dom.appendChild(el0, el1);
              return el0;
            },
            buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
              var morphs = new Array(1);
              morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
              return morphs;
            },
            statements: [["block", "if", [["get", "contrib.users.familyName", ["loc", [null, [34, 26], [34, 50]]]]], [], 0, 1, ["loc", [null, [34, 20], [42, 27]]]]],
            locals: ["contrib"],
            templates: [child0, child1]
          };
        })();
        return {
          meta: {
            "fragmentReason": false,
            "revision": "Ember@2.4.6",
            "loc": {
              "source": null,
              "start": {
                "line": 13,
                "column": 4
              },
              "end": {
                "line": 51,
                "column": 4
              }
            },
            "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
          },
          isEmpty: false,
          arity: 1,
          cachedFragment: null,
          hasRendered: false,
          buildFragment: function buildFragment(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode(" | Registered: ");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n        ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("p");
            var el2 = dom.createTextNode("\n");
            dom.appendChild(el1, el2);
            var el2 = dom.createComment("");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("        ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("        ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("hr");
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
            var element0 = dom.childAt(fragment, [1]);
            var morphs = new Array(7);
            morphs[0] = dom.createMorphAt(element0, 1, 1);
            morphs[1] = dom.createMorphAt(element0, 2, 2);
            morphs[2] = dom.createMorphAt(element0, 3, 3);
            morphs[3] = dom.createMorphAt(element0, 4, 4);
            morphs[4] = dom.createMorphAt(element0, 5, 5);
            morphs[5] = dom.createMorphAt(element0, 7, 7);
            morphs[6] = dom.createMorphAt(dom.childAt(fragment, [3]), 1, 1);
            return morphs;
          },
          statements: [["block", "if", [["get", "registration.pendingRegistrationApproval", ["loc", [null, [15, 18], [15, 58]]]]], [], 0, null, ["loc", [null, [15, 12], [17, 19]]]], ["block", "if", [["get", "registration.pendingEmbargoApproval", ["loc", [null, [18, 18], [18, 53]]]]], [], 1, null, ["loc", [null, [18, 12], [20, 19]]]], ["block", "if", [["get", "registration.pendingWithdrawal", ["loc", [null, [21, 18], [21, 48]]]]], [], 2, null, ["loc", [null, [21, 12], [23, 19]]]], ["block", "if", [["get", "registration.withdrawn", ["loc", [null, [24, 18], [24, 40]]]]], [], 3, null, ["loc", [null, [24, 12], [26, 19]]]], ["block", "link-to", ["registrations.detail", ["get", "registration.id", ["loc", [null, [27, 46], [27, 61]]]]], [], 4, null, ["loc", [null, [27, 12], [29, 24]]]], ["inline", "moment-format", [["get", "registration.dateRegistered", ["loc", [null, [29, 55], [29, 82]]]]], [], ["loc", [null, [29, 39], [29, 84]]]], ["block", "each", [["get", "registration.contributors", ["loc", [null, [32, 20], [32, 45]]]]], [], 5, null, ["loc", [null, [32, 12], [44, 21]]]]],
          locals: ["registration"],
          templates: [child0, child1, child2, child3, child4, child5]
        };
      })();
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 12,
              "column": 0
            },
            "end": {
              "line": 52,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createComment("");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
          dom.insertBoundary(fragment, 0);
          dom.insertBoundary(fragment, null);
          return morphs;
        },
        statements: [["block", "each", [["get", "model", ["loc", [null, [13, 12], [13, 17]]]]], [], 0, null, ["loc", [null, [13, 4], [51, 13]]]]],
        locals: [],
        templates: [child0]
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 52,
              "column": 0
            },
            "end": {
              "line": 57,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
        },
        isEmpty: false,
        arity: 0,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("\n        There have been no completed registrations of this project. You can start a new registration by clicking the\n        New registration” button, and you have the option of saving as a draft registration before submission.\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes() {
          return [];
        },
        statements: [],
        locals: [],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 58,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/registrations/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/registrationsl/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h2");
        var el2 = dom.createTextNode(" Registrations ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("hr");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(5);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(fragment, 6, 6, contextualElement);
        morphs[3] = dom.createMorphAt(fragment, 10, 10, contextualElement);
        morphs[4] = dom.createMorphAt(fragment, 14, 14, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]], ["inline", "page-title", ["Registrations"], [], ["loc", [null, [3, 0], [3, 25]]]], ["inline", "link-to", ["Back to node", "projects.detail"], ["class", "btn btn-default"], ["loc", [null, [4, 0], [4, 68]]]], ["inline", "link-to", ["View Drafts", "projects.detail.draft_registrations"], ["class", "btn btn-primary"], ["loc", [null, [8, 0], [8, 87]]]], ["block", "if", [["get", "model", ["loc", [null, [12, 6], [12, 11]]]]], [], 0, 1, ["loc", [null, [12, 0], [57, 7]]]]],
      locals: [],
      templates: [child0, child1]
    };
  })());
});
define('ember-craft-repository/pods/projects/detail/route', ['exports', 'ember', 'ember-osf/const/permissions', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberOsfConstPermissions, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        model: function model(params) {
            return this.store.findRecord('node', params.node_id);
        },
        setupController: function setupController(controller, model) {
            this._super(controller, model);
            controller.set('editedTitle', model.get('title'));
            controller.set('editedCategory', model.get('category'));
            controller.set('editedDescription', model.get('description'));
            controller.set('editedIsPublic', model.get('public'));
        },
        actions: {
            affiliateProject: function affiliateProject(instId) {
                var _this = this;

                this.store.findRecord('institution', instId).then(function (inst) {
                    var project = _this.modelFor(_this.routeName);
                    project.get('affiliatedInstitutions').pushObject(inst);
                    project.save();
                });
            },
            deaffiliateProject: function deaffiliateProject(inst) {
                var project = this.modelFor(this.routeName);
                project.get('affiliatedInstitutions').removeObject(inst);
                project.save();
            },
            addChild: function addChild(title, description, category) {
                var project = this.modelFor(this.routeName);
                if (project.get('currentUserPermissions').indexOf(_emberOsfConstPermissions['default'].WRITE) !== -1) {
                    var child = this.store.createRecord('node', {
                        title: title,
                        category: category || 'project',
                        description: description || null
                    });
                    project.get('children').pushObject(child);
                    project.save();
                    project.one('didUpdate', this, function () {
                        this.transitionTo('projects.detail.children');
                    });
                } else {
                    console.log('You do not have permissions to create this component');
                }
            },
            // TODO: Is this necessary?
            addChildren: function addChildren(title1, title2) {
                var project = this.modelFor(this.routeName);
                if (project.get('currentUserPermissions').indexOf(_emberOsfConstPermissions['default'].WRITE) !== -1) {
                    var child1 = this.store.createRecord('node', {
                        title: title1,
                        category: 'project'
                    });
                    var child2 = this.store.createRecord('node', {
                        title: title2,
                        category: 'project'
                    });
                    project.get('children').pushObject(child1);
                    project.get('children').pushObject(child2);
                    project.save();
                } else {
                    console.log('You do not have permissions to create this component');
                }
            },
            // destroyProject() {
            //     var project = this.modelFor(this.routeName);
            //     if (project.get('currentUserPermissions').indexOf(permissions.WRITE) !== -1) {
            //         project.one('didDelete', this, function() {
            //             this.transitionTo('projects.index');
            //         });
            //         project.destroyRecord();
            //     } else {
            //         console.log('You do not have permissions to destroy this project');
            //     }
            // },
            addProjectLink: function addProjectLink(targetProjectId) {
                var project = this.modelFor(this.routeName);
                if (project.get('currentUserPermissions').indexOf(_emberOsfConstPermissions['default'].WRITE) !== -1) {
                    var projectLink = this.store.createRecord('node-link', {
                        target: targetProjectId
                    });
                    project.get('nodeLinks').pushObject(projectLink);
                    project.save();
                } else {
                    console.log('You do not have permissions to create a project link');
                }
            },
            removeProjectLink: function removeProjectLink(targetProject) {
                var project = this.modelFor(this.routeName);
                if (project.get('currentUserPermissions').indexOf(_emberOsfConstPermissions['default'].WRITE) !== -1) {
                    targetProject.destroyRecord();
                    console.log('Project link removed.');
                } else {
                    console.log('You do not have permissions to delete this project link.');
                }
            },
            addComment: function addComment(commentText, currentUser) {
                // var addCommentTextarea = $("#add-comment-textarea");
                // var commentText = addCommentTextarea.val();
                console.log('Add Comment Test', commentText);
                var project = this.modelFor(this.routeName);
                console.log(this.routeName);

                if (project.get('currentUserPermissions').indexOf(_emberOsfConstPermissions['default'].WRITE) !== -1) {
                    var comment = this.get('store').createRecord('comment', {
                        content: commentText,
                        page: 'node',
                        type: 'nodes',
                        target: project.id,
                        dateCreated: new Date(),
                        dateModified: new Date(),
                        user: currentUser
                    });

                    project.get('comments').pushObject(comment);
                    project.save(comment);
                    console.log('comment', comment);
                    console.log('Comment Added.');
                } else {
                    console.log('Error!');
                }
            }
        }
    });
});
// app/pods/projects/detail/route.js

// TODO:50 refactor permissions strings when https://github.com/CenterForOpenScience/ember-osf/pull/23/files#diff-7fd0bf247bef3c257e0fcfd7e544a338R5 is merged
define("ember-craft-repository/pods/projects/detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 4,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        return morphs;
      },
      statements: [["inline", "page-title", [["get", "model.title", ["loc", [null, [2, 8], [2, 19]]]]], ["separator", " "], ["loc", [null, [2, 0], [2, 35]]]], ["content", "outlet", ["loc", [null, [3, 0], [3, 10]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/projects/index/controller', ['exports', 'ember', 'ember-osf/mixins/paginated-controller'], function (exports, _ember, _emberOsfMixinsPaginatedController) {
    exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsPaginatedController['default'], {
        actions: {
            /**
            * Create a node
            *
            * @method createNode
            * @param {String} title, Node title
            * @param {String} description Node description
            * @return {Promise} Returns a promise that resolves to the created node
            */
            createNode: function createNode(title, description) {
                var node = this.store.createRecord('node', {
                    title: title,
                    category: 'project',
                    description: description || null
                });
                node.save();
            }
        }
    });
});
// app/pods/projects/index/controller.js
define('ember-craft-repository/pods/projects/index/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin', 'ember-osf/mixins/paginated-route'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin, _emberOsfMixinsPaginatedRoute) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], _emberOsfMixinsPaginatedRoute['default'], {
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        routeParams: null,
        // TODO: Compare and test to ember-osf dummy app
        model: function model(routeParams) {
            var _this = this;

            var user = this.modelFor('application');
            var userParams = {
                filter: {
                    contributors: ''
                }
            };

            if (user) {
                userParams['filter']['contributors'] = user.id;
                // publicParams['filter']['public'] = true;
                this.set('routeParams', routeParams);

                return this.queryForPage('node', routeParams, userParams);
            } else {
                var _ret = (function () {
                    var self = _this;

                    return {
                        v: _this.get('store').findRecord('user', 'me').then(function (user) {
                            userParams['filter']['contributors'] = user.id;
                            return self.queryForPage('node', routeParams, userParams);
                        })
                    };
                })();

                if (typeof _ret === 'object') return _ret.v;
            }
        },
        setupController: function setupController(controller, model) {
            var publicParams = {
                filter: {
                    'public': ''
                }
            };

            var routeParams = this.get('routeParams');
            publicParams['filter']['public'] = true;

            controller.set('publicProjects', this.queryForPage('node', routeParams, publicParams));
            controller.set('model', model);
        },
        actions: {
            reloadProjectListRoute: function reloadProjectListRoute() {
                this.refresh();
            }
        }
    });
});
// app/pods/projects/index/route.js
define("ember-craft-repository/pods/projects/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 28,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui stackable grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "two wide column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "twelve wide column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("div");
        dom.setAttribute(el3, "class", "ui stackable grid");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("div");
        dom.setAttribute(el4, "class", "row");
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "eight wide column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createElement("h2");
        dom.setAttribute(el6, "class", "ui header");
        var el7 = dom.createTextNode("Private Projects");
        dom.appendChild(el6, el7);
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n                ");
        dom.appendChild(el4, el5);
        var el5 = dom.createElement("div");
        dom.setAttribute(el5, "class", "eight wide right aligned column");
        var el6 = dom.createTextNode("\n                    ");
        dom.appendChild(el5, el6);
        var el6 = dom.createComment("");
        dom.appendChild(el5, el6);
        var el6 = dom.createTextNode("\n                ");
        dom.appendChild(el5, el6);
        dom.appendChild(el4, el5);
        var el5 = dom.createTextNode("\n            ");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "two wide column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui stackable grid");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "two wide column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "twelve wide column");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("h3");
        dom.setAttribute(el3, "class", "ui header");
        var el4 = dom.createTextNode("Public Projects");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        dom.setAttribute(el2, "class", "two wide column");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [4, 3]);
        var morphs = new Array(4);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(dom.childAt(element0, [1, 1, 3]), 1, 1);
        morphs[2] = dom.createMorphAt(element0, 3, 3);
        morphs[3] = dom.createMorphAt(dom.childAt(fragment, [6, 3]), 3, 3);
        return morphs;
      },
      statements: [["inline", "page-title", ["Projects"], [], ["loc", [null, [2, 0], [2, 20]]]], ["inline", "project-create", [], ["reloadRoute", "reloadProjectListRoute"], ["loc", [null, [12, 20], [12, 75]]]], ["inline", "projects-cards", [], ["pageSize", 10, "isPubic", false], ["loc", [null, [16, 8], [16, 52]]]], ["inline", "projects-public-cards", [], ["pageSize", 6, "isPublic", true], ["loc", [null, [24, 8], [24, 58]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/pods/projects/loading/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/loading/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/loading/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active centered large text inline loader");
        var el2 = dom.createTextNode("Loading");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/pods/projects/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/projects/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/projects/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/registrations/detail/route', ['exports', 'ember'], function (exports, _ember) {
    exports['default'] = _ember['default'].Route.extend({
        model: function model(params) {
            return this.store.findRecord('registration', params.registration_id);
        }
    });
});
// app/pods/registrations/detail/route.js
define("ember-craft-repository/pods/registrations/detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 20,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/registrations/detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/registrations/detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "panel");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Title: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Category: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Date Registered: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("hr");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [6]);
        var morphs = new Array(7);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
        morphs[3] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
        morphs[4] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
        morphs[5] = dom.createMorphAt(dom.childAt(element0, [9]), 1, 1);
        morphs[6] = dom.createMorphAt(element0, 13, 13);
        return morphs;
      },
      statements: [["inline", "page-title", [["get", "model.title", ["loc", [null, [2, 8], [2, 19]]]]], [], ["loc", [null, [2, 0], [2, 21]]]], ["inline", "link-to", ["Back to list", "registrations"], ["class", "btn btn-default"], ["loc", [null, [3, 0], [3, 66]]]], ["content", "model.title", ["loc", [null, [5, 29], [5, 44]]]], ["content", "model.category", ["loc", [null, [6, 32], [6, 50]]]], ["inline", "moment-format", [["get", "model.dateRegistered", ["loc", [null, [7, 55], [7, 75]]]]], [], ["loc", [null, [7, 39], [7, 77]]]], ["inline", "link-to", ["Project Registered", "projects.detail", ["get", "model.registeredFrom.id", ["loc", [null, [15, 57], [15, 80]]]]], ["class", "btn btn-warning"], ["loc", [null, [15, 8], [15, 106]]]], ["inline", "log-detail", [], ["model-logs", ["subexpr", "@mut", [["get", "model.logs", ["loc", [null, [18, 28], [18, 38]]]]], [], []]], ["loc", [null, [18, 4], [18, 40]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/pods/registrations/index/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 4,
              "column": 0
            },
            "end": {
              "line": 18,
              "column": 0
            }
          },
          "moduleName": "ember-craft-repository/pods/registrations/index/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("hr");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n    ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "panel");
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Title: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Category: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          var el3 = dom.createElement("label");
          var el4 = dom.createTextNode("Date Registered: ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("p");
          dom.setAttribute(el2, "class", "btn-group");
          var el3 = dom.createTextNode("\n");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("            ");
          dom.appendChild(el2, el3);
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n        ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n    ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [3]);
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 1, 1);
          morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element0, [5]), 1, 1);
          morphs[3] = dom.createMorphAt(dom.childAt(element0, [7]), 2, 2);
          return morphs;
        },
        statements: [["content", "registration.title", ["loc", [null, [7, 33], [7, 55]]]], ["content", "registration.category", ["loc", [null, [8, 36], [8, 61]]]], ["inline", "moment-format", [["get", "registration.dateRegistered", ["loc", [null, [9, 59], [9, 86]]]]], [], ["loc", [null, [9, 43], [9, 88]]]], ["inline", "link-to", ["Detail", "registrations.detail", ["get", "registration.id", ["loc", [null, [15, 54], [15, 69]]]]], ["class", "btn btn-primary"], ["loc", [null, [15, 12], [15, 95]]]]],
        locals: ["registration"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 19,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/registrations/index/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/registrations/index/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h4");
        var el2 = dom.createTextNode(" My Registrations ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(2);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 6, 6, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "page-title", ["Registrations"], [], ["loc", [null, [2, 0], [2, 25]]]], ["block", "each", [["get", "model", ["loc", [null, [4, 8], [4, 13]]]]], [], 0, null, ["loc", [null, [4, 0], [18, 9]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define("ember-craft-repository/pods/registrations/loading/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/registrations/loading/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/loading/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active centered large text inline loader");
        var el2 = dom.createTextNode("Loading");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/registrations/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        model: function model() {
            var user = this.modelFor('application');
            if (user) {
                return user.get('registrations');
            } else {
                return this.get('store').findRecord('user', 'me').then(function (user) {
                    return user.get('registrations');
                });
            }
        }
    });
});
// app/pods/registrations/route.js
define("ember-craft-repository/pods/registrations/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/registrations/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/registrations/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/signup/route', ['exports', 'ember'], function (exports, _ember) {
  exports['default'] = _ember['default'].Route.extend({});
});
// app/pods/signup/route.js
define("ember-craft-repository/pods/signup/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 7,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/signup/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/signup/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "row");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("div");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [2, 1]), 1, 1);
        return morphs;
      },
      statements: [["content", "sign-up", ["loc", [null, [4, 8], [4, 19]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/pods/usernodes/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin', 'ember-osf/mixins/fetch-all-route'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin, _emberOsfMixinsFetchAllRoute) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], _emberOsfMixinsFetchAllRoute['default'], {
        relationshipToFetch: 'nodes',
        model: function model() {
            // users/me
            return this.modelFor('application');
        }
    });
});
// app/pods/usernodes/route.js
define("ember-craft-repository/pods/usernodes/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 5,
              "column": 4
            },
            "end": {
              "line": 7,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/usernodes/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("li");
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode(", ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var morphs = new Array(2);
          morphs[0] = dom.createMorphAt(element0, 0, 0);
          morphs[1] = dom.createMorphAt(element0, 2, 2);
          return morphs;
        },
        statements: [["content", "node", ["loc", [null, [6, 12], [6, 20]]]], ["content", "node.title", ["loc", [null, [6, 22], [6, 36]]]]],
        locals: ["node"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 11,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/usernodes/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/usernodes/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\nUser: ");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("br");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\nProjects:\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("ol");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("button");
        var el2 = dom.createTextNode("Load more");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element1 = dom.childAt(fragment, [7]);
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(dom.childAt(fragment, [5]), 1, 1);
        morphs[2] = dom.createElementMorph(element1);
        return morphs;
      },
      statements: [["content", "model.fullName", ["loc", [null, [2, 6], [2, 24]]]], ["block", "each", [["get", "allRelated", ["loc", [null, [5, 12], [5, 22]]]]], [], 0, null, ["loc", [null, [5, 4], [7, 13]]]], ["element", "action", ["getMore"], [], ["loc", [null, [10, 8], [10, 28]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define('ember-craft-repository/pods/users/detail/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], {
        model: function model(params) {
            return this.store.findRecord('user', params.user_id);
        }
    });
});
// app/pods/users/detail/route.js
define("ember-craft-repository/pods/users/detail/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 21,
              "column": 8
            },
            "end": {
              "line": 26,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/users/detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element1 = dom.childAt(fragment, [1]);
          var morphs = new Array(2);
          morphs[0] = dom.createMorphAt(dom.childAt(element1, [1]), 0, 0);
          morphs[1] = dom.createMorphAt(dom.childAt(element1, [3]), 0, 0);
          return morphs;
        },
        statements: [["content", "project.id", ["loc", [null, [23, 20], [23, 34]]]], ["content", "project.title", ["loc", [null, [24, 20], [24, 37]]]]],
        locals: ["project"],
        templates: []
      };
    })();
    var child1 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 35,
              "column": 8
            },
            "end": {
              "line": 40,
              "column": 8
            }
          },
          "moduleName": "ember-craft-repository/pods/users/detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("            ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("td");
          var el3 = dom.createComment("");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var morphs = new Array(2);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1]), 0, 0);
          morphs[1] = dom.createMorphAt(dom.childAt(element0, [3]), 0, 0);
          return morphs;
        },
        statements: [["content", "registration.id", ["loc", [null, [37, 20], [37, 39]]]], ["content", "registration.title", ["loc", [null, [38, 20], [38, 42]]]]],
        locals: ["registration"],
        templates: []
      };
    })();
    var child2 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 46,
              "column": 12
            },
            "end": {
              "line": 50,
              "column": 12
            }
          },
          "moduleName": "ember-craft-repository/pods/users/detail/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("                ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("tr");
          var el2 = dom.createTextNode("\n                    ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n                ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var morphs = new Array(1);
          morphs[0] = dom.createMorphAt(dom.childAt(fragment, [1]), 1, 1);
          return morphs;
        },
        statements: [["content", "inst.name", ["loc", [null, [48, 20], [48, 33]]]]],
        locals: ["inst"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 54,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/users/detail/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/users/detail/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h4");
        var el3 = dom.createTextNode("Data");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Full Name: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode(" ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createElement("label");
        var el4 = dom.createTextNode("Date Registered: ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode(" ");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("hr");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h4");
        var el3 = dom.createTextNode("Projects");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("table");
        dom.setAttribute(el2, "class", "table");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("tr");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("ID");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("Title");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("hr");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h4");
        var el3 = dom.createTextNode("Registrations");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("table");
        dom.setAttribute(el2, "class", "table");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("tr");
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("ID");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n            ");
        dom.appendChild(el3, el4);
        var el4 = dom.createElement("th");
        var el5 = dom.createTextNode("Title");
        dom.appendChild(el4, el5);
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("\n        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n");
        dom.appendChild(el2, el3);
        var el3 = dom.createComment("");
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("hr");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("h4");
        var el3 = dom.createTextNode("Affiliated Institutions");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createElement("p");
        var el3 = dom.createTextNode("\n        ");
        dom.appendChild(el2, el3);
        var el3 = dom.createElement("table");
        dom.setAttribute(el3, "class", "table");
        var el4 = dom.createTextNode("\n");
        dom.appendChild(el3, el4);
        var el4 = dom.createComment("");
        dom.appendChild(el3, el4);
        var el4 = dom.createTextNode("        ");
        dom.appendChild(el3, el4);
        dom.appendChild(el2, el3);
        var el3 = dom.createTextNode("\n    ");
        dom.appendChild(el2, el3);
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element2 = dom.childAt(fragment, [6]);
        var morphs = new Array(7);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        morphs[2] = dom.createMorphAt(dom.childAt(element2, [3]), 2, 2);
        morphs[3] = dom.createMorphAt(dom.childAt(element2, [5]), 2, 2);
        morphs[4] = dom.createMorphAt(dom.childAt(element2, [13]), 3, 3);
        morphs[5] = dom.createMorphAt(dom.childAt(element2, [19]), 3, 3);
        morphs[6] = dom.createMorphAt(dom.childAt(element2, [25, 1]), 1, 1);
        return morphs;
      },
      statements: [["inline", "page-title", [["get", "model.fullName", ["loc", [null, [2, 8], [2, 22]]]]], [], ["loc", [null, [2, 0], [2, 24]]]], ["inline", "link-to", ["Back to list", "users"], ["class", "btn btn-default"], ["loc", [null, [3, 0], [3, 58]]]], ["content", "model.fullName", ["loc", [null, [6, 34], [6, 52]]]], ["inline", "moment-format", [["get", "model.dateRegistered", ["loc", [null, [7, 56], [7, 76]]]]], [], ["loc", [null, [7, 40], [7, 78]]]], ["block", "each", [["get", "model.nodes", ["loc", [null, [21, 16], [21, 27]]]]], [], 0, null, ["loc", [null, [21, 8], [26, 17]]]], ["block", "each", [["get", "model.registrations", ["loc", [null, [35, 16], [35, 35]]]]], [], 1, null, ["loc", [null, [35, 8], [40, 17]]]], ["block", "each", [["get", "model.affiliatedInstitutions", ["loc", [null, [46, 20], [46, 48]]]]], [], 2, null, ["loc", [null, [46, 12], [50, 21]]]]],
      locals: [],
      templates: [child0, child1, child2]
    };
  })());
});
define('ember-craft-repository/pods/users/list/controller', ['exports', 'ember', 'ember-osf/mixins/paginated-controller'], function (exports, _ember, _emberOsfMixinsPaginatedController) {
  exports['default'] = _ember['default'].Controller.extend(_emberOsfMixinsPaginatedController['default'], {});
});
// app/pods/users/list/controller.js
define('ember-craft-repository/pods/users/list/route', ['exports', 'ember', 'ember-simple-auth/mixins/authenticated-route-mixin', 'ember-osf/mixins/paginated-route'], function (exports, _ember, _emberSimpleAuthMixinsAuthenticatedRouteMixin, _emberOsfMixinsPaginatedRoute) {
    exports['default'] = _ember['default'].Route.extend(_emberSimpleAuthMixinsAuthenticatedRouteMixin['default'], _emberOsfMixinsPaginatedRoute['default'], {
        store: _ember['default'].inject.service(),
        session: _ember['default'].inject.service(),
        model: function model(routeParams) {
            return this.queryForPage('user', routeParams);
        }
    });
});
// app/pods/users/list/route.js
define("ember-craft-repository/pods/users/list/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    var child0 = (function () {
      return {
        meta: {
          "fragmentReason": false,
          "revision": "Ember@2.4.6",
          "loc": {
            "source": null,
            "start": {
              "line": 7,
              "column": 4
            },
            "end": {
              "line": 48,
              "column": 4
            }
          },
          "moduleName": "ember-craft-repository/pods/users/list/template.hbs"
        },
        isEmpty: false,
        arity: 1,
        cachedFragment: null,
        hasRendered: false,
        buildFragment: function buildFragment(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("        ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("div");
          dom.setAttribute(el1, "class", "ui card");
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "content");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("h3");
          dom.setAttribute(el3, "class", "ui header");
          var el4 = dom.createComment("");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createElement("div");
          dom.setAttribute(el2, "class", "content");
          var el3 = dom.createTextNode("\n                ");
          dom.appendChild(el2, el3);
          var el3 = dom.createElement("div");
          dom.setAttribute(el3, "class", "ui small feed");
          var el4 = dom.createTextNode("\n                    ");
          dom.appendChild(el3, el4);
          var el4 = dom.createElement("div");
          dom.setAttribute(el4, "class", "event");
          var el5 = dom.createTextNode("\n                        ");
          dom.appendChild(el4, el5);
          var el5 = dom.createElement("div");
          dom.setAttribute(el5, "class", "content");
          var el6 = dom.createTextNode("\n                            ");
          dom.appendChild(el5, el6);
          var el6 = dom.createElement("div");
          dom.setAttribute(el6, "class", "summary");
          var el7 = dom.createTextNode("\n                                ");
          dom.appendChild(el6, el7);
          var el7 = dom.createElement("div");
          dom.setAttribute(el7, "class", "ui list");
          var el8 = dom.createTextNode("\n                                    ");
          dom.appendChild(el7, el8);
          var el8 = dom.createElement("div");
          dom.setAttribute(el8, "class", "item");
          var el9 = dom.createTextNode("\n                                        ");
          dom.appendChild(el8, el9);
          var el9 = dom.createElement("div");
          dom.setAttribute(el9, "class", "content");
          var el10 = dom.createTextNode("\n                                            ");
          dom.appendChild(el9, el10);
          var el10 = dom.createElement("h5");
          dom.setAttribute(el10, "class", "ui blue sub header");
          var el11 = dom.createTextNode("\n                                                ");
          dom.appendChild(el10, el11);
          var el11 = dom.createElement("i");
          dom.setAttribute(el11, "class", "calendar icon");
          dom.appendChild(el10, el11);
          var el11 = dom.createTextNode("Date Registered\n                                            ");
          dom.appendChild(el10, el11);
          dom.appendChild(el9, el10);
          var el10 = dom.createTextNode("\n                                            ");
          dom.appendChild(el9, el10);
          var el10 = dom.createElement("div");
          dom.setAttribute(el10, "class", "description");
          var el11 = dom.createTextNode("\n                                                ");
          dom.appendChild(el10, el11);
          var el11 = dom.createComment("");
          dom.appendChild(el10, el11);
          var el11 = dom.createTextNode("\n                                            ");
          dom.appendChild(el10, el11);
          dom.appendChild(el9, el10);
          var el10 = dom.createTextNode("\n                                        ");
          dom.appendChild(el9, el10);
          dom.appendChild(el8, el9);
          var el9 = dom.createTextNode("\n                                    ");
          dom.appendChild(el8, el9);
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                                    ");
          dom.appendChild(el7, el8);
          var el8 = dom.createElement("div");
          dom.setAttribute(el8, "class", "item");
          var el9 = dom.createTextNode("\n                                        ");
          dom.appendChild(el8, el9);
          var el9 = dom.createElement("div");
          dom.setAttribute(el9, "class", "content");
          var el10 = dom.createTextNode("\n                                            ");
          dom.appendChild(el9, el10);
          var el10 = dom.createElement("h5");
          dom.setAttribute(el10, "class", "ui blue sub header");
          var el11 = dom.createTextNode("\n                                                ");
          dom.appendChild(el10, el11);
          var el11 = dom.createElement("i");
          dom.setAttribute(el11, "class", "idea icon");
          dom.appendChild(el10, el11);
          var el11 = dom.createTextNode("User ID\n                                            ");
          dom.appendChild(el10, el11);
          dom.appendChild(el9, el10);
          var el10 = dom.createTextNode("\n                                            ");
          dom.appendChild(el9, el10);
          var el10 = dom.createElement("div");
          dom.setAttribute(el10, "class", "description");
          var el11 = dom.createTextNode("\n                                                ");
          dom.appendChild(el10, el11);
          var el11 = dom.createComment("");
          dom.appendChild(el10, el11);
          var el11 = dom.createTextNode("\n                                            ");
          dom.appendChild(el10, el11);
          dom.appendChild(el9, el10);
          var el10 = dom.createTextNode("\n                                        ");
          dom.appendChild(el9, el10);
          dom.appendChild(el8, el9);
          var el9 = dom.createTextNode("\n                                    ");
          dom.appendChild(el8, el9);
          dom.appendChild(el7, el8);
          var el8 = dom.createTextNode("\n                                ");
          dom.appendChild(el7, el8);
          dom.appendChild(el6, el7);
          var el7 = dom.createTextNode("\n                            ");
          dom.appendChild(el6, el7);
          dom.appendChild(el5, el6);
          var el6 = dom.createTextNode("\n                        ");
          dom.appendChild(el5, el6);
          dom.appendChild(el4, el5);
          var el5 = dom.createTextNode("\n                    ");
          dom.appendChild(el4, el5);
          dom.appendChild(el3, el4);
          var el4 = dom.createTextNode("\n                ");
          dom.appendChild(el3, el4);
          dom.appendChild(el2, el3);
          var el3 = dom.createTextNode("\n            ");
          dom.appendChild(el2, el3);
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("            ");
          dom.appendChild(el1, el2);
          var el2 = dom.createComment("");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("\n        ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
          var element0 = dom.childAt(fragment, [1]);
          var element1 = dom.childAt(element0, [3, 1, 1, 1, 1, 1]);
          var morphs = new Array(4);
          morphs[0] = dom.createMorphAt(dom.childAt(element0, [1, 1]), 0, 0);
          morphs[1] = dom.createMorphAt(dom.childAt(element1, [1, 1, 3]), 1, 1);
          morphs[2] = dom.createMorphAt(dom.childAt(element1, [3, 1, 3]), 1, 1);
          morphs[3] = dom.createMorphAt(element0, 6, 6);
          return morphs;
        },
        statements: [["content", "user.fullName", ["loc", [null, [10, 38], [10, 55]]]], ["inline", "moment-format", [["get", "user.dateRegistered", ["loc", [null, [24, 64], [24, 83]]]]], [], ["loc", [null, [24, 48], [24, 85]]]], ["content", "user.id", ["loc", [null, [34, 48], [34, 59]]]], ["inline", "link-to", ["Detail", "users.detail", ["get", "user.id", ["loc", [null, [46, 46], [46, 53]]]]], ["class", "ui bottom attached button"], ["loc", [null, [46, 12], [46, 89]]]]],
        locals: ["user"],
        templates: []
      };
    })();
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 61,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/users/list/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/users/list/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("h2");
        dom.setAttribute(el1, "class", "ui header");
        var el2 = dom.createTextNode("Users");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui four doubling cards");
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui inverted black segment pagination");
        var el2 = dom.createTextNode("\n    ");
        dom.appendChild(el1, el2);
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        var el2 = dom.createTextNode("\n");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(3);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        morphs[1] = dom.createMorphAt(dom.childAt(fragment, [6]), 1, 1);
        morphs[2] = dom.createMorphAt(dom.childAt(fragment, [8]), 1, 1);
        return morphs;
      },
      statements: [["inline", "page-title", ["Users"], [], ["loc", [null, [2, 0], [2, 17]]]], ["block", "each", [["get", "model", ["loc", [null, [7, 12], [7, 17]]]]], [], 0, null, ["loc", [null, [7, 4], [48, 13]]]], ["inline", "pagination-control-ui", [], ["currentPage", ["subexpr", "@mut", [["get", "page", ["loc", [null, [54, 20], [54, 24]]]]], [], []], "pageCount", ["subexpr", "@mut", [["get", "totalPages", ["loc", [null, [55, 18], [55, 28]]]]], [], []], "next", ["subexpr", "action", ["next"], [], ["loc", [null, [56, 13], [56, 28]]]], "previous", ["subexpr", "action", ["previous"], [], ["loc", [null, [57, 17], [57, 36]]]], "goToPage", ["subexpr", "action", ["goToPage"], [], ["loc", [null, [58, 17], [58, 36]]]]], ["loc", [null, [53, 4], [59, 6]]]]],
      locals: [],
      templates: [child0]
    };
  })());
});
define("ember-craft-repository/pods/users/loading/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/users/loading/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/loading/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("div");
        dom.setAttribute(el1, "class", "ui active centered large text inline loader");
        var el2 = dom.createTextNode("Loading");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes() {
        return [];
      },
      statements: [],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/pods/users/template", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 3,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/pods/users/template.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" app/pods/users/template.hbs ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 2, 2, contextualElement);
        return morphs;
      },
      statements: [["content", "outlet", ["loc", [null, [2, 0], [2, 10]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/resolver', ['exports', 'ember-resolver'], function (exports, _emberResolver) {
  exports['default'] = _emberResolver['default'];
});
// app/resolver.js
define('ember-craft-repository/router', ['exports', 'ember', 'ember-craft-repository/config/environment'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment) {

    var Router = _ember['default'].Router.extend({
        location: _emberCraftRepositoryConfigEnvironment['default'].locationType,
        rootURL: _emberCraftRepositoryConfigEnvironment['default'].rootURL
    });

    Router.map(function () {
        this.route('index', {
            path: '/'
        });
        this.route('login');
        this.route('cookielogin');
        this.route('projects', function () {
            // this.route('index', {
            //     path: '/'
            // });
            this.route('detail', {
                path: '/:node_id'
            }, function () {
                this.route('children');
                this.route('files', function () {
                    this.route('provider', {
                        path: '/:provider'
                    }, function () {
                        this.route('file', {
                            path: '/:file_id'
                        }, function () {
                            this.route('revisions');
                        });
                    });
                });
                this.route('registrations');
                this.route('draft_registrations', function () {
                    this.route('detail', {
                        path: '/:draft_registration_id'
                    });
                });
            });
        });
        this.route('signup');
        this.route('institutions', function () {
            this.route('detail', {
                path: '/:institution_id'
            });
        });
        this.route('registrations', function () {
            this.route('detail', {
                path: '/:registration_id'
            });
        });
        this.route('users', function () {
            this.route('list', {
                path: '/'
            });
            this.route('detail', {
                path: '/:user_id'
            });
        });
        this.route('profile');
        this.route('collections', function () {
            this.route('detail', {
                path: '/:collection_id'
            });
        });
        this.route('prereg');
        this.route('allnodes');
        this.route('usernodes');
    });

    exports['default'] = Router;
});
// app/router.js
define('ember-craft-repository/routes/application', ['exports', 'ember'], function (exports, _ember) {
  exports['default'] = _ember['default'].Route.extend();
});
define('ember-craft-repository/serializers/collection', ['exports', 'ember-osf/serializers/collection'], function (exports, _emberOsfSerializersCollection) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersCollection['default'];
    }
  });
});
define('ember-craft-repository/serializers/comment-report', ['exports', 'ember-osf/serializers/comment-report'], function (exports, _emberOsfSerializersCommentReport) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersCommentReport['default'];
    }
  });
});
define('ember-craft-repository/serializers/comment', ['exports', 'ember-osf/serializers/comment'], function (exports, _emberOsfSerializersComment) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersComment['default'];
    }
  });
});
define('ember-craft-repository/serializers/contributor', ['exports', 'ember-osf/serializers/contributor'], function (exports, _emberOsfSerializersContributor) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersContributor['default'];
    }
  });
});
define('ember-craft-repository/serializers/draft-registration', ['exports', 'ember-osf/serializers/draft-registration'], function (exports, _emberOsfSerializersDraftRegistration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersDraftRegistration['default'];
    }
  });
});
define('ember-craft-repository/serializers/file-contents', ['exports', 'ember-osf/serializers/file-contents'], function (exports, _emberOsfSerializersFileContents) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersFileContents['default'];
    }
  });
});
define('ember-craft-repository/serializers/file-provider', ['exports', 'ember-osf/serializers/file-provider'], function (exports, _emberOsfSerializersFileProvider) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersFileProvider['default'];
    }
  });
});
define('ember-craft-repository/serializers/file-version', ['exports', 'ember-osf/serializers/file-version'], function (exports, _emberOsfSerializersFileVersion) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersFileVersion['default'];
    }
  });
});
define('ember-craft-repository/serializers/file', ['exports', 'ember-osf/serializers/file'], function (exports, _emberOsfSerializersFile) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersFile['default'];
    }
  });
});
define('ember-craft-repository/serializers/institution', ['exports', 'ember-osf/serializers/institution'], function (exports, _emberOsfSerializersInstitution) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersInstitution['default'];
    }
  });
});
define('ember-craft-repository/serializers/linked-node', ['exports', 'ember-osf/serializers/linked-node'], function (exports, _emberOsfSerializersLinkedNode) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersLinkedNode['default'];
    }
  });
});
define('ember-craft-repository/serializers/metaschema', ['exports', 'ember-osf/serializers/metaschema'], function (exports, _emberOsfSerializersMetaschema) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersMetaschema['default'];
    }
  });
});
define('ember-craft-repository/serializers/node-link', ['exports', 'ember-osf/serializers/node-link'], function (exports, _emberOsfSerializersNodeLink) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersNodeLink['default'];
    }
  });
});
define('ember-craft-repository/serializers/node', ['exports', 'ember-osf/serializers/node'], function (exports, _emberOsfSerializersNode) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersNode['default'];
    }
  });
});
define('ember-craft-repository/serializers/osf-serializer', ['exports', 'ember-osf/serializers/osf-serializer'], function (exports, _emberOsfSerializersOsfSerializer) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersOsfSerializer['default'];
    }
  });
});
define('ember-craft-repository/serializers/registration', ['exports', 'ember-osf/serializers/registration'], function (exports, _emberOsfSerializersRegistration) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersRegistration['default'];
    }
  });
});
define('ember-craft-repository/serializers/user', ['exports', 'ember-osf/serializers/user'], function (exports, _emberOsfSerializersUser) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfSerializersUser['default'];
    }
  });
});
define('ember-craft-repository/services/ajax', ['exports', 'ember-ajax/services/ajax'], function (exports, _emberAjaxServicesAjax) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberAjaxServicesAjax['default'];
    }
  });
});
define('ember-craft-repository/services/current-user', ['exports', 'ember-osf/services/current-user'], function (exports, _emberOsfServicesCurrentUser) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfServicesCurrentUser['default'];
    }
  });
});
define('ember-craft-repository/services/file-manager', ['exports', 'ember-osf/services/file-manager'], function (exports, _emberOsfServicesFileManager) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfServicesFileManager['default'];
    }
  });
});
define('ember-craft-repository/services/head-data', ['exports', 'ember-cli-head/services/head-data'], function (exports, _emberCliHeadServicesHeadData) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberCliHeadServicesHeadData['default'];
    }
  });
});
define('ember-craft-repository/services/i18n', ['exports', 'ember-i18n/services/i18n'], function (exports, _emberI18nServicesI18n) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberI18nServicesI18n['default'];
    }
  });
});
define('ember-craft-repository/services/media', ['exports', 'ember-responsive/media'], function (exports, _emberResponsiveMedia) {
  exports['default'] = _emberResponsiveMedia['default'];
});
define('ember-craft-repository/services/moment', ['exports', 'ember', 'ember-craft-repository/config/environment', 'ember-moment/services/moment'], function (exports, _ember, _emberCraftRepositoryConfigEnvironment, _emberMomentServicesMoment) {
  exports['default'] = _emberMomentServicesMoment['default'].extend({
    defaultFormat: _ember['default'].get(_emberCraftRepositoryConfigEnvironment['default'], 'moment.outputFormat')
  });
});
define('ember-craft-repository/services/page-title-list', ['exports', 'ember-page-title/services/page-title-list', 'ember-craft-repository/config/environment'], function (exports, _emberPageTitleServicesPageTitleList, _emberCraftRepositoryConfigEnvironment) {

  function capitalize(key) {
    return key.charAt(0).toUpperCase() + key.slice(1);
  }

  var defaults = {};
  ['separator', 'prepend', 'replace'].forEach(function (key) {
    if (_emberCraftRepositoryConfigEnvironment['default'].pageTitle && _emberCraftRepositoryConfigEnvironment['default'].pageTitle[key]) {
      defaults['default' + capitalize(key)] = _emberCraftRepositoryConfigEnvironment['default'].pageTitle[key];
    }
  });

  exports['default'] = _emberPageTitleServicesPageTitleList['default'].extend(defaults);
});
define('ember-craft-repository/services/session', ['exports', 'ember-simple-auth/services/session'], function (exports, _emberSimpleAuthServicesSession) {
  exports['default'] = _emberSimpleAuthServicesSession['default'];
});
define('ember-craft-repository/services/toast', ['exports', 'ember-toastr/services/toast'], function (exports, _emberToastrServicesToast) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberToastrServicesToast['default'];
    }
  });
});
define('ember-craft-repository/session-stores/application', ['exports', 'ember-simple-auth/session-stores/adaptive'], function (exports, _emberSimpleAuthSessionStoresAdaptive) {
  exports['default'] = _emberSimpleAuthSessionStoresAdaptive['default'].extend();
});
define("ember-craft-repository/templates/components/ui-accordion", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-accordion.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-checkbox", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["multiple-nodes", "wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 7,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-checkbox.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createElement("input");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("label");
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [0]);
        if (this.cachedFragment) {
          dom.repairClonedNode(element0, [], true);
        }
        var morphs = new Array(7);
        morphs[0] = dom.createAttrMorph(element0, 'type');
        morphs[1] = dom.createAttrMorph(element0, 'name');
        morphs[2] = dom.createAttrMorph(element0, 'tabindex');
        morphs[3] = dom.createAttrMorph(element0, 'checked');
        morphs[4] = dom.createAttrMorph(element0, 'disabled');
        morphs[5] = dom.createMorphAt(dom.childAt(fragment, [2]), 0, 0);
        morphs[6] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["attribute", "type", ["get", "type", ["loc", [null, [1, 14], [1, 18]]]]], ["attribute", "name", ["get", "name", ["loc", [null, [2, 14], [2, 18]]]]], ["attribute", "tabindex", ["get", "tabindex", ["loc", [null, [3, 18], [3, 26]]]]], ["attribute", "checked", ["subexpr", "unbound", [["get", "checked", ["loc", [null, [4, 25], [4, 32]]]]], [], ["loc", [null, [4, 15], [4, 34]]]]], ["attribute", "disabled", ["subexpr", "unbound", [["get", "disabled", ["loc", [null, [5, 26], [5, 34]]]]], [], ["loc", [null, [5, 16], [5, 36]]]]], ["content", "label", ["loc", [null, [6, 7], [6, 16]]]], ["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [7, 8], [7, 26]]]]], [], ["loc", [null, [7, 0], [7, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-dimmer", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 2,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-dimmer.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-dropdown", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 47
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-dropdown.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]], ["subexpr", "action", ["mapping"], [], ["loc", [null, [1, 27], [1, 45]]]]], [], ["loc", [null, [1, 0], [1, 47]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-embed", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-embed.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-modal", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-modal.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-nag", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-nag.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-popup", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-popup.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-progress", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-progress.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-radio", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["multiple-nodes", "wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 7,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-radio.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createElement("input");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("label");
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var element0 = dom.childAt(fragment, [0]);
        if (this.cachedFragment) {
          dom.repairClonedNode(element0, [], true);
        }
        var morphs = new Array(7);
        morphs[0] = dom.createAttrMorph(element0, 'type');
        morphs[1] = dom.createAttrMorph(element0, 'name');
        morphs[2] = dom.createAttrMorph(element0, 'tabindex');
        morphs[3] = dom.createAttrMorph(element0, 'checked');
        morphs[4] = dom.createAttrMorph(element0, 'disabled');
        morphs[5] = dom.createMorphAt(dom.childAt(fragment, [2]), 0, 0);
        morphs[6] = dom.createMorphAt(fragment, 4, 4, contextualElement);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["attribute", "type", ["get", "type", ["loc", [null, [1, 14], [1, 18]]]]], ["attribute", "name", ["get", "name", ["loc", [null, [2, 14], [2, 18]]]]], ["attribute", "tabindex", ["get", "tabindex", ["loc", [null, [3, 18], [3, 26]]]]], ["attribute", "checked", ["subexpr", "unbound", [["get", "checked", ["loc", [null, [4, 25], [4, 32]]]]], [], ["loc", [null, [4, 15], [4, 34]]]]], ["attribute", "disabled", ["subexpr", "unbound", [["get", "disabled", ["loc", [null, [5, 26], [5, 34]]]]], [], ["loc", [null, [5, 16], [5, 36]]]]], ["content", "label", ["loc", [null, [6, 7], [6, 16]]]], ["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [7, 8], [7, 26]]]]], [], ["loc", [null, [7, 0], [7, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-rating", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-rating.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-search", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-search.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-shape", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-shape.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-sidebar", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-sidebar.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/components/ui-sticky", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 1,
            "column": 28
          }
        },
        "moduleName": "ember-craft-repository/templates/components/ui-sticky.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment("");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(fragment, 0, 0, contextualElement);
        dom.insertBoundary(fragment, 0);
        dom.insertBoundary(fragment, null);
        return morphs;
      },
      statements: [["inline", "yield", [["subexpr", "action", ["execute"], [], ["loc", [null, [1, 8], [1, 26]]]]], [], ["loc", [null, [1, 0], [1, 28]]]]],
      locals: [],
      templates: []
    };
  })());
});
define("ember-craft-repository/templates/head", ["exports"], function (exports) {
  exports["default"] = Ember.HTMLBars.template((function () {
    return {
      meta: {
        "fragmentReason": {
          "name": "missing-wrapper",
          "problems": ["wrong-type", "multiple-nodes"]
        },
        "revision": "Ember@2.4.6",
        "loc": {
          "source": null,
          "start": {
            "line": 1,
            "column": 0
          },
          "end": {
            "line": 6,
            "column": 0
          }
        },
        "moduleName": "ember-craft-repository/templates/head.hbs"
      },
      isEmpty: false,
      arity: 0,
      cachedFragment: null,
      hasRendered: false,
      buildFragment: function buildFragment(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createComment(" `app/templates/head.hbs` ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment(" content from ember-page-title, injected by ember-cli-head ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment(" The 'model' available in this template can be populated by ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createComment(" setting values on the 'head-data' service. ");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("title");
        var el2 = dom.createComment("");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      buildRenderNodes: function buildRenderNodes(dom, fragment, contextualElement) {
        var morphs = new Array(1);
        morphs[0] = dom.createMorphAt(dom.childAt(fragment, [8]), 0, 0);
        return morphs;
      },
      statements: [["content", "model.title", ["loc", [null, [5, 7], [5, 22]]]]],
      locals: [],
      templates: []
    };
  })());
});
define('ember-craft-repository/transforms/embed', ['exports', 'ember-osf/transforms/embed'], function (exports, _emberOsfTransformsEmbed) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfTransformsEmbed['default'];
    }
  });
});
define('ember-craft-repository/transforms/links', ['exports', 'ember-osf/transforms/links'], function (exports, _emberOsfTransformsLinks) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfTransformsLinks['default'];
    }
  });
});
define('ember-craft-repository/utils/ajax-helpers', ['exports', 'ember-osf/utils/ajax-helper'], function (exports, _emberOsfUtilsAjaxHelper) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfUtilsAjaxHelper['default'];
    }
  });
  Object.defineProperty(exports, 'authenticatedAJAX', {
    enumerable: true,
    get: function get() {
      return _emberOsfUtilsAjaxHelper.authenticatedAJAX;
    }
  });
});
define('ember-craft-repository/utils/auth', ['exports', 'ember-osf/utils/auth'], function (exports, _emberOsfUtilsAuth) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfUtilsAuth['default'];
    }
  });
});
define('ember-craft-repository/utils/i18n/compile-template', ['exports', 'ember-i18n/utils/i18n/compile-template'], function (exports, _emberI18nUtilsI18nCompileTemplate) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberI18nUtilsI18nCompileTemplate['default'];
    }
  });
});
define('ember-craft-repository/utils/i18n/missing-message', ['exports', 'ember-i18n/utils/i18n/missing-message'], function (exports, _emberI18nUtilsI18nMissingMessage) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberI18nUtilsI18nMissingMessage['default'];
    }
  });
});
define('ember-craft-repository/utils/load-relationship', ['exports', 'ember-osf/utils/load-relationship'], function (exports, _emberOsfUtilsLoadRelationship) {
  Object.defineProperty(exports, 'default', {
    enumerable: true,
    get: function get() {
      return _emberOsfUtilsLoadRelationship['default'];
    }
  });
});
/* jshint ignore:start */



/* jshint ignore:end */

/* jshint ignore:start */

define('ember-craft-repository/config/environment', ['ember'], function(Ember) {
  var prefix = 'ember-craft-repository';
/* jshint ignore:start */

try {
  var metaName = prefix + '/config/environment';
  var rawConfig = document.querySelector('meta[name="' + metaName + '"]').getAttribute('content');
  var config = JSON.parse(unescape(rawConfig));

  var exports = { 'default': config };

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

/* jshint ignore:end */

});

/* jshint ignore:end */

/* jshint ignore:start */

if (!runningTests) {
  require("ember-craft-repository/app")["default"].create({"LOG_TRANSITIONS":true,"name":"ember-craft-repository","version":"0.0.1+3a4ec935"});
}

/* jshint ignore:end */
//# sourceMappingURL=ember-craft-repository.map